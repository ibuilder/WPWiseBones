<?php
/**
 * Author archive template.
 */
defined( 'ABSPATH' ) || exit;
get_header();
$wpwisebones_container = get_theme_mod( 'wpwisebones_container_width', 'container' );
$wpwisebones_options   = get_option( 'wpwisebones_options', array() );
if ( ! empty( $wpwisebones_options['breadcrumbs'] ) ) {
	wpwisebones_breadcrumbs();
}
$wpwisebones_author_id = get_queried_object_id();
$wpwisebones_author    = get_queried_object();
?>
<div id="content" class="site-content">
	<div class="<?php echo esc_attr( $wpwisebones_container ); ?>">
		<div class="row g-4">

			<?php if ( wpwisebones_has_sidebar() && 'left-sidebar' === wpwisebones_get_layout() ) : ?>
				<aside id="secondary" class="col-lg-4 widget-area"><?php get_sidebar(); ?></aside>
			<?php endif; ?>

			<main id="main" tabindex="-1" class="site-main <?php echo esc_attr( wpwisebones_content_class() ); ?>">

				<!-- Author card -->
				<div class="card border-0 bg-body-tertiary mb-5 p-4">
					<div class="d-flex gap-4 align-items-center flex-wrap">
						<?php echo wp_kses_post( get_avatar( $wpwisebones_author_id, 96, '', '', array( 'class' => 'rounded-circle flex-shrink-0' ) ) ); ?>
						<div>
							<h1 class="h3 mb-1"><?php echo esc_html( $wpwisebones_author->display_name ); ?></h1>
							<?php if ( $wpwisebones_author->description ) : ?>
								<p class="text-muted mb-2"><?php echo esc_html( $wpwisebones_author->description ); ?></p>
							<?php endif; ?>
							<div class="d-flex gap-2 flex-wrap small text-muted">
								<?php if ( $wpwisebones_author->user_url ) : ?>
									<a href="<?php echo esc_url( $wpwisebones_author->user_url ); ?>" target="_blank" rel="noopener noreferrer">
										<i class="bi bi-globe me-1"></i><?php echo esc_html( $wpwisebones_author->user_url ); ?>
									</a>
								<?php endif; ?>
								<span><i class="bi bi-file-post me-1"></i>
									<?php
									printf(
										/* translators: %d: number of posts */
										esc_html( _n( '%d post', '%d posts', (int) count_user_posts( $wpwisebones_author_id ), 'wpwisebones' ) ),
										(int) count_user_posts( $wpwisebones_author_id )
									);
									?>
								</span>
							</div>
						</div>
					</div>
				</div>

				<?php if ( have_posts() ) : ?>
					<div class="row g-4">
					<?php
					while ( have_posts() ) :
						the_post();
						?>
						<?php get_template_part( 'template-parts/content/content', get_post_type() ); ?>
					<?php endwhile; ?>
					</div>
					<?php wpwisebones_pagination(); ?>
				<?php else : ?>
					<?php get_template_part( 'template-parts/content/content', 'none' ); ?>
				<?php endif; ?>
			</main>

			<?php if ( wpwisebones_has_sidebar() && 'right-sidebar' === wpwisebones_get_layout() ) : ?>
				<aside id="secondary" class="col-lg-4 widget-area"><?php get_sidebar(); ?></aside>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>
