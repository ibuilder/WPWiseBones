<?php
/**
 * Fallback singular template - used for any single post/page that doesn't
 * match a more specific template (single.php, page.php, etc.).
 */
defined( 'ABSPATH' ) || exit;
get_header();
$wpwisebones_container = get_theme_mod( 'wpwisebones_container_width', 'container' );
$wpwisebones_options   = get_option( 'wpwisebones_options', array() );
if ( ! empty( $wpwisebones_options['breadcrumbs'] ) ) {
	wpwisebones_breadcrumbs();
}
?>
<div id="content" class="site-content">
	<div class="<?php echo esc_attr( $wpwisebones_container ); ?>">
		<div class="row g-4">

			<?php if ( wpwisebones_has_sidebar() && 'left-sidebar' === wpwisebones_get_layout() ) : ?>
				<aside id="secondary" class="col-lg-4 widget-area"><?php get_sidebar(); ?></aside>
			<?php endif; ?>

			<main id="main" tabindex="-1" class="site-main <?php echo esc_attr( wpwisebones_content_class() ); ?>">
				<?php
				while ( have_posts() ) :
					the_post();
					?>
					<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
						<header class="entry-header mb-4">
							<h1 class="entry-title"><?php the_title(); ?></h1>
							<div class="entry-meta text-muted small">
								<?php
								wpwisebones_posted_on();
								wpwisebones_posted_by();
								?>
							</div>
						</header>
						<?php
						if ( has_post_thumbnail() ) {
							the_post_thumbnail( 'wpwisebones-hero', array( 'class' => 'img-fluid rounded mb-4' ) );}
						?>
						<div class="entry-content"><?php the_content(); ?></div>
						<footer class="entry-footer mt-4 pt-3 border-top"><?php wpwisebones_entry_footer(); ?></footer>
					</article>
					<?php
					if ( comments_open() || get_comments_number() ) {
						comments_template();}
					?>
				<?php endwhile; ?>
			</main>

			<?php if ( wpwisebones_has_sidebar() && 'right-sidebar' === wpwisebones_get_layout() ) : ?>
				<aside id="secondary" class="col-lg-4 widget-area"><?php get_sidebar(); ?></aside>
			<?php endif; ?>
		</div>
	</div>
</div>
<?php get_footer(); ?>
