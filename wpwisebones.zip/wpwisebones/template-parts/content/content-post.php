<?php
/**
 * Template part: post card for blog loop.
 */
defined( 'ABSPATH' ) || exit;
$wpwisebones_options = get_option( 'wpwisebones_options', array() );
?>
<div class="col-md-6 col-lg-4">
	<article id="post-<?php the_ID(); ?>" <?php post_class( 'card h-100 post-card border-0 shadow-sm' ); ?>>
		<?php if ( has_post_thumbnail() ) : ?>
			<a href="<?php the_permalink(); ?>" tabindex="-1" aria-hidden="true">
				<?php the_post_thumbnail( 'wpwisebones-card', array( 'class' => 'card-img-top' ) ); ?>
			</a>
		<?php endif; ?>

		<div class="card-body d-flex flex-column">
			<div class="entry-meta mb-2 text-muted small">
				<?php
				wpwisebones_posted_on();
				wpwisebones_posted_by();
				?>
				<?php if ( ! empty( $wpwisebones_options['reading_time'] ) ) : ?>
					<span class="reading-time"><i class="bi bi-clock me-1"></i><?php echo esc_html( wpwisebones_reading_time() ); ?></span>
				<?php endif; ?>
			</div>

			<h2 class="card-title h5">
				<a href="<?php the_permalink(); ?>" class="link-body-emphasis text-decoration-none">
					<?php the_title(); ?>
				</a>
			</h2>

			<div class="card-text text-muted flex-grow-1">
				<?php the_excerpt(); ?>
			</div>

			<a href="<?php the_permalink(); ?>" class="btn btn-sm btn-outline-primary mt-3 align-self-start">
				<?php esc_html_e( 'Read More', 'wpwisebones' ); ?> <i class="bi bi-arrow-right ms-1"></i>
			</a>
		</div>

		<div class="card-footer bg-transparent border-top-0 small text-muted">
			<?php wpwisebones_entry_footer(); ?>
		</div>
	</article>
</div>
