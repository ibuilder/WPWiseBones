# Sample MLS data

Twenty-four realistic sample listings, provided in three formats so you can test
the import pipeline without MLS credentials and preview how each feed type maps.

| File | Format | Use with adapter |
|------|--------|------------------|
| `reso-sample.json` | RESO Web API (OData `value[]`) | **Demo** (`{"format":"reso"}`) — also mirrors RESO/Bridge/Trestle/MLS Grid/Paragon output |
| `flexmls-sample.json` | FlexMLS / Spark (`D.Results[].StandardFields`) | **Demo** (`{"format":"flexmls"}`) — mirrors Spark/FlexMLS output |
| `listings-sample.csv` | CSV with RESO headers | **CSV / IDX File** (point `base_url` or `extra_params.path` at a copy in uploads) |

## What's in the set

- **Asset types:** Residential (14), Residential Income / multifamily (2), Land (3), Commercial Sale (5 — incl. Retail, Industrial, Office, Mixed Use, Special Purpose/airpark)
- **Markets:** TX (10), FL (5), AZ (3), CO (3), WA (3)
- **Statuses:** Active (20), Pending (2), Closed (2 — the Closed ones double as comparable sales for the comps engine)
- **Fields:** price, full address + lat/lon, beds/baths/sqft/lot/year, garage, pool, HOA, taxes, cap rate, units, days-on-market, virtual tour, agent (name/email/phone/office/license), and three photos each

## Quickest way to try it

1. **MLS Connect → MLS Feeds → Add Feed**
2. Adapter: **Demo (bundled sample data)**, Active: ✓, Save
3. Back on the dashboard, click **Run Now**
4. Open **RealWise Listings → All Listings** — the 24 sample homes are imported, scored, and mapped.

## Regenerating

All three files are generated from one canonical source to stay in sync:

```bash
php tools/make-sample-data.php
```
