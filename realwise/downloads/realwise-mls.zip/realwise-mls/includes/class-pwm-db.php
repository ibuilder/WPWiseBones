<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWM_DB — schema and helpers for MLS Connect.
 */
class PWM_DB {

    public static function log_table()       { global $wpdb; return $wpdb->prefix . 'pwm_import_log'; }
    public static function field_map_table() { global $wpdb; return $wpdb->prefix . 'pwm_field_maps'; }
    public static function feed_table()      { global $wpdb; return $wpdb->prefix . 'pwm_feeds'; }

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::feed_table() . " (
            id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
            label              VARCHAR(80)  NOT NULL DEFAULT 'My MLS Feed',
            adapter            VARCHAR(32)  NOT NULL DEFAULT 'bridge',
            base_url           VARCHAR(255) DEFAULT NULL,
            api_key            VARCHAR(255) DEFAULT NULL,
            api_secret         VARCHAR(255) DEFAULT NULL,
            extra_params       TEXT         DEFAULT NULL,
            asset_types        VARCHAR(255) DEFAULT 'all',
            filter_states      VARCHAR(255) DEFAULT NULL,
            filter_zips        TEXT         DEFAULT NULL,
            schedule_frequency VARCHAR(16)  DEFAULT 'daily',
            schedule_time      VARCHAR(8)   DEFAULT '02:00',
            max_records        INT          DEFAULT 5000,
            active             TINYINT(1)   DEFAULT 1,
            last_run           DATETIME     DEFAULT NULL,
            last_run_status    VARCHAR(16)  DEFAULT NULL,
            created_at         DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::log_table() . " (
            id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            feed_id          INT UNSIGNED    NOT NULL,
            started_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
            finished_at      DATETIME        DEFAULT NULL,
            status           VARCHAR(16)     DEFAULT 'running',
            records_fetched  INT UNSIGNED    DEFAULT 0,
            records_inserted INT UNSIGNED    DEFAULT 0,
            records_updated  INT UNSIGNED    DEFAULT 0,
            records_skipped  INT UNSIGNED    DEFAULT 0,
            pages_pulled     SMALLINT        DEFAULT 0,
            error_message    TEXT            DEFAULT NULL,
            memory_peak_mb   DECIMAL(6,1)    DEFAULT NULL,
            PRIMARY KEY (id),
            KEY feed_id (feed_id),
            KEY started_at (started_at)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::field_map_table() . " (
            id            INT UNSIGNED  NOT NULL AUTO_INCREMENT,
            feed_id       INT UNSIGNED  NOT NULL,
            mls_field     VARCHAR(120)  NOT NULL,
            pw_column     VARCHAR(80)   NOT NULL,
            transform     VARCHAR(32)   DEFAULT NULL,
            default_value VARCHAR(255)  DEFAULT NULL,
            active        TINYINT(1)    DEFAULT 1,
            PRIMARY KEY (id),
            UNIQUE KEY feed_field (feed_id, mls_field)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) dbDelta( $q );

        // Seed default feed if empty
        $count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::feed_table() );
        if ( $count === 0 ) {
            $wpdb->insert( self::feed_table(), [
                'label'       => 'Bridge Interactive (Default)',
                'adapter'     => 'bridge',
                'asset_types' => 'residential,commercial,industrial,land,multifamily',
                'active'      => 0,
            ] );
        }
    }

    public static function get_feeds( bool $active_only = false ): array {
        global $wpdb;
        $where = $active_only ? 'WHERE active = 1' : '';
        return $wpdb->get_results( "SELECT * FROM " . self::feed_table() . " $where ORDER BY id ASC" ) ?: [];
    }

    public static function get_feed( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::feed_table() . ' WHERE id = %d', $id ) );
    }

    public static function save_feed( array $data ): int {
        global $wpdb;
        $table = self::feed_table();
        if ( ! empty( $data['id'] ) ) {
            $id = (int) $data['id']; unset( $data['id'] );
            $wpdb->update( $table, $data, [ 'id' => $id ] );
            return $id;
        }
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function delete_feed( int $id ): void {
        global $wpdb;
        $wpdb->delete( self::feed_table(),      [ 'id'      => $id ] );
        $wpdb->delete( self::field_map_table(), [ 'feed_id' => $id ] );
    }

    public static function log_start( int $feed_id ): int {
        global $wpdb;
        $wpdb->insert( self::log_table(), [ 'feed_id' => $feed_id, 'started_at' => current_time('mysql'), 'status' => 'running' ] );
        return $wpdb->insert_id;
    }

    public static function log_finish( int $log_id, string $status, array $counts, ?string $error = null ): void {
        global $wpdb;
        $wpdb->update( self::log_table(), array_merge( $counts, [
            'finished_at'    => current_time( 'mysql' ),
            'status'         => $status,
            'error_message'  => $error,
            'memory_peak_mb' => round( memory_get_peak_usage( true ) / 1048576, 1 ),
        ] ), [ 'id' => $log_id ] );
    }

    public static function get_recent_logs( int $feed_id = 0, int $limit = 20 ): array {
        global $wpdb;
        $where = $feed_id ? $wpdb->prepare( 'WHERE l.feed_id = %d', $feed_id ) : '';
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT l.*, f.label as feed_label FROM " . self::log_table() . " l
             JOIN " . self::feed_table() . " f ON l.feed_id = f.id
             $where ORDER BY l.started_at DESC LIMIT %d", $limit
        ) ) ?: [];
    }

    public static function get_field_maps( int $feed_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::field_map_table() . ' WHERE feed_id = %d AND active = 1', $feed_id
        ) ) ?: [];
    }

    public static function save_field_map( array $data ): void {
        global $wpdb;
        $table  = self::field_map_table();
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE feed_id = %d AND mls_field = %s", $data['feed_id'], $data['mls_field']
        ) );
        $exists
            ? $wpdb->update( $table, $data, [ 'feed_id' => $data['feed_id'], 'mls_field' => $data['mls_field'] ] )
            : $wpdb->insert( $table, $data );
    }
}
