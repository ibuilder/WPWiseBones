<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Scheduler — WP-Cron schedule management per feed.
 */
class PWM_Scheduler {

    public static function init(): void {
        add_filter( 'cron_schedules', [ __CLASS__, 'add_intervals' ] );
        // Only register add_action() hooks so WP-Cron can call them — do NOT
        // clear/reschedule on every page load. Actual scheduling happens at
        // activation and when a feed is saved.
        self::register_hooks();
    }

    public static function register_hooks(): void {
        if ( ! class_exists( 'PWM_DB' ) ) return;
        foreach ( PWM_DB::get_feeds() as $feed ) {
            // Scheduled recurring import
            $hook = 'pwm_run_import_' . $feed->id;
            add_action( $hook, function () use ( $feed ) {
                PWM_Importer::run( (int) $feed->id );
            } );
            // One-shot "run now" import (triggered from admin AJAX)
            $now_hook = 'pwm_run_import_now_' . $feed->id;
            add_action( $now_hook, function () use ( $feed ) {
                PWM_Importer::run( (int) $feed->id );
            } );
        }
    }

    public static function add_intervals( array $schedules ): array {
        $schedules['every_6_hours']  = [ 'interval' => 6  * HOUR_IN_SECONDS, 'display' => 'Every 6 Hours'  ];
        $schedules['every_12_hours'] = [ 'interval' => 12 * HOUR_IN_SECONDS, 'display' => 'Every 12 Hours' ];
        $schedules['weekly']         = [ 'interval' => WEEK_IN_SECONDS,       'display' => 'Once a Week'    ];
        return $schedules;
    }

    public static function frequency_map(): array {
        return [
            'hourly'     => 'hourly',
            '6hours'     => 'every_6_hours',
            '12hours'    => 'every_12_hours',
            'twicedaily' => 'twicedaily',
            'daily'      => 'daily',
            'weekly'     => 'weekly',
            'manual'     => null,
        ];
    }

    // Called at activation and after a feed is saved/deleted — not on every page load.
    public static function sync_schedules(): void {
        if ( ! class_exists( 'PWM_DB' ) ) return;
        foreach ( PWM_DB::get_feeds() as $feed ) {
            self::schedule_feed( $feed );
        }
    }

    public static function schedule_feed( object $feed ): void {
        $hook = 'pwm_run_import_' . $feed->id;
        wp_clear_scheduled_hook( $hook );
        if ( ! $feed->active ) return;

        $freq_map   = self::frequency_map();
        $recurrence = $freq_map[ $feed->schedule_frequency ] ?? 'daily';
        if ( $recurrence === null ) return;

        $tz       = wp_timezone();
        $now      = new DateTime( 'now', $tz );
        [$h, $m]  = array_map( 'intval', explode( ':', $feed->schedule_time ?: '02:00' ) );
        $next     = new DateTime( 'today', $tz );
        $next->setTime( $h, $m, 0 );
        if ( $next <= $now ) $next->modify( '+1 day' );

        add_action( $hook, function () use ( $feed ) {
            PWM_Importer::run( (int) $feed->id );
        } );
        wp_schedule_event( $next->getTimestamp(), $recurrence, $hook );
    }

    public static function clear_schedules(): void {
        if ( ! class_exists( 'PWM_DB' ) ) return;
        foreach ( PWM_DB::get_feeds() as $feed ) {
            wp_clear_scheduled_hook( 'pwm_run_import_' . $feed->id );
        }
    }

    public static function next_run_time( int $feed_id ): ?string {
        $ts = wp_next_scheduled( 'pwm_run_import_' . $feed_id );
        if ( ! $ts ) return null;
        return get_date_from_gmt( gmdate( 'Y-m-d H:i:s', $ts ), 'M j, Y g:i a' );
    }
}
