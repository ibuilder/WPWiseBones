<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_FieldMap — maps raw MLS fields to RealWise DB columns.
 */
class PWM_FieldMap {

    private array $map = [];

    public static function reso_defaults(): array {
        return [
            'ListingId'               => [ 'column' => 'mls_id',           'transform' => 'string'    ],
            'ListingKey'              => [ 'column' => 'mls_id',           'transform' => 'string',   'priority' => 2 ],
            'MlsStatus'               => [ 'column' => 'status',           'transform' => 'lowercase' ],
            'StandardStatus'          => [ 'column' => 'status',           'transform' => 'lowercase', 'priority' => 2 ],
            'ListPrice'               => [ 'column' => 'list_price',       'transform' => 'float'     ],
            'UnparsedAddress'         => [ 'column' => 'address',          'transform' => 'string'    ],
            'StreetName'              => [ 'column' => 'address',          'transform' => 'string',   'priority' => 2 ],
            'City'                    => [ 'column' => 'city',             'transform' => 'string'    ],
            'StateOrProvince'         => [ 'column' => 'state',            'transform' => 'uppercase' ],
            'PostalCode'              => [ 'column' => 'zip_code',         'transform' => 'string'    ],
            'CountyOrParish'          => [ 'column' => 'county',           'transform' => 'string'    ],
            'Latitude'                => [ 'column' => 'latitude',         'transform' => 'float'     ],
            'Longitude'               => [ 'column' => 'longitude',        'transform' => 'float'     ],
            'BedroomsTotal'           => [ 'column' => 'bedrooms',         'transform' => 'int'       ],
            'BathroomsTotalInteger'   => [ 'column' => 'bathrooms',        'transform' => 'float'     ],
            'BathroomsFull'           => [ 'column' => 'bathrooms',        'transform' => 'float',    'priority' => 2 ],
            'LivingArea'              => [ 'column' => 'sqft',             'transform' => 'int'       ],
            'LotSizeSquareFeet'       => [ 'column' => 'lot_sqft',         'transform' => 'float'     ],
            'YearBuilt'               => [ 'column' => 'year_built',       'transform' => 'int'       ],
            'GarageSpaces'            => [ 'column' => 'garage_spaces',    'transform' => 'int'       ],
            'PoolPrivateYN'           => [ 'column' => 'pool',             'transform' => 'bool'      ],
            'AssociationFee'          => [ 'column' => 'hoa_fee',          'transform' => 'float'     ],
            'TaxAnnualAmount'         => [ 'column' => 'property_taxes',   'transform' => 'float'     ],
            'FloodZone'               => [ 'column' => 'flood_zone',       'transform' => 'string'    ],
            'Zoning'                  => [ 'column' => 'zoning',           'transform' => 'string'    ],
            'CapRate'                 => [ 'column' => 'cap_rate',         'transform' => 'float'     ],
            'NetOperatingIncome'      => [ 'column' => 'noi',              'transform' => 'float'     ],
            'NumberOfUnitsTotal'      => [ 'column' => 'num_units',        'transform' => 'int'       ],
            'PublicRemarks'           => [ 'column' => 'description',      'transform' => 'string'    ],
            'VirtualTourURLUnbranded' => [ 'column' => 'virtual_tour',     'transform' => 'string'    ],
            'Media'                   => [ 'column' => 'photos',           'transform' => 'json'      ],
            'DaysOnMarket'            => [ 'column' => 'days_on_market',   'transform' => 'int'       ],
            'CumulativeDaysOnMarket'  => [ 'column' => 'days_on_market',   'transform' => 'int',      'priority' => 2 ],
            'ListAgentEmail'          => [ 'column' => '_agent_email',     'transform' => 'email'     ],
            'ListAgentFullName'       => [ 'column' => '_agent_name',      'transform' => 'string'    ],
            'ListAgentDirectPhone'    => [ 'column' => '_agent_phone',     'transform' => 'string'    ],
            'ListOfficeName'          => [ 'column' => '_agent_brokerage', 'transform' => 'string'    ],
            'ListAgentStateLicense'   => [ 'column' => '_agent_license',   'transform' => 'string'    ],
        ];
    }

    /** Build an instance from the RESO defaults only (no per-feed overrides, no DB). */
    public static function defaults(): self {
        $inst = new self();
        $inst->map = self::reso_defaults();
        return $inst;
    }

    public static function build( object $feed ): self {
        $map      = self::reso_defaults();
        $overrides = PWM_DB::get_field_maps( (int) $feed->id );
        foreach ( $overrides as $row ) {
            if ( ! $row->active ) continue;
            $map[ $row->mls_field ] = [
                'column'    => $row->pw_column,
                'transform' => $row->transform ?: 'string',
            ];
        }
        $inst      = new self();
        $inst->map = $map;
        return $inst;
    }

    public function transform( array $raw, string $asset_type ): array {
        // When the feed streams every type at once (CSV / Demo / "all"), derive
        // the real asset type from the record's PropertyType instead of "all".
        if ( $asset_type === 'all' || $asset_type === '' ) {
            $asset_type = self::derive_asset_type( $raw );
        }
        $out     = [ 'asset_type' => $asset_type, 'pulled_at' => current_time( 'mysql' ) ];
        $written = [];

        foreach ( $this->map as $mls_field => $spec ) {
            if ( ! array_key_exists( $mls_field, $raw ) ) continue;
            $column   = $spec['column'];
            $priority = $spec['priority'] ?? 1;
            if ( isset( $written[$column] ) && $written[$column] < $priority ) continue;
            $value = self::apply_transform( $raw[$mls_field], $spec['transform'] );
            if ( $value === null && $spec['transform'] !== 'bool' ) continue;
            $out[$column]     = $value;
            $written[$column] = $priority;
        }

        // Agent upsert
        if ( ! empty( $out['_agent_email'] ) || ! empty( $out['_agent_name'] ) ) {
            $agent_data = array_filter( [
                'name'        => $out['_agent_name']      ?? '',
                'email'       => $out['_agent_email']     ?? null,
                'phone'       => $out['_agent_phone']     ?? null,
                'brokerage'   => $out['_agent_brokerage'] ?? null,
                'license_num' => $out['_agent_license']   ?? null,
            ], fn($v) => $v !== null && $v !== '' );
            if ( class_exists('PWL_DB') && $agent_data ) {
                $out['agent_id'] = PWL_DB::upsert_agent( $agent_data );
            }
        }
        foreach ( array_keys( $out ) as $k ) {
            if ( str_starts_with( $k, '_agent_' ) ) unset( $out[$k] );
        }
        return $out;
    }

    /**
     * Map a raw record's PropertyType (RESO names, Spark codes, or free text)
     * to a RealWise asset type. Used when a feed imports all types at once.
     */
    public static function derive_asset_type( array $raw ): string {
        $pt  = strtolower( (string) ( $raw['PropertyType'] ?? $raw['PropertySubType'] ?? '' ) );
        $sub = strtolower( (string) ( $raw['PropertySubType'] ?? '' ) );

        // Spark single-letter property-type codes
        $codes = [ 'a' => 'residential', 'b' => 'multifamily', 'c' => 'commercial', 'd' => 'commercial', 'e' => 'land', 'f' => 'land' ];
        if ( isset( $codes[ $pt ] ) ) return $codes[ $pt ];

        if ( str_contains( $sub, 'industrial' ) )            return 'industrial';
        if ( str_contains( $pt, 'income' ) || str_contains( $sub, 'multi' ) ) return 'multifamily';
        if ( str_contains( $pt, 'land' ) || str_contains( $pt, 'lot' ) )      return 'land';
        if ( str_contains( $pt, 'commercial' ) || str_contains( $pt, 'business' ) ) return 'commercial';
        if ( str_contains( $sub, 'aviation' ) || str_contains( $sub, 'hangar' ) )   return 'aviation';
        return 'residential';
    }

    private static function apply_transform( $value, string $transform ) {
        return match ( $transform ) {
            'string'    => is_array($value) ? implode(' ', $value) : sanitize_text_field( (string) $value ),
            'float'     => is_numeric($value) ? (float) $value : null,
            'int'       => is_numeric($value) ? (int)   $value : null,
            'bool'      => in_array( strtolower((string)$value), ['true','yes','1','y'] ),
            'lowercase' => strtolower( trim( (string) $value ) ),
            'uppercase' => strtoupper( trim( (string) $value ) ),
            'email'     => is_email($value) ? sanitize_email($value) : null,
            'json'      => is_array($value) ? wp_json_encode($value) : (string) $value,
            'json_first'=> is_array($value) ? ($value[0] ?? null) : $value,
            default     => sanitize_text_field( (string) $value ),
        };
    }
}
