<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * PWM_Updater — delivers automatic updates for the commercial RealWise MLS plugin
 * from the store (PWM_STORE_URL) instead of the WordPress.org directory.
 *
 * Implements the EDD Software Licensing "get_version" handshake: it injects the
 * remote version into WordPress's update transient and serves the plugin-info
 * popup, passing the license key so the download is authorized. Without a valid
 * license the store returns no package, so updates simply don't appear.
 */
class PWM_Updater {

    private string $file;     // plugin basename, e.g. realwise-mls/realwise-mls.php
    private string $slug;     // realwise-mls
    private string $version;
    private string $store;
    private string $item_name;

    public function __construct( string $plugin_file, string $version, string $store_url, string $item_name ) {
        $this->file      = plugin_basename( $plugin_file );
        $this->slug      = dirname( $this->file );
        $this->version   = $version;
        $this->store     = $store_url;
        $this->item_name = $item_name;

        add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'check_update' ] );
        add_filter( 'plugins_api',                           [ $this, 'plugins_api' ], 10, 3 );
        add_action( "after_plugin_row_{$this->file}",        [ $this, 'maybe_unlicensed_row' ], 10, 2 );
    }

    /** Cached remote version payload (12h) to avoid hammering the store. */
    private function remote(): ?object {
        $cache_key = 'pwm_update_' . md5( $this->item_name . $this->version );
        $cached = get_transient( $cache_key );
        if ( $cached !== false ) {
            return $cached === 'none' ? null : $cached;
        }
        $resp = wp_remote_post(
            $this->store,
            [
                'timeout'   => 15,
                'sslverify' => true,
                'body'      => [
                    'edd_action' => 'get_version',
                    'license'    => PWM_License::key(),
                    'item_name'  => rawurlencode( $this->item_name ),
                    'url'        => home_url(),
                    'version'    => $this->version,
                ],
            ]
        );
        if ( is_wp_error( $resp ) || wp_remote_retrieve_response_code( $resp ) !== 200 ) {
            set_transient( $cache_key, 'none', HOUR_IN_SECONDS );
            return null;
        }
        $data = json_decode( wp_remote_retrieve_body( $resp ) );
        if ( ! is_object( $data ) ) {
            set_transient( $cache_key, 'none', HOUR_IN_SECONDS );
            return null;
        }
        // EDD returns `sections`/`banners` as JSON-encoded strings.
        if ( isset( $data->sections ) ) $data->sections = (array) json_decode( $data->sections, true );
        if ( isset( $data->banners ) )  $data->banners  = (array) json_decode( $data->banners, true );
        set_transient( $cache_key, $data, 12 * HOUR_IN_SECONDS );
        return $data;
    }

    /** Inject an available update into the plugins update transient. */
    public function check_update( $transient ) {
        if ( ! is_object( $transient ) ) return $transient;
        $remote = $this->remote();
        if ( ! $remote || empty( $remote->new_version ) ) return $transient;

        if ( version_compare( $this->version, $remote->new_version, '<' ) ) {
            $item = (object) [
                'id'          => $this->file,
                'slug'        => $this->slug,
                'plugin'      => $this->file,
                'new_version' => $remote->new_version,
                'url'         => $remote->homepage ?? $this->store,
                'package'     => $remote->package ?? '', // empty when unlicensed → no auto-install
                'tested'      => $remote->tested ?? '',
                'requires'    => $remote->requires ?? '',
            ];
            if ( empty( $item->package ) ) {
                $transient->response[ $this->file ] = $item; // shows "update available" but links to renew
            } else {
                $transient->response[ $this->file ] = $item;
            }
        } else {
            $transient->no_update[ $this->file ] = (object) [
                'id' => $this->file, 'slug' => $this->slug, 'plugin' => $this->file,
                'new_version' => $this->version,
            ];
        }
        return $transient;
    }

    /** Serve the "View details" popup from the store. */
    public function plugins_api( $result, $action, $args ) {
        if ( $action !== 'plugin_information' || empty( $args->slug ) || $args->slug !== $this->slug ) {
            return $result;
        }
        $remote = $this->remote();
        if ( ! $remote ) return $result;
        return (object) [
            'name'          => $this->item_name,
            'slug'          => $this->slug,
            'version'       => $remote->new_version ?? $this->version,
            'author'        => '<a href="' . esc_url( $this->store ) . '">RealWise</a>',
            'homepage'      => $remote->homepage ?? $this->store,
            'requires'      => $remote->requires ?? '',
            'tested'        => $remote->tested ?? '',
            'download_link' => $remote->package ?? '',
            'sections'      => $remote->sections ?? [ 'description' => '' ],
            'banners'       => $remote->banners ?? [],
        ];
    }

    /** When unlicensed, append a renew prompt under the plugin row. */
    public function maybe_unlicensed_row( $plugin_file, $plugin_data ): void {
        if ( PWM_License::is_valid() ) return;
        $remote = $this->remote();
        if ( ! $remote || empty( $remote->new_version ) || version_compare( $this->version, $remote->new_version, '>=' ) ) return;
        printf(
            '<tr class="plugin-update-tr active"><td colspan="4" class="plugin-update colspanchange"><div class="update-message notice inline notice-warning notice-alt"><p>%s <a href="%s">%s</a></p></div></td></tr>',
            esc_html__( 'A new version of RealWise MLS is available. Activate your license to install it.', 'realwise-mls' ),
            esc_url( admin_url( 'admin.php?page=pwm-license' ) ),
            esc_html__( 'Enter license key', 'realwise-mls' )
        );
    }
}
