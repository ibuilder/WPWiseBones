<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_RESO — generic RESO Web API (OData v4) client.
 *
 * This is the workhorse adapter. The RESO Web API is the modern industry
 * standard and is spoken by the large majority of MLS data sources — Bridge
 * Interactive, CoreLogic Trestle, MLS Grid, Paragon/ICE, Rapattoni,
 * Constellation1, and most MLSs that expose a direct RESO endpoint. Vendors
 * differ mainly in base URL and authentication, which this adapter handles via
 * three auth modes plus a token cache.
 *
 * Auth modes (feed.extra_params JSON "auth_mode", or per-vendor preset):
 *   bearer       Authorization: Bearer {api_key}          (MLS Grid, Trestle token)
 *   query_token  ?access_token={api_key}                  (Bridge Interactive)
 *   oauth2       client_credentials grant → bearer token  (Trestle, Paragon, Constellation1)
 *
 * extra_params (JSON) recognised keys:
 *   auth_mode      override the preset
 *   token_url      OAuth2 token endpoint (for oauth2)
 *   scope          OAuth2 scope
 *   resource       OData resource set (default "Property")
 *   odata_filter   extra $filter clause AND-ed in
 *   page_size      override per-page
 *   media_expand   expand expression for photos (default "Media")
 */
class PWM_Adapter_RESO extends PWM_Adapter_Base {

    /** Per-vendor defaults; overridden by subclasses. */
    protected string $default_base   = '';
    protected string $default_auth   = 'bearer';
    protected string $default_token_url = '';

    protected function cfg(): array {
        $extra = json_decode( $this->feed->extra_params ?: '{}', true ) ?: [];
        return [
            'auth_mode'   => $extra['auth_mode']   ?? $this->default_auth,
            'token_url'   => $extra['token_url']   ?? $this->default_token_url,
            'scope'       => $extra['scope']       ?? '',
            'resource'    => $extra['resource']    ?? 'Property',
            'odata_filter'=> $extra['odata_filter']?? '',
            'media_expand'=> $extra['media_expand']?? 'Media',
            'page_size'   => (int) ( $extra['page_size'] ?? 0 ),
        ];
    }

    protected function base_url(): string {
        return rtrim( $this->feed->base_url ?: $this->default_base, '/' );
    }

    public function supported_asset_types(): array {
        // RESO Data Dictionary PropertyType enumerations.
        return [
            'residential' => "PropertyType eq 'Residential'",
            'commercial'  => "PropertyType eq 'Commercial Sale'",
            'industrial'  => "PropertyType eq 'Commercial Sale' and PropertySubType eq 'Industrial'",
            'land'        => "PropertyType eq 'Land'",
            'multifamily' => "PropertyType eq 'Residential Income'",
            'aviation'    => "PropertyType eq 'Commercial Sale' and PropertySubType eq 'Special Purpose'",
        ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $cfg  = $this->cfg();
        $size = $cfg['page_size'] ?: $per_page;
        $base = $this->base_url();
        if ( ! $base ) throw new \RuntimeException( esc_html(  __( 'No base URL configured for the RESO feed.', 'realwise-mls' )  ) );

        // Build $filter
        $clauses = [];
        $type_filter = $this->supported_asset_types()[ $asset_type ] ?? '';
        if ( $type_filter ) $clauses[] = '(' . $type_filter . ')';
        // Active listings only, unless caller filters otherwise
        $clauses[] = "StandardStatus eq 'Active'";
        if ( $cfg['odata_filter'] ) $clauses[] = '(' . $cfg['odata_filter'] . ')';
        if ( $zips = $this->zip_filter() ) $clauses[] = $zips;

        $params = [
            '$top'   => $size,
            '$skip'  => ( $page - 1 ) * $size,
            '$count' => 'true',
            '$orderby' => 'ModificationTimestamp desc',
        ];
        if ( $clauses ) $params['$filter'] = implode( ' and ', $clauses );
        if ( $cfg['media_expand'] ) $params['$expand'] = $cfg['media_expand'];

        $url  = $base . '/' . ltrim( $cfg['resource'], '/' );
        $data = $this->get( $url, $params );

        // OData payload: { value: [...], @odata.nextLink: ... }
        return $data['value'] ?? $data['D']['Results'] ?? [];
    }

    /** Append a RESO PostalCode filter from the feed's ZIP list. */
    protected function zip_filter(): string {
        if ( empty( $this->feed->filter_zips ) ) return '';
        $zips = array_filter( array_map( 'trim', explode( "\n", $this->feed->filter_zips ) ) );
        $zips = array_slice( $zips, 0, 50 );
        if ( ! $zips ) return '';
        $ors = array_map( fn( $z ) => "PostalCode eq '" . str_replace( "'", '', $z ) . "'", $zips );
        return '(' . implode( ' or ', $ors ) . ')';
    }

    protected function auth_headers(): array {
        $cfg = $this->cfg();
        switch ( $cfg['auth_mode'] ) {
            case 'oauth2':
                $token = $this->oauth2_token();
                return [ 'Authorization' => 'Bearer ' . $token, 'Accept' => 'application/json' ];
            case 'query_token':
                return [ 'Accept' => 'application/json' ]; // token added to URL below
            case 'bearer':
            default:
                return [ 'Authorization' => 'Bearer ' . $this->feed->api_key, 'Accept' => 'application/json' ];
        }
    }

    /**
     * Override get() to inject the access_token query param for query_token mode.
     */
    protected function get( string $url, array $params = [] ): array {
        if ( $this->cfg()['auth_mode'] === 'query_token' ) {
            $params['access_token'] = $this->feed->api_key;
        }
        return parent::get( $url, $params );
    }

    /**
     * OAuth2 client_credentials grant. Token cached in a transient until ~expiry.
     */
    protected function oauth2_token(): string {
        $cfg = $this->cfg();
        if ( ! $cfg['token_url'] ) {
            throw new \RuntimeException( esc_html(  __( 'OAuth2 selected but no token_url configured in extra_params.', 'realwise-mls' )  ) );
        }
        $cache_key = 'pwm_oauth_' . md5( $this->feed->id . '|' . $cfg['token_url'] );
        $cached    = get_transient( $cache_key );
        if ( $cached ) return $cached;

        $body = [
            'grant_type'    => 'client_credentials',
            'client_id'     => $this->feed->api_key,
            'client_secret' => $this->feed->api_secret,
        ];
        if ( $cfg['scope'] ) $body['scope'] = $cfg['scope'];

        $resp = wp_remote_post( $cfg['token_url'], [
            'timeout' => 20,
            'headers' => [ 'Accept' => 'application/json', 'Content-Type' => 'application/x-www-form-urlencoded' ],
            'body'    => $body,
        ] );
        if ( is_wp_error( $resp ) ) throw new \RuntimeException( esc_html(  'OAuth2: ' . $resp->get_error_message()  ) );
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( empty( $data['access_token'] ) ) {
            throw new \RuntimeException( esc_html(  __( 'OAuth2 token request failed — check client id/secret and scope.', 'realwise-mls' )  ) );
        }
        $ttl = max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 60 );
        set_transient( $cache_key, $data['access_token'], $ttl );
        return $data['access_token'];
    }
}
