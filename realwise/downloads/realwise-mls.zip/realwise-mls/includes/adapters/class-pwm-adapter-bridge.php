<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_Bridge — Bridge Interactive (bridgedataoutput.com)
 * RESO Web API. Auth: access_token query param.
 * Docs: https://bridgedataoutput.com/docs
 */
class PWM_Adapter_Bridge extends PWM_Adapter_Base {

    public function supported_asset_types(): array {
        return [
            'residential' => [ 'PropertyType' => 'Residential' ],
            'commercial'  => [ 'PropertyType' => 'Commercial Sale' ],
            'industrial'  => [ 'PropertyType' => 'Commercial Sale', 'PropertySubType' => 'Industrial' ],
            'land'        => [ 'PropertyType' => 'Land' ],
            'multifamily' => [ 'PropertyType' => 'Residential', 'PropertySubType' => 'Multi Family' ],
            'aviation'    => [ 'PropertyType' => 'Commercial Sale', 'PropertySubType' => 'Special Purpose' ],
        ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $base    = rtrim( $this->feed->base_url ?: 'https://api.bridgedataoutput.com/api/v2/OData/test', '/' );
        $filters = $this->supported_asset_types()[ $asset_type ] ?? [];
        $extra   = json_decode( $this->feed->extra_params ?: '{}', true );

        $params = array_merge( [
            'access_token' => $this->feed->api_key,
            'limit'        => $per_page,
            'offset'       => ( $page - 1 ) * $per_page,
            'MlsStatus'    => 'Active',
        ], $filters, $extra );

        if ( ! empty( $this->feed->filter_zips ) ) {
            $zips = array_filter( array_map( 'trim', explode( "\n", $this->feed->filter_zips ) ) );
            if ( $zips ) $params['PostalCode'] = implode( ',', array_slice( $zips, 0, 50 ) );
        }

        $data = $this->get( "$base/listings", $params );
        return $data['bundle'] ?? $data['value'] ?? [];
    }
}
