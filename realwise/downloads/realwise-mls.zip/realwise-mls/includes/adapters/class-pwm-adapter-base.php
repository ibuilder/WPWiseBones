<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_Base — abstract base for all MLS adapters.
 */
abstract class PWM_Adapter_Base {

    protected object $feed;

    public function __construct( object $feed ) {
        $this->feed = $feed;
    }

    abstract public function fetch_page( string $asset_type, int $page, int $per_page ): array;
    abstract public function supported_asset_types(): array;

    protected function get( string $url, array $params = [] ): array {
        if ( $params ) $url = add_query_arg( $params, $url );
        $response = wp_remote_get( $url, [ 'timeout' => 30, 'headers' => $this->auth_headers() ] );
        if ( is_wp_error( $response ) ) {
            throw new \RuntimeException( esc_html(  'HTTP error: ' . $response->get_error_message()  ) );
        }
        $code = wp_remote_retrieve_response_code( $response );
        if ( $code === 401 ) throw new \RuntimeException( esc_html(  'Authentication failed — check API key.'  ) );
        if ( $code >= 400 ) throw new \RuntimeException( esc_html(  "HTTP $code fetching $url"  ) );
        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( json_last_error() !== JSON_ERROR_NONE ) {
            throw new \RuntimeException( esc_html(  'Invalid JSON response from vendor.'  ) );
        }
        return $body;
    }

    protected function auth_headers(): array {
        return [];
    }
}
