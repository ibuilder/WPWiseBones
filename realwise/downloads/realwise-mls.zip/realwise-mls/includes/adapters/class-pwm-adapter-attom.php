<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_ATTOM — ATTOM Data Solutions API
 * Docs: https://api.developer.attomdata.com/
 * Feed api_key = ATTOM API key (sent as apikey header).
 */
class PWM_Adapter_ATTOM extends PWM_Adapter_Base {

    protected function auth_headers(): array {
        return [ 'apikey' => $this->feed->api_key, 'Accept' => 'application/json' ];
    }

    public function supported_asset_types(): array {
        return [
            'residential' => [ 'propertyType' => 'SFR,CONDO,TWNHS' ],
            'multifamily' => [ 'propertyType' => 'APARTMENT' ],
            'commercial'  => [ 'propertyType' => 'COMMERCIAL' ],
        ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $base   = rtrim( $this->feed->base_url ?: 'https://api.attomdata.com/propertyapi/v1.0.0', '/' );
        $types  = $this->supported_asset_types()[ $asset_type ] ?? [];
        $extra  = json_decode( $this->feed->extra_params ?: '{}', true );
        $params = array_merge( [
            'page'       => $page,
            'pagesize'   => $per_page,
            'statusCode' => 'active',
        ], $types, $extra );
        if ( ! empty( $this->feed->filter_zips ) ) {
            $zips = array_filter( array_map( 'trim', explode( "\n", $this->feed->filter_zips ) ) );
            if ( $zips ) $params['postalcode'] = implode( ',', array_slice( $zips, 0, 10 ) );
        }
        $data = $this->get( "$base/property/expandedprofile", $params );
        return $data['property'] ?? [];
    }
}
