<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_SimplyRETS — SimplyRETS normalized JSON API.
 *
 * SimplyRETS is a popular middleware that normalizes many MLSs into one simple
 * JSON REST API, widely used by small brokerages. Auth is HTTP Basic
 * (api_key = username, api_secret = password). It returns a flat JSON array;
 * fields use a nested shape ({ property: {...}, address: {...}, photos: [...] })
 * that we flatten to RESO-ish names for the shared field map.
 *
 * Docs: https://docs.simplyrets.com/
 */
class PWM_Adapter_SimplyRETS extends PWM_Adapter_Base {

    public function supported_asset_types(): array {
        return [
            'residential' => [ 'type' => 'residential' ],
            'commercial'  => [ 'type' => 'commercial' ],
            'land'        => [ 'type' => 'land' ],
            'multifamily' => [ 'type' => 'multifamily' ],
            'aviation'    => [ 'type' => 'commercial' ],
        ];
    }

    protected function auth_headers(): array {
        $user = $this->feed->api_key;
        $pass = $this->feed->api_secret ?: '';
        return [
            // Standard HTTP Basic auth header (not obfuscation).
            // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
            'Authorization' => 'Basic ' . base64_encode( "$user:$pass" ), // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic Auth header encoding.
            'Accept'        => 'application/json',
        ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $base   = rtrim( $this->feed->base_url ?: 'https://api.simplyrets.com', '/' );
        $filter = $this->supported_asset_types()[ $asset_type ] ?? [];
        $params = [
            'limit'  => min( $per_page, 500 ),
            'offset' => ( $page - 1 ) * min( $per_page, 500 ),
            'status' => 'Active',
        ];
        $params = array_merge( $params, $filter );
        if ( ! empty( $this->feed->filter_zips ) ) {
            $zips = array_filter( array_map( 'trim', explode( "\n", $this->feed->filter_zips ) ) );
            if ( $zips ) $params['postalCodes'] = implode( ',', array_slice( $zips, 0, 50 ) );
        }
        $rows = $this->get( "$base/properties", $params );
        return array_map( [ $this, 'normalise' ], (array) $rows );
    }

    protected function normalise( array $r ): array {
        $addr  = $r['address']  ?? [];
        $prop  = $r['property'] ?? [];
        $geo   = $r['geo']      ?? [];
        $agent = $r['agent']    ?? [];

        $media = [];
        foreach ( (array) ( $r['photos'] ?? [] ) as $u ) {
            if ( $u ) $media[] = [ 'MediaURL' => $u ];
        }

        return [
            'ListingId'             => $r['mlsId'] ?? $r['listingId'] ?? '',
            'StandardStatus'        => $r['mls']['status'] ?? 'Active',
            'ListPrice'             => $r['listPrice'] ?? null,
            'UnparsedAddress'       => trim( ( $addr['streetNumber'] ?? '' ) . ' ' . ( $addr['streetName'] ?? '' ) ),
            'City'                  => $addr['city'] ?? '',
            'StateOrProvince'       => $addr['state'] ?? '',
            'PostalCode'            => $addr['postalCode'] ?? '',
            'Latitude'              => $geo['lat'] ?? null,
            'Longitude'             => $geo['lng'] ?? null,
            'BedroomsTotal'         => $prop['bedrooms'] ?? null,
            'BathroomsTotalInteger' => $prop['bathsFull'] ?? null,
            'LivingArea'            => $prop['area'] ?? null,
            'LotSizeSquareFeet'     => $prop['lotSize'] ?? null,
            'YearBuilt'             => $prop['yearBuilt'] ?? null,
            'PublicRemarks'         => $r['remarks'] ?? '',
            'PropertyType'          => $prop['type'] ?? '',
            'DaysOnMarket'          => $r['mls']['daysOnMarket'] ?? null,
            'ListAgentFullName'     => $agent['firstName'] ?? '' ? trim( ( $agent['firstName'] ?? '' ) . ' ' . ( $agent['lastName'] ?? '' ) ) : '',
            'ListAgentEmail'        => $agent['contact']['email'] ?? null,
            'Media'                 => $media,
        ];
    }
}
