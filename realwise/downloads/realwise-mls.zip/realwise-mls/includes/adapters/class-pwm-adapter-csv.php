<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_CSV — import listings from a CSV/TSV file.
 *
 * Many MLSs and IDX vendors deliver data as a nightly downloadable file (CSV)
 * rather than a live API — FlexMLS "IDX data feeds", RETS exports, and most
 * back-office exports all produce CSV. This adapter reads such a file from a
 * URL (base_url) or a server path (extra_params "path"), maps its columns with
 * the feed's field map, and pages through the rows.
 *
 * extra_params (JSON):
 *   path        absolute server path to a local file (alternative to base_url)
 *   delimiter   field delimiter (default ",", use "\t" for TSV)
 *   id_column   header name of the unique id column (default tries common names)
 *
 * The file's header row supplies the field names; map them to RealWise columns
 * under Field Maps just like an API feed. RESO and common export headers
 * (ListingId, ListPrice, City, …) work out of the box.
 */
class PWM_Adapter_CSV extends PWM_Adapter_Base {

    private ?array $rows = null;

    public function supported_asset_types(): array {
        // CSV has no server-side filtering; one pass returns everything and the
        // field map's asset_type is applied per row by the importer.
        return [ 'all' => [] ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $this->load();
        // CSV is fetched once; only serve rows on the first asset-type/page so we
        // don't import duplicates when the importer loops asset types.
        if ( $asset_type !== 'all' && $asset_type !== array_key_first( $this->effective_asset_types() ) ) {
            return [];
        }
        $offset = ( $page - 1 ) * $per_page;
        return array_slice( $this->rows, $offset, $per_page );
    }

    /** When the feed limits asset types, only the first one streams the file. */
    private function effective_asset_types(): array {
        $t = $this->feed->asset_types === 'all' ? [ 'all' => [] ]
           : array_fill_keys( array_map( 'trim', explode( ',', $this->feed->asset_types ) ), [] );
        return $t ?: [ 'all' => [] ];
    }

    private function cfg(): array {
        $e = json_decode( $this->feed->extra_params ?: '{}', true ) ?: [];
        return [
            'path'      => $e['path'] ?? '',
            'delimiter' => $e['delimiter'] ?? ',',
            'id_column' => $e['id_column'] ?? '',
        ];
    }

    private function load(): void {
        if ( $this->rows !== null ) return;
        $cfg = $this->cfg();
        $delim = $cfg['delimiter'] === '\\t' ? "\t" : ( $cfg['delimiter'] ?: ',' );

        $contents = '';
        if ( $cfg['path'] ) {
            // Local file: must live under uploads for safety. Read via WP_Filesystem.
            $uploads = wp_get_upload_dir();
            $real    = realpath( $cfg['path'] );
            if ( ! $real || strpos( $real, realpath( $uploads['basedir'] ) ) !== 0 ) {
                throw new \RuntimeException( esc_html(  __( 'CSV path must be inside the uploads directory.', 'realwise-mls' )  ) );
            }
            global $wp_filesystem;
            if ( ! function_exists( 'WP_Filesystem' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            WP_Filesystem();
            $contents = $wp_filesystem ? $wp_filesystem->get_contents( $real ) : '';
            if ( $contents === false || $contents === '' ) {
                throw new \RuntimeException( esc_html(  __( 'Could not read the CSV file.', 'realwise-mls' )  ) );
            }
        } elseif ( $this->feed->base_url ) {
            $resp = wp_remote_get( $this->feed->base_url, [ 'timeout' => 60, 'headers' => $this->auth_headers() ] );
            if ( is_wp_error( $resp ) ) throw new \RuntimeException( esc_html(  'CSV fetch: ' . $resp->get_error_message()  ) );
            if ( wp_remote_retrieve_response_code( $resp ) >= 400 ) {
                throw new \RuntimeException( esc_html(  'CSV fetch HTTP ' . wp_remote_retrieve_response_code( $resp )  ) );
            }
            $contents = wp_remote_retrieve_body( $resp );
        } else {
            throw new \RuntimeException( esc_html(  __( 'No CSV source: set base_url or extra_params.path.', 'realwise-mls' )  ) );
        }

        $this->rows = $this->parse( $contents, $delim );
    }

    /** Optional Basic auth on the file URL via api_key:api_secret. */
    protected function auth_headers(): array {
        if ( $this->feed->api_key ) {
            // base64_encode here builds a standard HTTP Basic auth header, not obfuscation.
            // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
            return [ 'Authorization' => 'Basic ' . base64_encode( $this->feed->api_key . ':' . ( $this->feed->api_secret ?: '' ) ) ]; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic Auth header encoding.
        }
        return [];
    }

    private function parse( string $contents, string $delim ): array {
        $contents = preg_replace( "/^\xEF\xBB\xBF/", '', $contents ); // strip BOM
        $lines    = preg_split( '/\r\n|\r|\n/', $contents );
        $rows     = [];
        $header   = null;
        foreach ( $lines as $line ) {
            if ( $line === '' ) continue;
            $cells = str_getcsv( $line, $delim );
            if ( $header === null ) { $header = $cells; continue; }
            if ( count( $cells ) === 1 && $cells[0] === '' ) continue;
            $row = [];
            foreach ( $header as $i => $name ) {
                $row[ trim( $name ) ] = $cells[ $i ] ?? '';
            }
            $rows[] = $row;
        }
        return $rows;
    }
}
