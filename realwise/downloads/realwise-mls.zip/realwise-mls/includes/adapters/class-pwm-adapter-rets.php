<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_RETS — Legacy RETS protocol adapter.
 *
 * Requires: composer require troydavisson/phrets in the plugin directory.
 *
 * Feed fields:
 *   base_url     = RETS login URL
 *   api_key      = RETS username
 *   api_secret   = RETS password
 *   extra_params = JSON: { "rets_version":"RETS/1.7.2", "res_class":"ResidentialProperty", ... }
 */
class PWM_Adapter_RETS extends PWM_Adapter_Base {

    public function supported_asset_types(): array {
        $extra = json_decode( $this->feed->extra_params ?: '{}', true );
        return [
            'residential' => [ 'class' => $extra['res_class']   ?? 'ResidentialProperty' ],
            'commercial'  => [ 'class' => $extra['comm_class']  ?? 'CommercialProperty'  ],
            'land'        => [ 'class' => $extra['land_class']  ?? 'LandProperty'        ],
            'multifamily' => [ 'class' => $extra['multi_class'] ?? 'MultiFamily'         ],
        ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $vendor_dir = PWM_DIR . 'vendor/autoload.php';
        if ( ! file_exists( $vendor_dir ) ) {
            // Surface a clear admin notice rather than an uncaught exception
            add_action( 'admin_notices', function () {
                echo '<div class="notice notice-warning"><p>'
                    . '<strong>RealWise MLS Connect — RETS Adapter:</strong> The phRETS library is not installed. '
                    . 'Run <code>composer require troydavisson/phrets</code> in <code>'
                    . esc_html( PWM_DIR ) . '</code> to enable RETS support.</p></div>';
            } );
            throw new \RuntimeException( esc_html( 
                'RETS adapter requires phRETS. Run: composer require troydavisson/phrets in ' . PWM_DIR
             ) );
        }
        require_once $vendor_dir;

        $extra  = json_decode( $this->feed->extra_params ?: '{}', true );
        $class  = $this->supported_asset_types()[ $asset_type ]['class'] ?? 'ResidentialProperty';

        $config = new \PHRETS\Configuration();
        $config->setLoginUrl( $this->feed->base_url )
               ->setUsername( $this->feed->api_key )
               ->setPassword( $this->feed->api_secret )
               ->setRetsVersion( $extra['rets_version'] ?? 'RETS/1.7.2' );

        $rets = new \PHRETS\Session( $config );
        $rets->Login();
        $results = $rets->Search( 'Property', $class, '(StandardStatus=Active)', [
            'Limit'  => $per_page,
            'Offset' => ( $page - 1 ) * $per_page,
            'Format' => 'COMPACT-DECODED',
        ] );
        $rets->Disconnect();
        return iterator_to_array( $results );
    }
}
