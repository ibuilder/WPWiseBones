<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_Demo — imports the bundled sample dataset.
 *
 * Lets you try the whole import pipeline (field mapping, scheduling, log,
 * de-listing) with zero credentials. Ships realistic sample listings in both
 * RESO Web API and FlexMLS/Spark shapes so you can preview either format.
 *
 * extra_params (JSON):
 *   format   "reso" (default) or "flexmls"
 */
class PWM_Adapter_Demo extends PWM_Adapter_Base {

    public function supported_asset_types(): array {
        return [ 'all' => [] ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        // Single page — sample set is small.
        if ( $page > 1 ) return [];
        $fmt  = json_decode( $this->feed->extra_params ?: '{}', true )['format'] ?? 'reso';
        $file = PWM_DIR . 'sample-data/' . ( $fmt === 'flexmls' ? 'flexmls-sample.json' : 'reso-sample.json' );
        if ( ! file_exists( $file ) ) {
            throw new \RuntimeException( esc_html(  __( 'Sample data file not found.', 'realwise-mls' )  ) );
        }
        // Reading the plugin's own bundled, read-only sample file (not user content).
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $data = json_decode( file_get_contents( $file ), true ) ?: []; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Reads the plugin-bundled sample-data JSON.

        if ( $fmt === 'flexmls' ) {
            $results = $data['D']['Results'] ?? [];
            return array_map( [ $this, 'flatten_flexmls' ], $results );
        }
        return $data['value'] ?? [];
    }

    private function flatten_flexmls( array $record ): array {
        $sf = $record['StandardFields'] ?? $record;
        $media = [];
        foreach ( (array) ( $sf['Photos'] ?? [] ) as $p ) {
            $url = $p['Uri800'] ?? $p['UriLarge'] ?? '';
            if ( $url ) $media[] = [ 'MediaURL' => $url ];
        }
        if ( isset( $sf['BedsTotal'] ) )  $sf['BedroomsTotal']         = $sf['BedsTotal'];
        if ( isset( $sf['BathsTotal'] ) ) $sf['BathroomsTotalInteger'] = $sf['BathsTotal'];
        $sf['Media'] = $media;
        return $sf;
    }
}
