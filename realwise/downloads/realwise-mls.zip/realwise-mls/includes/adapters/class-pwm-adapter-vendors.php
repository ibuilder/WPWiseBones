<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * Vendor presets that extend the generic RESO Web API adapter.
 *
 * Each preset just sets the default base URL, auth mode, and (for OAuth2) the
 * token endpoint. Everything else — OData paging, filtering, media expansion,
 * the RESO field map — is inherited. Admins can still override base URL and
 * extra_params per feed.
 *
 * Research note on the MLS data landscape:
 *   The RESO Web API (OData v4 + RESO Data Dictionary) is the modern standard
 *   that has largely replaced legacy RETS. The platforms below cover the vast
 *   majority of US/Canada MLS access. FlexMLS is handled by the Spark adapter
 *   (its API is RESTful but not OData). RETS remains for the minority of MLSs
 *   that have not yet migrated.
 */

/** CoreLogic Trestle — RESO Web API, OAuth2 client_credentials. */
class PWM_Adapter_Trestle extends PWM_Adapter_RESO {
    protected string $default_base     = 'https://api-prod.corelogic.com/trestle/odata';
    protected string $default_auth     = 'oauth2';
    protected string $default_token_url = 'https://api-prod.corelogic.com/trestle/oidc/connect/token';
    protected function cfg(): array {
        $c = parent::cfg();
        if ( empty( json_decode( $this->feed->extra_params ?: '{}', true )['scope'] ?? '' ) ) {
            $c['scope'] = 'api';
        }
        return $c;
    }
}

/** MLS Grid — normalized RESO Web API across many MLSs, Bearer token. */
class PWM_Adapter_MLSGrid extends PWM_Adapter_RESO {
    protected string $default_base = 'https://api.mlsgrid.com/v2';
    protected string $default_auth = 'bearer';
    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        // MLS Grid requires OriginatingSystemName-scoped queries and caps $top at 1000.
        return parent::fetch_page( $asset_type, $page, min( $per_page, 1000 ) );
    }
}

/** Paragon / ICE Mortgage Technology (Black Knight) — RESO Web API, OAuth2. */
class PWM_Adapter_Paragon extends PWM_Adapter_RESO {
    protected string $default_base     = 'https://api.paragonapi.com/api/v2/OData';
    protected string $default_auth     = 'oauth2';
    protected string $default_token_url = 'https://api.paragonapi.com/api/v2/oauth/token';
}

/** Rapattoni — RESO Web API, Bearer token. */
class PWM_Adapter_Rapattoni extends PWM_Adapter_RESO {
    protected string $default_base = 'https://webapi.rapmls.com/RESO/OData';
    protected string $default_auth = 'bearer';
}

/** Constellation1 (formerly Real Estate Digital) — RESO Web API, OAuth2. */
class PWM_Adapter_Constellation extends PWM_Adapter_RESO {
    protected string $default_base     = 'https://resoapi.constellation1.com/odata';
    protected string $default_auth     = 'oauth2';
    protected string $default_token_url = 'https://resoapi.constellation1.com/oauth/token';
}
