<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_Spark — Spark Platform API, which powers FlexMLS.
 *
 * FlexMLS (by FBS) exposes its data through the Spark API. The Spark API is
 * RESTful but NOT OData: results are wrapped in a { "D": { "Results": [...] } }
 * envelope and each record nests its fields under a "StandardFields" object,
 * with Spark-specific names (BedsTotal, BathsTotal, Photos[].Uri*). This
 * adapter flattens StandardFields to the top level and normalises Photos into a
 * RESO-style Media array so the shared field map applies cleanly.
 *
 * Docs: https://sparkplatform.com/docs   Auth: OAuth2 bearer or API key.
 */
class PWM_Adapter_Spark extends PWM_Adapter_Base {

    public function supported_asset_types(): array {
        return [
            'residential' => "PropertyType Eq 'A'",        // Spark property-type codes
            'commercial'  => "PropertyType Eq 'C'",
            'land'        => "PropertyType Eq 'F'",
            'multifamily' => "PropertyType Eq 'B'",
            'aviation'    => "PropertyType Eq 'C'",
        ];
    }

    protected function auth_headers(): array {
        return [ 'Authorization' => 'Bearer ' . $this->feed->api_key, 'Accept' => 'application/json' ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $base    = rtrim( $this->feed->base_url ?: 'https://replication.sparkapi.com/v1', '/' );
        $filter  = $this->supported_asset_types()[ $asset_type ] ?? '';
        $params  = [ '_limit' => min( $per_page, 1000 ), '_page' => $page, '_expand' => 'Photos' ];

        $clauses = [ "StandardStatus Eq 'Active'" ];
        if ( $filter ) $clauses[] = $filter;
        if ( $zips = $this->zip_filter() ) $clauses[] = $zips;
        $params['_filter'] = implode( ' And ', $clauses );

        $data    = $this->get( "$base/listings", $params );
        $results = $data['D']['Results'] ?? [];

        // Flatten StandardFields → top level, normalise photos.
        return array_map( [ $this, 'normalise' ], $results );
    }

    protected function zip_filter(): string {
        if ( empty( $this->feed->filter_zips ) ) return '';
        $zips = array_filter( array_map( 'trim', explode( "\n", $this->feed->filter_zips ) ) );
        $zips = array_slice( $zips, 0, 25 );
        if ( ! $zips ) return '';
        $ors = array_map( fn( $z ) => "PostalCode Eq '" . str_replace( "'", '', $z ) . "'", $zips );
        return '(' . implode( ' Or ', $ors ) . ')';
    }

    /**
     * Convert a Spark/FlexMLS record into a flat RESO-ish associative array.
     */
    protected function normalise( array $record ): array {
        $sf = $record['StandardFields'] ?? $record;

        // Photos: Spark gives Photos[].Uri{ size } — pick the largest available.
        $media = [];
        foreach ( (array) ( $sf['Photos'] ?? [] ) as $p ) {
            $url = $p['Uri1600'] ?? $p['Uri1280'] ?? $p['Uri1024'] ?? $p['Uri800']
                 ?? $p['Uri640'] ?? $p['UriLarge'] ?? $p['Uri300'] ?? '';
            if ( $url ) $media[] = [ 'MediaURL' => $url, 'Order' => $p['Primary'] ?? 0 ];
        }

        // Map Spark-specific names onto RESO names the field map understands.
        $aliases = [
            'BedsTotal'         => 'BedroomsTotal',
            'BathsTotal'        => 'BathroomsTotalInteger',
            'BathsFull'         => 'BathroomsFull',
            'BuildingAreaTotal' => 'LivingArea',
            'LotSizeArea'       => 'LotSizeSquareFeet',
        ];
        foreach ( $aliases as $spark => $reso ) {
            if ( isset( $sf[ $spark ] ) && ! isset( $sf[ $reso ] ) ) {
                $sf[ $reso ] = $sf[ $spark ];
            }
        }
        $sf['Media'] = $media;
        return $sf;
    }
}
