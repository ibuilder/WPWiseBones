<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Adapter_Crexi — Crexi commercial real estate API
 * Docs: https://docs.crexi.com/
 * Feed api_key = Crexi API key.
 */
class PWM_Adapter_Crexi extends PWM_Adapter_Base {

    protected function auth_headers(): array {
        return [ 'x-api-key' => $this->feed->api_key, 'Accept' => 'application/json' ];
    }

    public function supported_asset_types(): array {
        return [
            'commercial'  => [ 'propertyType' => 'retail,office,mixed-use' ],
            'industrial'  => [ 'propertyType' => 'industrial' ],
            'land'        => [ 'propertyType' => 'land' ],
            'aviation'    => [ 'propertyType' => 'special-purpose' ],
            'multifamily' => [ 'propertyType' => 'multifamily' ],
        ];
    }

    public function fetch_page( string $asset_type, int $page, int $per_page ): array {
        $base   = rtrim( $this->feed->base_url ?: 'https://api.crexi.com/v1', '/' );
        $types  = $this->supported_asset_types()[ $asset_type ] ?? [];
        $extra  = json_decode( $this->feed->extra_params ?: '{}', true );
        $params = array_merge( [ 'page' => $page, 'perPage' => $per_page, 'status' => 'active' ], $types, $extra );
        $data   = $this->get( "$base/listings", $params );
        return $data['listings'] ?? $data['data'] ?? [];
    }
}
