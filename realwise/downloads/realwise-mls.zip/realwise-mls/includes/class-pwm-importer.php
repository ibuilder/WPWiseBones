<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWM_Importer — orchestrates a full import run for one feed.
 */
class PWM_Importer {

    public static function run( int $feed_id ): int {
        $feed = PWM_DB::get_feed( $feed_id );
        if ( ! $feed || ! $feed->active ) return 0;

        $log_id = PWM_DB::log_start( $feed_id );
        $counts = [
            'records_fetched'  => 0,
            'records_inserted' => 0,
            'records_updated'  => 0,
            'records_skipped'  => 0,
            'pages_pulled'     => 0,
        ];

        try {
            $adapter     = self::get_adapter( $feed );
            $field_map   = PWM_FieldMap::build( $feed );
            $asset_types = $feed->asset_types === 'all'
                ? array_keys( $adapter->supported_asset_types() )
                : array_map( 'trim', explode( ',', $feed->asset_types ) );

            $max_records  = (int) ( $feed->max_records ?: 5000 );
            $records_done = 0;
            $page_size    = 200;

            foreach ( $asset_types as $asset_type ) {
                if ( $records_done >= $max_records ) break;
                $page = 1;

                while ( $records_done < $max_records ) {
                    if ( $page > 1 ) usleep( 300000 );

                    $raw = $adapter->fetch_page( $asset_type, $page, min( $page_size, $max_records - $records_done ) );
                    if ( empty( $raw ) ) break;
                    $counts['pages_pulled']++;

                    foreach ( $raw as $record ) {
                        $counts['records_fetched']++;
                        $mapped = $field_map->transform( $record, $asset_type );
                        if ( empty( $mapped['mls_id'] ) ) {
                            $counts['records_skipped']++;
                            continue;
                        }
                        $existing = class_exists('PWL_DB') ? PWL_DB::get_by_mls_id( $mapped['mls_id'] ) : false;
                        if ( class_exists('PWL_DB') ) PWL_DB::upsert_listing( $mapped );
                        $existing ? $counts['records_updated']++ : $counts['records_inserted']++;
                        $records_done++;
                    }

                    if ( count( $raw ) < $page_size ) break;
                    $page++;
                }
            }

            self::mark_delisted( $feed );

            PWM_DB::log_finish( $log_id, 'success', $counts );
            global $wpdb;
            $wpdb->update( PWM_DB::feed_table(), [
                'last_run'        => current_time( 'mysql' ),
                'last_run_status' => 'success',
            ], [ 'id' => $feed_id ] );

        } catch ( Exception $e ) {
            PWM_DB::log_finish( $log_id, 'error', $counts, $e->getMessage() );
            global $wpdb;
            $wpdb->update( PWM_DB::feed_table(), [
                'last_run'        => current_time( 'mysql' ),
                'last_run_status' => 'error',
            ], [ 'id' => $feed_id ] );
        }

        return $log_id;
    }

    public static function get_adapter( object $feed ): PWM_Adapter_Base {
        $map = [
            // Generic RESO Web API (works with most modern MLS endpoints)
            'reso'          => 'PWM_Adapter_RESO',
            // Vendor presets (extend RESO with base URL + auth)
            'bridge'        => 'PWM_Adapter_Bridge',
            'trestle'       => 'PWM_Adapter_Trestle',
            'mlsgrid'       => 'PWM_Adapter_MLSGrid',
            'paragon'       => 'PWM_Adapter_Paragon',
            'rapattoni'     => 'PWM_Adapter_Rapattoni',
            'constellation' => 'PWM_Adapter_Constellation',
            // Non-OData APIs
            'spark'         => 'PWM_Adapter_Spark',       // Spark / FlexMLS
            'simplyrets'    => 'PWM_Adapter_SimplyRETS',
            'attom'         => 'PWM_Adapter_ATTOM',
            'crexi'         => 'PWM_Adapter_Crexi',
            // Legacy + file + demo
            'rets'          => 'PWM_Adapter_RETS',
            'csv'           => 'PWM_Adapter_CSV',
            'demo'          => 'PWM_Adapter_Demo',
        ];
        $class = $map[ $feed->adapter ] ?? null;
        if ( ! $class || ! class_exists( $class ) ) {
            throw new \RuntimeException( esc_html(  "Unknown adapter: {$feed->adapter}"  ) );
        }
        return new $class( $feed );
    }

    private static function mark_delisted( object $feed ): void {
        if ( ! class_exists('PWL_DB') ) return;
        global $wpdb;
        // 48h ago in site-local time, matching how pulled_at is stored (current_time('mysql')).
        $threshold = wp_date( 'Y-m-d H:i:s', time() - 48 * HOUR_IN_SECONDS );
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . PWL_DB::listings_table() . " SET status = 'delisted'
             WHERE status = 'active' AND pulled_at < %s AND pulled_at IS NOT NULL",
            $threshold
        ) );
    }
}
