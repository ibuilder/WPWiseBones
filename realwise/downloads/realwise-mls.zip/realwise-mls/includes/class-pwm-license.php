<?php
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * PWM_License — license key management for the commercial RealWise MLS plugin.
 *
 * Talks to the EDD Software Licensing API on the store (PWM_STORE_URL). Stores the
 * key and its status, activates/deactivates a site seat, and revalidates daily.
 * A valid license is what unlocks automatic updates (see PWM_Updater).
 */
class PWM_License {

    const KEY_OPT    = 'pwm_license_key';
    const STATUS_OPT = 'pwm_license_status';   // 'valid' | 'invalid' | 'expired' | 'inactive' | ''
    const CRON_HOOK  = 'pwm_license_daily_check';

    public static function init(): void {
        add_action( 'admin_post_pwm_activate_license',   [ __CLASS__, 'handle_activate' ] );
        add_action( 'admin_post_pwm_deactivate_license', [ __CLASS__, 'handle_deactivate' ] );
        add_action( self::CRON_HOOK,                     [ __CLASS__, 'scheduled_check' ] );
        add_action( 'admin_notices',                     [ __CLASS__, 'maybe_notice' ] );
        if ( ! wp_next_scheduled( self::CRON_HOOK ) ) {
            wp_schedule_event( time() + DAY_IN_SECONDS, 'daily', self::CRON_HOOK );
        }
    }

    public static function key(): string {
        return trim( (string) get_option( self::KEY_OPT, '' ) );
    }

    public static function status(): string {
        return (string) get_option( self::STATUS_OPT, '' );
    }

    public static function is_valid(): bool {
        return self::status() === 'valid';
    }

    /** Low-level call to the store's EDD-SL API. */
    private static function api( string $edd_action, string $key ): ?object {
        $resp = wp_remote_post(
            PWM_STORE_URL,
            [
                'timeout'   => 15,
                'sslverify' => true,
                'body'      => [
                    'edd_action' => $edd_action, // activate_license | deactivate_license | check_license
                    'license'    => $key,
                    'item_name'  => rawurlencode( PWM_ITEM_NAME ),
                    'url'        => home_url(),
                ],
            ]
        );
        if ( is_wp_error( $resp ) || wp_remote_retrieve_response_code( $resp ) !== 200 ) {
            return null;
        }
        $data = json_decode( wp_remote_retrieve_body( $resp ) );
        return is_object( $data ) ? $data : null;
    }

    public static function handle_activate(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Denied', 'realwise-mls' ) );
        check_admin_referer( 'pwm_license' );
        $key = isset( $_POST['pwm_license_key'] ) ? sanitize_text_field( wp_unslash( $_POST['pwm_license_key'] ) ) : '';
        update_option( self::KEY_OPT, $key );
        $data = self::api( 'activate_license', $key );
        $status = ( $data && ! empty( $data->success ) && isset( $data->license ) ) ? $data->license : 'invalid';
        update_option( self::STATUS_OPT, $status );
        self::redirect_back( $status === 'valid' ? 'activated' : 'activate_failed' );
    }

    public static function handle_deactivate(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( esc_html__( 'Denied', 'realwise-mls' ) );
        check_admin_referer( 'pwm_license' );
        self::api( 'deactivate_license', self::key() );
        update_option( self::STATUS_OPT, 'inactive' );
        self::redirect_back( 'deactivated' );
    }

    /** Daily silent revalidation so expired/revoked keys flip to invalid. */
    public static function scheduled_check(): void {
        $key = self::key();
        if ( $key === '' ) return;
        $data = self::api( 'check_license', $key );
        if ( $data && isset( $data->license ) ) {
            update_option( self::STATUS_OPT, $data->license );
        }
    }

    private static function redirect_back( string $msg ): void {
        wp_safe_redirect( add_query_arg(
            [ 'page' => 'pwm-license', 'pwm_msg' => $msg ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    public static function maybe_notice(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( self::is_valid() ) return;
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( ! $screen || strpos( $screen->id, 'pwm-' ) === false ) return;
        $url = admin_url( 'admin.php?page=pwm-license' );
        printf(
            '<div class="notice notice-warning"><p><strong>%s</strong> %s <a href="%s">%s</a></p></div>',
            esc_html__( 'RealWise MLS', 'realwise-mls' ),
            esc_html__( 'is not licensed, so automatic updates are off.', 'realwise-mls' ),
            esc_url( $url ),
            esc_html__( 'Enter your license key', 'realwise-mls' )
        );
    }

    /** Admin page: the License screen. */
    public static function page(): void {
        $key    = self::key();
        $status = self::status();
        $masked = $key !== '' ? str_repeat( '•', max( 0, strlen( $key ) - 4 ) ) . substr( $key, -4 ) : '';
        ?>
        <div class="wrap">
            <h1><?php esc_html_e( 'RealWise MLS — License', 'realwise-mls' ); ?></h1>
            <?php if ( isset( $_GET['pwm_msg'] ) ) : // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $m = sanitize_key( wp_unslash( $_GET['pwm_msg'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                $map = [
                    'activated'       => [ 'success', __( 'License activated. Automatic updates are on.', 'realwise-mls' ) ],
                    'deactivated'     => [ 'info',    __( 'License deactivated on this site.', 'realwise-mls' ) ],
                    'activate_failed' => [ 'error',   __( 'Could not activate that key. Check it and try again.', 'realwise-mls' ) ],
                ];
                if ( isset( $map[ $m ] ) ) printf( '<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr( $map[ $m ][0] ), esc_html( $map[ $m ][1] ) );
            endif; ?>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'pwm_license' ); ?>
                <table class="form-table" role="presentation">
                    <tr>
                        <th scope="row"><label for="pwm_license_key"><?php esc_html_e( 'License key', 'realwise-mls' ); ?></label></th>
                        <td>
                            <input name="pwm_license_key" id="pwm_license_key" type="text" class="regular-text"
                                   value="<?php echo esc_attr( self::is_valid() ? $masked : $key ); ?>"
                                   <?php echo self::is_valid() ? 'readonly' : ''; ?> />
                            <p class="description">
                                <?php
                                $labels = [
                                    'valid'    => [ '#16a34a', __( 'Active', 'realwise-mls' ) ],
                                    'expired'  => [ '#b91c1c', __( 'Expired — please renew', 'realwise-mls' ) ],
                                    'invalid'  => [ '#b91c1c', __( 'Invalid key', 'realwise-mls' ) ],
                                    'inactive' => [ '#6b7280', __( 'Inactive on this site', 'realwise-mls' ) ],
                                ];
                                $l = $labels[ $status ] ?? [ '#6b7280', __( 'Not entered', 'realwise-mls' ) ];
                                printf( '<strong style="color:%s">%s</strong>', esc_attr( $l[0] ), esc_html( $l[1] ) );
                                ?>
                            </p>
                        </td>
                    </tr>
                </table>
                <?php if ( self::is_valid() ) : ?>
                    <input type="hidden" name="action" value="pwm_deactivate_license" />
                    <?php submit_button( __( 'Deactivate License', 'realwise-mls' ), 'secondary' ); ?>
                <?php else : ?>
                    <input type="hidden" name="action" value="pwm_activate_license" />
                    <?php submit_button( __( 'Activate License', 'realwise-mls' ) ); ?>
                <?php endif; ?>
            </form>
            <p class="description">
                <?php
                printf(
                    /* translators: %s is the store URL. */
                    esc_html__( 'Buy or manage your license at %s.', 'realwise-mls' ),
                    '<a href="' . esc_url( PWM_STORE_URL ) . '" target="_blank" rel="noopener">' . esc_html( PWM_STORE_URL ) . '</a>'
                );
                ?>
            </p>
        </div>
        <?php
    }
}
