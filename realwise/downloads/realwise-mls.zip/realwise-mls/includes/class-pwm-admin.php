<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWM_Admin — MLS Connect admin pages: dashboard, feeds CRUD, import log, field maps.
 */
class PWM_Admin {

    public static function init(): void {
        add_action( 'admin_menu',  [ __CLASS__, 'menu'           ] );
        add_action( 'admin_init',  [ __CLASS__, 'handle_actions' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
        add_action( 'wp_ajax_pwm_run_import_now',  [ __CLASS__, 'ajax_run_now'       ] );
        add_action( 'wp_ajax_pwm_save_field_map',  [ __CLASS__, 'ajax_save_field_map'] );
    }

    public static function menu(): void {
        // Own top-level menu. RealWise MLS is a standalone plugin, so it must not
        // depend on another plugin's menu existing (plugin load order is not
        // guaranteed, and attaching to a not-yet-registered parent 404s the pages).
        add_menu_page(
            __( 'RealWise MLS', 'realwise-mls' ),
            __( 'RealWise MLS', 'realwise-mls' ),
            'manage_options',
            'pwm-dashboard',
            [ __CLASS__, 'page_dashboard' ],
            'dashicons-download',
            56
        );
        $sub = [
            'pwm-dashboard' => [ __( 'Dashboard',   'realwise-mls' ), 'page_dashboard'  ],
            'pwm-feeds'     => [ __( 'MLS Feeds',   'realwise-mls' ), 'page_feeds'      ],
            'pwm-log'       => [ __( 'Import Log',  'realwise-mls' ), 'page_log'        ],
            'pwm-fieldmaps' => [ __( 'Field Maps',  'realwise-mls' ), 'page_fieldmaps'  ],
            'pwm-license'   => [ __( 'License',     'realwise-mls' ), [ 'PWM_License', 'page' ] ],
        ];
        foreach ( $sub as $slug => [ $label, $cb ] ) {
            $callback = is_array( $cb ) ? $cb : [ __CLASS__, $cb ];
            add_submenu_page( 'pwm-dashboard', $label, $label, 'manage_options', $slug, $callback );
        }
    }

    public static function assets( string $hook ): void {
        if ( strpos( $hook, 'pwm' ) === false ) return;
        wp_enqueue_style(  'pwm-admin', PWM_URL . 'assets/css/admin.css', [], PWM_VERSION );
        wp_enqueue_script( 'pwm-admin', PWM_URL . 'assets/js/admin.js',  [ 'jquery' ], PWM_VERSION, true );
        wp_localize_script( 'pwm-admin', 'PWM_Admin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'pwm_admin_nonce' ),
        ] );
    }

    public static function page_dashboard(): void {
        $feeds     = PWM_DB::get_feeds();
        $logs      = PWM_DB::get_recent_logs( 0, 10 );
        $next_runs = [];
        foreach ( $feeds as $f ) {
            $next_runs[$f->id] = PWM_Scheduler::next_run_time( $f->id );
        }
        include PWM_DIR . 'templates/admin/dashboard.php';
    }

    /**
     * Per-adapter setup hints shown in the feed editor. Keys: api_key label,
     * api_secret label (or empty to hide), base_url hint, extra hint.
     */
    public static function adapter_presets(): array {
        return [
            'reso'          => [ 'key' => 'Bearer token / Client ID', 'secret' => 'Client Secret (OAuth2 only)', 'url' => 'Your MLS RESO OData endpoint', 'extra' => '{"auth_mode":"bearer"} — or "oauth2" with "token_url", or "query_token"' ],
            'bridge'        => [ 'key' => 'Server Token (access_token)', 'secret' => '', 'url' => 'Leave blank for Bridge default', 'extra' => 'Optional OData overrides' ],
            'trestle'       => [ 'key' => 'Client ID', 'secret' => 'Client Secret', 'url' => 'Leave blank for Trestle default', 'extra' => 'Optional {"scope":"api"}' ],
            'mlsgrid'       => [ 'key' => 'Bearer token', 'secret' => '', 'url' => 'Leave blank for MLS Grid default', 'extra' => 'Optional {"odata_filter":"OriginatingSystemName eq \'XXX\'"}' ],
            'paragon'       => [ 'key' => 'Client ID', 'secret' => 'Client Secret', 'url' => 'Your Paragon OData endpoint', 'extra' => 'OAuth2 token_url if non-default' ],
            'rapattoni'     => [ 'key' => 'Bearer token', 'secret' => '', 'url' => 'Your Rapattoni RESO endpoint', 'extra' => '' ],
            'constellation' => [ 'key' => 'Client ID', 'secret' => 'Client Secret', 'url' => 'Leave blank for default', 'extra' => '' ],
            'spark'         => [ 'key' => 'Access token (Bearer)', 'secret' => '', 'url' => 'Leave blank for Spark replication API', 'extra' => 'FlexMLS uses this adapter' ],
            'simplyrets'    => [ 'key' => 'API username', 'secret' => 'API password', 'url' => 'Leave blank for api.simplyrets.com', 'extra' => '' ],
            'attom'         => [ 'key' => 'ATTOM API key', 'secret' => '', 'url' => 'Leave blank for default', 'extra' => '' ],
            'crexi'         => [ 'key' => 'Crexi API key', 'secret' => '', 'url' => 'Leave blank for default', 'extra' => '' ],
            'rets'          => [ 'key' => 'RETS username', 'secret' => 'RETS password', 'url' => 'RETS Login URL', 'extra' => '{"rets_version":"RETS/1.7.2","res_class":"ResidentialProperty"}' ],
            'csv'           => [ 'key' => 'Basic-auth user (optional)', 'secret' => 'Basic-auth pass (optional)', 'url' => 'CSV file URL (or use extra_params.path)', 'extra' => '{"delimiter":",","path":"/abs/uploads/feed.csv"}' ],
            'demo'          => [ 'key' => '', 'secret' => '', 'url' => '', 'extra' => '{"format":"reso"} or {"format":"flexmls"}' ],
        ];
    }

    public static function page_feeds(): void {
        $editing  = isset( $_GET['edit'] ) ? PWM_DB::get_feed( (int) $_GET['edit'] ) : null;
        $feeds    = PWM_DB::get_feeds();
        $adapters = [
            // RESO Web API (the modern standard)
            'reso'          => 'RESO Web API (generic / any MLS)',
            'bridge'        => 'Bridge Interactive (Zillow)',
            'trestle'       => 'CoreLogic Trestle',
            'mlsgrid'       => 'MLS Grid',
            'paragon'       => 'Paragon / ICE',
            'rapattoni'     => 'Rapattoni',
            'constellation' => 'Constellation1',
            // Non-OData APIs
            'spark'         => 'Spark Platform / FlexMLS',
            'simplyrets'    => 'SimplyRETS',
            'attom'         => 'ATTOM Data',
            'crexi'         => 'Crexi Commercial',
            // Legacy + file + demo
            'rets'          => 'RETS (Legacy)',
            'csv'           => 'CSV / IDX File',
            'demo'          => 'Demo (bundled sample data)',
        ];
        $adapter_presets = PWM_Admin::adapter_presets();
        $freqs    = [ 'hourly' => 'Hourly', '6hours' => 'Every 6 Hours', '12hours' => 'Every 12 Hours', 'twicedaily' => 'Twice Daily', 'daily' => 'Daily', 'weekly' => 'Weekly', 'manual' => 'Manual Only' ];
        include PWM_DIR . 'templates/admin/feeds.php';
    }

    public static function page_log(): void {
        $feed_id = (int) ( $_GET['feed_id'] ?? 0 );
        $logs    = PWM_DB::get_recent_logs( $feed_id, 50 );
        $feeds   = PWM_DB::get_feeds();
        include PWM_DIR . 'templates/admin/import-log.php';
    }

    public static function page_fieldmaps(): void {
        $feed_id  = (int) ( $_GET['feed_id'] ?? 0 );
        $feeds    = PWM_DB::get_feeds();
        $maps     = $feed_id ? PWM_DB::get_field_maps( $feed_id ) : [];
        $defaults = PWM_FieldMap::reso_defaults();
        $pw_cols  = self::pw_columns();
        include PWM_DIR . 'templates/admin/field-maps.php';
    }

    public static function handle_actions(): void {
        if ( ! current_user_can( 'manage_options' ) ) return;

        if ( isset( $_POST['pwm_save_feed'] ) ) {
            check_admin_referer( 'pwm_save_feed' );
            $data = [
                'label'              => sanitize_text_field( wp_unslash( $_POST['label'] ) ),
                'adapter'            => sanitize_key( wp_unslash( $_POST['adapter'] ) ),
                'base_url'           => esc_url_raw( wp_unslash( $_POST['base_url']  ?? '' ) ),
                'api_key'            => sanitize_text_field( wp_unslash( $_POST['api_key'] ) ),
                'api_secret'         => sanitize_text_field( wp_unslash( $_POST['api_secret']  ?? '' ) ),
                'extra_params'       => sanitize_textarea_field( wp_unslash( $_POST['extra_params'] ?? '' ) ),
                'asset_types'        => sanitize_text_field( wp_unslash( $_POST['asset_types'] ?? 'all' ) ),
                'filter_zips'        => sanitize_textarea_field( wp_unslash( $_POST['filter_zips'] ?? '' ) ),
                'schedule_frequency' => sanitize_key( wp_unslash( $_POST['schedule_frequency'] ?? 'daily' ) ),
                'schedule_time'      => sanitize_text_field( wp_unslash( $_POST['schedule_time'] ?? '02:00' ) ),
                'max_records'        => (int) ( $_POST['max_records'] ?? 5000 ),
                'active'             => isset( $_POST['active'] ) ? 1 : 0,
            ];
            if ( ! empty( $_POST['feed_id'] ) ) $data['id'] = (int) $_POST['feed_id'];
            $id   = PWM_DB::save_feed( $data );
            // Resync all schedules so the saved feed takes effect immediately
            PWM_Scheduler::sync_schedules();
            wp_safe_redirect( add_query_arg( [ 'page' => 'pwm-feeds', 'msg' => 'saved' ], admin_url( 'admin.php' ) ) );
            exit;
        }

        if ( isset( $_GET['pwm_delete_feed'] ) && check_admin_referer( 'pwm_delete_feed' ) ) {
            PWM_DB::delete_feed( (int) $_GET['pwm_delete_feed'] );
            wp_safe_redirect( add_query_arg( [ 'page' => 'pwm-feeds', 'msg' => 'deleted' ], admin_url( 'admin.php' ) ) );
            exit;
        }
    }

    public static function ajax_run_now(): void {
        check_ajax_referer( 'pwm_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
        $feed_id = (int) ( $_POST['feed_id'] ?? 0 );
        if ( ! $feed_id ) wp_send_json_error( 'No feed ID.' );

        // Schedule immediately — avoids 30s HTTP timeout on large feeds
        $hook = 'pwm_run_import_now_' . $feed_id;
        add_action( $hook, function () use ( $feed_id ) {
            PWM_Importer::run( $feed_id );
        } );
        if ( ! wp_next_scheduled( $hook ) ) {
            wp_schedule_single_event( time(), $hook );
        }
        // Spawn cron immediately so it doesn't wait for next visitor
        wp_remote_post( admin_url( 'admin-ajax.php' ), [
            'timeout'   => 0.01,
            'blocking'  => false,
            'body'      => [ 'action' => 'pwm_spawn_cron' ],
            'cookies'   => [],
            'sslverify' => apply_filters( 'https_local_ssl_verify', false ),
        ] );
        spawn_cron();

        wp_send_json_success( [ 'message' => 'Import queued. Refresh the log in a moment to see results.' ] );
    }

    public static function ajax_save_field_map(): void {
        check_ajax_referer( 'pwm_admin_nonce', 'nonce' );
        if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
        PWM_DB::save_field_map( [
            'feed_id'       => (int)    ( $_POST['feed_id']      ?? 0 ),
            'mls_field'     => sanitize_text_field( wp_unslash( $_POST['mls_field']    ?? '' ) ),
            'pw_column'     => sanitize_key( wp_unslash( $_POST['pw_column']    ?? '' ) ),
            'transform'     => sanitize_key( wp_unslash( $_POST['transform']    ?? 'string' ) ),
            'default_value' => sanitize_text_field( wp_unslash( $_POST['default_value'] ?? '' ) ),
            'active'        => (int) ( $_POST['active'] ?? 1 ),
        ] );
        wp_send_json_success();
    }

    public static function pw_columns(): array {
        return [
            'mls_id','asset_type','status','list_price','address','city','state','zip_code','county',
            'latitude','longitude','bedrooms','bathrooms','sqft','lot_sqft','year_built','garage_spaces',
            'pool','hoa_fee','property_taxes','flood_zone','zoning','cap_rate','noi','occupancy_rate',
            'num_units','virtual_tour','photos','description','days_on_market','agent_id',
        ];
    }
}
