<?php
/**
 * Uninstall RealWise MLS — clears cron events, license data, and drops all tables.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- Uninstall drops the plugin's own custom tables (names from $wpdb->prefix + literals); no user values to prepare.

function realwise_mls_uninstall_site() {
    global $wpdb;

    // Clear the per-feed scheduled + run-now cron events before dropping the feeds table.
    $feeds_table = $wpdb->prefix . 'pwm_feeds';
    if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $feeds_table ) ) === $feeds_table ) {
        $ids = $wpdb->get_col( "SELECT id FROM `{$feeds_table}`" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        foreach ( (array) $ids as $id ) {
            wp_clear_scheduled_hook( 'pwm_run_import_' . (int) $id );
            wp_clear_scheduled_hook( 'pwm_run_import_now_' . (int) $id );
        }
    }

    // Licensing: clear the daily revalidation cron (options are removed by the pwm_ sweep below).
    wp_clear_scheduled_hook( 'pwm_license_daily_check' );

    foreach ( [ 'pwm_feeds', 'pwm_import_log', 'pwm_field_maps' ] as $t ) {
        $wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}$t`" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    // Any pwm_ prefixed options/transients (currently none, but future-proof).
    $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'pwm\\_%'" ); // phpcs:ignore WordPress.DB
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '\\_transient\\_pwm\\_%'
            OR option_name LIKE '\\_transient\\_timeout\\_pwm\\_%'"
    ); // phpcs:ignore WordPress.DB
}

if ( is_multisite() ) {
    foreach ( get_sites( [ 'fields' => 'ids', 'number' => 0 ] ) as $rw_blog_id ) {
        switch_to_blog( $rw_blog_id );
        realwise_mls_uninstall_site();
        restore_current_blog();
    }
} else {
    realwise_mls_uninstall_site();
}
