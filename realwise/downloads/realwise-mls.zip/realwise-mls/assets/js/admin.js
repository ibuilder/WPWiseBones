/* RealWise MLS Connect — Admin JS */
(function ($) {
  'use strict';

  // Run import now button
  $(document).on('click', '.pwm-run-now', function () {
    var $btn    = $(this).prop('disabled', true).text('Running…');
    var feed_id = $btn.data('feed');
    var $status = $('#pwm-run-status');
    $status.text('Starting import for feed #' + feed_id + '…');

    $.post(PWM_Admin.ajax_url, {
      action:  'pwm_run_import_now',
      nonce:   PWM_Admin.nonce,
      feed_id: feed_id
    }, function (res) {
      $btn.prop('disabled', false).text('Run Now');
      if (res.success) {
        $status.html(
          '&#9989; ' + (res.data.message || 'Import queued.')
          + ' <a href="' + window.location.pathname + '?page=pwm-log&feed_id=' + feed_id + '">View log &rarr;</a>'
        ).css('color', '#16a34a');
      } else {
        $status.text('Error: ' + (res.data || 'Unknown error.')).css('color', '#dc2626');
      }
    });
  });

  // Save individual field map row
  $(document).on('click', '.pwm-save-map', function () {
    var $btn   = $(this).prop('disabled', true).text('Saving…');
    var $row   = $btn.closest('.pwm-map-row');
    $.post(PWM_Admin.ajax_url, {
      action:    'pwm_save_field_map',
      nonce:     PWM_Admin.nonce,
      feed_id:   $btn.data('feed'),
      mls_field: $btn.data('field'),
      pw_column: $row.find('.pwm-pw-col').val(),
      transform: $row.find('.pwm-transform').val(),
      active:    1
    }, function (res) {
      $btn.prop('disabled', false).text(res.success ? 'Saved ✓' : 'Error');
      setTimeout(function () { $btn.text('Save'); }, 2000);
    });
  });

}(jQuery));
