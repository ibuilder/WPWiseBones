<?php if ( ! defined( 'ABSPATH' ) ) exit;
// Use nullsafe operator throughout — $editing is null when adding a new feed
$e = $editing; // shorthand
?>
<div class="wrap pwm-admin">
    <h1><?php echo $e ? esc_html__( 'Edit Feed', 'realwise-mls' ) : esc_html__( 'Add New Feed', 'realwise-mls' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php echo esc_html( $_GET['msg'] === 'saved' ? __( 'Feed saved.', 'realwise-mls' ) : __( 'Feed deleted.', 'realwise-mls' ) ); ?></p></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( admin_url('admin.php?page=pwm-feeds') ); ?>">
        <?php wp_nonce_field( 'pwm_save_feed' ); ?>
        <?php if ( $e ) : ?><input type="hidden" name="feed_id" value="<?php echo (int) $e->id; ?>"><?php endif; ?>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Label', 'realwise-mls' ); ?></th><td><input type="text" name="label" class="regular-text" value="<?php echo esc_attr( $e?->label ?? '' ); ?>" required></td></tr>
            <tr><th><?php esc_html_e( 'Adapter', 'realwise-mls' ); ?></th><td>
                <select name="adapter" class="regular-text">
                    <?php foreach ( $adapters as $val => $lbl ) : ?>
                    <option value="<?php echo esc_attr($val); ?>" <?php selected( $e?->adapter ?? 'bridge', $val ); ?>><?php echo esc_html($lbl); ?></option>
                    <?php endforeach; ?>
                </select>
            </td></tr>
            <tr><th><?php esc_html_e( 'Base URL', 'realwise-mls' ); ?></th><td><input type="url" name="base_url" class="regular-text" value="<?php echo esc_attr( $e?->base_url ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Leave blank for default', 'realwise-mls' ); ?>"></td></tr>
            <tr><th><?php esc_html_e( 'API Key', 'realwise-mls' ); ?></th><td>
                <input type="password" name="api_key" class="regular-text" value="<?php echo esc_attr( $e?->api_key ?? '' ); ?>" autocomplete="new-password">
                <?php /* translators: %d / %s are runtime values. */ if ( $e?->api_key ) : ?><p class="description"><?php printf( esc_html__( 'Key set (ends …%s). Overwrite to change.', 'realwise-mls' ), esc_html( substr( $e->api_key, -4 ) ) ); ?></p><?php endif; ?>
            </td></tr>
            <tr><th><?php esc_html_e( 'API Secret', 'realwise-mls' ); ?></th><td><input type="password" name="api_secret" class="regular-text" value="<?php echo esc_attr( $e?->api_secret ?? '' ); ?>" autocomplete="new-password"></td></tr>
            <tr><th><?php esc_html_e( 'Extra Params (JSON)', 'realwise-mls' ); ?></th><td><textarea name="extra_params" class="large-text" rows="3"><?php echo esc_textarea( $e?->extra_params ?? '' ); ?></textarea>
                <p class="description"><?php esc_html_e( 'Adapter-specific options as JSON, e.g.', 'realwise-mls' ); ?> <code>{"rets_version":"RETS/1.7.2"}</code></p></td></tr>
            <tr><th><?php esc_html_e( 'Asset Types', 'realwise-mls' ); ?></th><td>
                <input type="text" name="asset_types" class="regular-text" value="<?php echo esc_attr( $e?->asset_types ?? 'all' ); ?>" placeholder="all  or  residential,commercial,land">
                <p class="description"><?php esc_html_e( 'Comma-separated: residential, commercial, industrial, land, multifamily, aviation — or "all"', 'realwise-mls' ); ?></p>
            </td></tr>
            <tr><th><?php esc_html_e( 'Filter ZIPs', 'realwise-mls' ); ?></th><td><textarea name="filter_zips" class="regular-text" rows="4" placeholder="<?php esc_attr_e( 'One ZIP per line', 'realwise-mls' ); ?>"><?php echo esc_textarea( $e?->filter_zips ?? '' ); ?></textarea></td></tr>
            <tr><th><?php esc_html_e( 'Schedule', 'realwise-mls' ); ?></th><td>
                <select name="schedule_frequency">
                    <?php foreach ( $freqs as $val => $lbl ) : ?>
                    <option value="<?php echo esc_attr($val); ?>" <?php selected( $e?->schedule_frequency ?? 'daily', $val ); ?>><?php echo esc_html($lbl); ?></option>
                    <?php endforeach; ?>
                </select>
                <?php esc_html_e( 'at', 'realwise-mls' ); ?> <input type="time" name="schedule_time" value="<?php echo esc_attr( $e?->schedule_time ?? '02:00' ); ?>" style="width:90px">
            </td></tr>
            <tr><th><?php esc_html_e( 'Max Records/Run', 'realwise-mls' ); ?></th><td><input type="number" name="max_records" value="<?php echo esc_attr( $e?->max_records ?? 5000 ); ?>" class="small-text" min="1"></td></tr>
            <tr><th><?php esc_html_e( 'Active', 'realwise-mls' ); ?></th><td><label><input type="checkbox" name="active" value="1" <?php checked( $e?->active ?? 0, 1 ); ?>> <?php esc_html_e( 'Enable this feed', 'realwise-mls' ); ?></label></td></tr>
        </table>
        <input type="submit" name="pwm_save_feed" class="button button-primary" value="<?php echo $e ? esc_attr__( 'Update Feed', 'realwise-mls' ) : esc_attr__( 'Add Feed', 'realwise-mls' ); ?>">
        <a href="<?php echo esc_url( add_query_arg('page','pwm-feeds', admin_url('admin.php')) ); ?>" class="button"><?php esc_html_e( 'Cancel', 'realwise-mls' ); ?></a>
    </form>

    <hr>
    <h2><?php esc_html_e( 'Connection guide', 'realwise-mls' ); ?></h2>
    <p class="description"><?php esc_html_e( 'What to put in each field, per provider. The RESO Web API adapter works with any MLS that exposes a RESO endpoint; the named providers are presets that pre-fill the URL and auth.', 'realwise-mls' ); ?></p>
    <table class="widefat striped" style="max-width:1000px">
        <thead><tr>
            <th><?php esc_html_e( 'Provider', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'API Key', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'API Secret', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Base URL', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Extra Params (JSON)', 'realwise-mls' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $adapters as $key => $label ) :
            $p = $adapter_presets[ $key ] ?? [ 'key' => '', 'secret' => '', 'url' => '', 'extra' => '' ]; ?>
        <tr>
            <td><strong><?php echo esc_html( $label ); ?></strong></td>
            <td><?php echo $p['key']    ? esc_html( $p['key'] )    : '&mdash;'; ?></td>
            <td><?php echo $p['secret'] ? esc_html( $p['secret'] ) : '&mdash;'; ?></td>
            <td><?php echo $p['url']    ? esc_html( $p['url'] )    : '&mdash;'; ?></td>
            <td><?php echo $p['extra']  ? '<code>' . esc_html( $p['extra'] ) . '</code>' : '&mdash;'; ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p class="description"><?php esc_html_e( 'Tip: choose "Demo (bundled sample data)" and click Run Now to import six sample listings with no credentials — a quick way to verify the pipeline end to end.', 'realwise-mls' ); ?></p>

    <hr>
    <h2><?php esc_html_e( 'All Feeds', 'realwise-mls' ); ?></h2>
    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'ID', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Label', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Adapter', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Frequency', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Active', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'realwise-mls' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $feeds as $f ) : ?>
        <tr>
            <td><?php echo (int) $f->id; ?></td>
            <td><?php echo esc_html( $f->label ); ?></td>
            <td><?php echo esc_html( $adapters[ $f->adapter ] ?? $f->adapter ); ?></td>
            <td><?php echo esc_html( $freqs[ $f->schedule_frequency ] ?? $f->schedule_frequency ); ?> @ <?php echo esc_html( $f->schedule_time ); ?></td>
            <td><?php echo $f->active ? '&#10003;' : '&mdash;'; ?></td>
            <td>
                <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwm-feeds', 'edit' => $f->id ], admin_url('admin.php') ) ); ?>" class="button"><?php esc_html_e( 'Edit', 'realwise-mls' ); ?></a>
                <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'page' => 'pwm-feeds', 'pwm_delete_feed' => $f->id ], admin_url('admin.php') ), 'pwm_delete_feed' ) ); ?>"
                   class="button" onclick="return confirm('<?php echo esc_js( __( 'Delete this feed and all its field maps?', 'realwise-mls' ) ); ?>')"><?php esc_html_e( 'Delete', 'realwise-mls' ); ?></a>
                <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwm-fieldmaps', 'feed_id' => $f->id ], admin_url('admin.php') ) ); ?>" class="button"><?php esc_html_e( 'Field Maps', 'realwise-mls' ); ?></a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><a href="<?php echo esc_url( add_query_arg( 'page', 'pwm-feeds', admin_url('admin.php') ) ); ?>" class="button button-primary"><?php esc_html_e( '+ Add Another Feed', 'realwise-mls' ); ?></a></p>
</div>
