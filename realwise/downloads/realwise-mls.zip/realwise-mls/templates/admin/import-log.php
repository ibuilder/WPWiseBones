<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwm-admin">
    <h1><?php esc_html_e( 'Import Log', 'realwise-mls' ); ?></h1>
    <form method="get">
        <input type="hidden" name="page" value="pwm-log">
        <label><?php esc_html_e( 'Filter by feed:', 'realwise-mls' ); ?>
            <select name="feed_id" onchange="this.form.submit()">
                <option value="0"><?php esc_html_e( 'All feeds', 'realwise-mls' ); ?></option>
                <?php foreach ( $feeds as $f ) : ?>
                <option value="<?php echo (int)$f->id; ?>" <?php selected($feed_id,$f->id); ?>><?php echo esc_html($f->label); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </form>
    <table class="widefat striped" style="margin-top:12px">
        <thead><tr>
            <th><?php esc_html_e( 'Feed', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Started', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Finished', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Status', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Fetched', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Inserted', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Updated', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Skipped', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Pages', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Memory', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Error', 'realwise-mls' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $logs as $log ) : ?>
        <tr>
            <td><?php echo esc_html( $log->feed_label ); ?></td>
            <td><?php echo esc_html( date_i18n('M j, g:i a', strtotime($log->started_at)) ); ?></td>
            <td><?php echo $log->finished_at ? esc_html( date_i18n('g:i a', strtotime($log->finished_at)) ) : '…'; ?></td>
            <td><span class="pwm-badge <?php echo $log->status==='success'?'pwm-badge--green':($log->status==='running'?'pwm-badge--blue':'pwm-badge--red'); ?>"><?php echo esc_html($log->status); ?></span></td>
            <td><?php echo (int)$log->records_fetched; ?></td>
            <td><?php echo (int)$log->records_inserted; ?></td>
            <td><?php echo (int)$log->records_updated; ?></td>
            <td><?php echo (int)$log->records_skipped; ?></td>
            <td><?php echo (int)$log->pages_pulled; ?></td>
            <td><?php echo $log->memory_peak_mb ? esc_html($log->memory_peak_mb).' MB' : '—'; ?></td>
            <td><?php echo $log->error_message ? '<span title="'.esc_attr($log->error_message).'">&#x26A0;</span>' : ''; ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
