<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwm-admin">
    <h1>MLS Connect — Dashboard</h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php echo esc_html( ucfirst( $_GET['msg'] ) ); ?></p></div>
    <?php endif; ?>

    <script>
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.pwl-help-toggle');
        if (!btn) return;
        btn.setAttribute('aria-expanded', btn.getAttribute('aria-expanded') === 'true' ? 'false' : 'true');
    });
    </script>
    <div class="pwl-help-panel">
        <button type="button" class="pwl-help-toggle" aria-expanded="true">
            <span class="dashicons dashicons-lightbulb"></span> Getting Started &amp; Tips
            <span class="pwl-help-chevron">▾</span>
        </button>
        <div class="pwl-help-body">
            <div class="pwl-help-cols">
                <div class="pwl-help-col">
                    <h3>What this plugin does</h3>
                    <p>MLS Connect imports listings into RealWise from five vendor APIs — Bridge Interactive, Spark Platform, RETS, ATTOM Data, and Crexi — on an automatic schedule, with per-feed field mapping and a full import log.</p>
                    <h3>Quick start</h3>
                    <ol>
                        <li>Go to <strong>MLS Feeds</strong> and edit the default feed (or add a new one).</li>
                        <li>Pick your <strong>adapter</strong>, paste your API key, and set the asset types and ZIP filters.</li>
                        <li>Choose a <strong>schedule</strong> (e.g. Daily at 02:00) and tick <em>Active</em>.</li>
                        <li>Click <strong>Run Now</strong> here to test, then watch the <strong>Import Log</strong>.</li>
                        <li>Review <strong>Field Maps</strong> if your MLS uses non-standard field names.</li>
                    </ol>
                </div>
                <div class="pwl-help-col">
                    <h3>Tips</h3>
                    <ul class="pwl-help-tips">
                        <li><strong>Run Now is asynchronous</strong> — it queues a background job via WP-Cron and returns immediately. Refresh the Import Log to see results.</li>
                        <li><strong>WP-Cron depends on site traffic.</strong> For reliable scheduling, set a real server cron hitting <code>wp-cron.php</code> and define <code>DISABLE_WP_CRON</code>.</li>
                        <li><strong>30+ RESO fields</strong> are mapped out of the box. Override any of them per-feed under Field Maps.</li>
                        <li><strong>RETS</strong> needs the phRETS library: run <code>composer require troydavisson/phrets</code> in the plugin folder.</li>
                        <li>Listings not seen in a feed for <strong>48 hours</strong> are auto-marked <em>delisted</em> (never deleted).</li>
                        <li>Use <strong>Max Records/Run</strong> to stay within vendor rate limits on large markets.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <h2><?php esc_html_e( 'Feeds', 'realwise-mls' ); ?></h2>
    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'Feed', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Adapter', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Status', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Last Run', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Next Run', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'realwise-mls' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $feeds as $f ) : ?>
        <tr>
            <td><strong><?php echo esc_html( $f->label ); ?></strong></td>
            <td><?php echo esc_html( ucfirst( $f->adapter ) ); ?></td>
            <td>
                <?php if ( $f->active ) : ?>
                <span class="pwm-badge pwm-badge--green"><?php esc_html_e( 'Active', 'realwise-mls' ); ?></span>
                <?php if ( $f->last_run_status ) : ?>
                <span class="pwm-badge <?php echo $f->last_run_status === 'success' ? 'pwm-badge--green' : 'pwm-badge--red'; ?>"><?php echo esc_html( $f->last_run_status ); ?></span>
                <?php endif; ?>
                <?php else : ?>
                <span class="pwm-badge pwm-badge--gray"><?php esc_html_e( 'Disabled', 'realwise-mls' ); ?></span>
                <?php endif; ?>
            </td>
            <td><?php echo $f->last_run ? esc_html( date_i18n( 'M j, Y g:i a', strtotime( $f->last_run ) ) ) : '—'; ?></td>
            <td><?php echo esc_html( $next_runs[$f->id] ?? '—' ); ?></td>
            <td>
                <button class="button pwm-run-now" data-feed="<?php echo (int) $f->id; ?>" <?php echo ! $f->active ? 'disabled' : ''; ?>><?php esc_html_e( 'Run Now', 'realwise-mls' ); ?></button>
                <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwm-feeds', 'edit' => $f->id ] , admin_url('admin.php') ) ); ?>" class="button"><?php esc_html_e( 'Edit', 'realwise-mls' ); ?></a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p><a href="<?php echo esc_url( add_query_arg( 'page', 'pwm-feeds', admin_url('admin.php') ) ); ?>" class="button button-primary"><?php esc_html_e( '+ Add Feed', 'realwise-mls' ); ?></a></p>

    <h2><?php esc_html_e( 'Recent Import Log', 'realwise-mls' ); ?></h2>
    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'Feed', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Started', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Status', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Fetched', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Inserted', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Updated', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Skipped', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Time', 'realwise-mls' ); ?></th>
        </tr></thead>
        <tbody>
        <?php foreach ( $logs as $log ) :
            $duration = $log->finished_at ? round( ( strtotime($log->finished_at) - strtotime($log->started_at) ) ) . 's' : '…';
        ?>
        <tr>
            <td><?php echo esc_html( $log->feed_label ); ?></td>
            <td><?php echo esc_html( date_i18n( 'M j, g:i a', strtotime( $log->started_at ) ) ); ?></td>
            <td><span class="pwm-badge <?php echo $log->status === 'success' ? 'pwm-badge--green' : ($log->status === 'running' ? 'pwm-badge--blue' : 'pwm-badge--red'); ?>"><?php echo esc_html( $log->status ); ?></span></td>
            <td><?php echo (int) $log->records_fetched; ?></td>
            <td><?php echo (int) $log->records_inserted; ?></td>
            <td><?php echo (int) $log->records_updated; ?></td>
            <td><?php echo (int) $log->records_skipped; ?></td>
            <td><?php echo esc_html( $duration ); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div id="pwm-run-status" style="margin-top:12px;"></div>
</div>
