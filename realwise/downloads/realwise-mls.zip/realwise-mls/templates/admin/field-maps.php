<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwm-admin">
    <h1><?php esc_html_e( 'Field Maps', 'realwise-mls' ); ?></h1>
    <form method="get">
        <input type="hidden" name="page" value="pwm-fieldmaps">
        <label><?php esc_html_e( 'Select feed:', 'realwise-mls' ); ?>
            <select name="feed_id" onchange="this.form.submit()">
                <option value="0"><?php esc_html_e( '— Choose a feed —', 'realwise-mls' ); ?></option>
                <?php foreach ( $feeds as $f ) : ?>
                <option value="<?php echo (int)$f->id; ?>" <?php selected($feed_id,$f->id); ?>><?php echo esc_html($f->label); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
    </form>

    <?php if ( $feed_id ) : ?>
    <div class="notice notice-info inline" style="margin:12px 0"><p>
        <strong><?php esc_html_e( 'How field mapping works:', 'realwise-mls' ); ?></strong>
        <?php esc_html_e( 'each row maps a raw MLS field (left) to a RealWise database column (right) using a transform. The RESO defaults below cover most Bridge & Spark feeds out of the box — only change a row if your MLS uses a different field name or you need a different data type.', 'realwise-mls' ); ?>
        <br><strong><?php esc_html_e( 'Transforms:', 'realwise-mls' ); ?></strong>
        <code>string</code>, <code>float</code>/<code>int</code>, <code>bool</code>,
        <code>lowercase</code>/<code>uppercase</code>, <code>email</code>, <code>json</code>, <code>json_first</code>.
        <?php esc_html_e( 'Click Save on a row to persist your override.', 'realwise-mls' ); ?>
    </p></div>

    <table class="widefat" id="pwm-fieldmap-table">
        <thead><tr>
            <th><?php esc_html_e( 'MLS Field', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'RealWise Column', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Transform', 'realwise-mls' ); ?></th>
            <th><?php esc_html_e( 'Action', 'realwise-mls' ); ?></th>
        </tr></thead>
        <tbody>
        <?php
        // Merge defaults with saved overrides
        $saved_map = [];
        foreach ( $maps as $rw_item ) { $saved_map[$rw_item->mls_field] = $rw_item; }
        foreach ( $defaults as $mls_field => $spec ) :
            $override = $saved_map[$mls_field] ?? null;
        ?>
        <tr class="pwm-map-row" data-field="<?php echo esc_attr($mls_field); ?>">
            <td><code><?php echo esc_html($mls_field); ?></code></td>
            <td>
                <select class="pwm-pw-col" style="width:180px">
                    <?php foreach ($pw_cols as $col) : ?>
                    <option value="<?php echo esc_attr($col); ?>" <?php selected(($override->pw_column ?? $spec['column']), $col); ?>><?php echo esc_html($col); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td>
                <select class="pwm-transform" style="width:120px">
                    <?php foreach (['string','float','int','bool','lowercase','uppercase','email','json','json_first'] as $t) : ?>
                    <option value="<?php echo esc_attr($t); ?>" <?php selected(($override->transform ?? $spec['transform']), $t); ?>><?php echo esc_html($t); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
            <td><button class="button pwm-save-map" data-feed="<?php echo (int)$feed_id; ?>" data-field="<?php echo esc_attr($mls_field); ?>"><?php esc_html_e( 'Save', 'realwise-mls' ); ?></button></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
