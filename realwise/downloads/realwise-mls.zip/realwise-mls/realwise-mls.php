<?php
/**
 * Plugin Name: RealWise MLS
 * Plugin URI:  https://wprealwise.com
 * Description: MLS import engine with Bridge Interactive, Spark, RETS, ATTOM, and Crexi adapters. Scheduled imports, field mapping, and import log. Requires the RealWise plugin (free) for the listings it imports into.
 * Version:     1.0.0
 * Author:      RealWise
 * Author URI:  https://wprealwise.com
 * License:     GPL-2.0+
 * Text Domain: realwise-mls
 * Requires PHP: 8.0
 * Requires Plugins: realwise
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'PWM_VERSION', '1.0.0' );
define( 'PWM_DIR',     plugin_dir_path( __FILE__ ) );
define( 'PWM_URL',     plugin_dir_url(  __FILE__ ) );

// ── Commercial distribution: licensing + self-hosted updates ──────────────────
// The store that issues licenses and serves updates (EDD Software Licensing).
if ( ! defined( 'PWM_STORE_URL' ) ) define( 'PWM_STORE_URL', 'https://wprealwise.com' );
if ( ! defined( 'PWM_ITEM_NAME' ) ) define( 'PWM_ITEM_NAME', 'RealWise MLS' );

foreach ( [
    'class-pwm-db.php',
    'class-pwm-field-map.php',
    'class-pwm-importer.php',
    'class-pwm-scheduler.php',
    'adapters/class-pwm-adapter-base.php',
    'adapters/class-pwm-adapter-reso.php',      // generic RESO Web API (load before vendor presets)
    'adapters/class-pwm-adapter-vendors.php',   // Trestle, MLS Grid, Paragon, Rapattoni, Constellation1
    'adapters/class-pwm-adapter-bridge.php',
    'adapters/class-pwm-adapter-spark.php',     // Spark / FlexMLS
    'adapters/class-pwm-adapter-simplyrets.php',
    'adapters/class-pwm-adapter-rets.php',
    'adapters/class-pwm-adapter-attom.php',
    'adapters/class-pwm-adapter-crexi.php',
    'adapters/class-pwm-adapter-csv.php',
    'adapters/class-pwm-adapter-demo.php',
    'class-pwm-license.php',
    'class-pwm-updater.php',
    'class-pwm-admin.php',
] as $f ) {
    require_once PWM_DIR . 'includes/' . $f;
}

register_activation_hook(   __FILE__, function () {
    PWM_DB::install();
    PWM_Scheduler::sync_schedules(); // set up crons at activation time
} );
register_deactivation_hook( __FILE__, function () {
    PWM_Scheduler::clear_schedules();
    wp_clear_scheduled_hook( PWM_License::CRON_HOOK );
} );

// Translations are auto-loaded by WordPress.org for the plugin slug (WP 4.6+).

add_action( 'plugins_loaded', function () {
    // Feeds, field mappings, schedules and the import log are all manageable on
    // their own. Imported records are written into the RealWise listings database, so the
    // actual import step needs it active (the importer guards for this); a soft
    // notice tells the admin without blocking any of this plugin's own CRUD.
    if ( ! class_exists( 'PWL_DB' ) && is_admin() ) {
        add_action( 'admin_notices', function () {
            $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
            if ( $screen && strpos( $screen->id, 'pwm-' ) !== false ) {
                echo '<div class="notice notice-info is-dismissible"><p><strong>RealWise MLS</strong> '
                   . esc_html__( 'lets you configure feeds now. Install the RealWise plugin to import the data into your listings.', 'realwise-mls' )
                   . '</p></div>';
            }
        } );
    }
    PWM_Scheduler::init();
    if ( is_admin() ) {
        PWM_Admin::init();
        PWM_License::init();
    }
    // Self-hosted updates run on the front end too (WP-Cron checks for updates there).
    new PWM_Updater( __FILE__, PWM_VERSION, PWM_STORE_URL, PWM_ITEM_NAME );
} );

// register_hooks() in PWM_Scheduler::init() already covers both pwm_run_import_{id}
// and pwm_run_import_now_{id} — the latter is registered inside ajax_run_now and
// fires correctly because init runs before WP-Cron dispatches the event.


// ── WPRealWise.com admin credit ──────────────────────────────────────────────
if ( ! function_exists( 'realwise_admin_credit' ) ) {
    function realwise_admin_credit( $default, $screen_match ) {
        $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
        if ( $screen && strpos( $screen->id, $screen_match ) !== false ) {
            return 'Built with <span style="color:#e25555">&#9829;</span> by <a href="https://wprealwise.com" target="_blank" rel="noopener"><strong>WPRealWise.com</strong></a> &mdash; the complete real-estate plugin suite.';
        }
        return $default;
    }
}
add_filter( 'admin_footer_text', function ( $text ) {
    return realwise_admin_credit( $text, 'pwm-' );
} );
