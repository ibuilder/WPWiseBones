=== RealWise MLS ===
Contributors: realwise
Tags: real estate, realtor, idx, property, listings
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Import MLS listings on a schedule with field mapping and an import log. Supports the RESO Web API standard plus every major provider.

== Description ==

Import MLS listings on a schedule, with per-feed field mapping and a full import log. Built around the RESO Web API (OData) standard so it works with virtually any MLS, plus named presets and non-OData providers.

**Supported MLS systems & data sources**

* RESO Web API — generic; works with any MLS exposing a RESO/OData endpoint (bearer, OAuth2, or token auth)
* Bridge Interactive (Zillow Group)
* CoreLogic Trestle
* MLS Grid
* Paragon / ICE (Black Knight)
* Rapattoni
* Constellation1
* Spark Platform — **this is how FlexMLS feeds connect**
* SimplyRETS
* ATTOM Data
* Crexi (commercial)
* RETS (legacy, requires phRETS)
* CSV / IDX file (URL or uploaded file — for nightly file drops)
* Demo — six bundled sample listings, no credentials needed, to test the pipeline

Records from every source are normalized to the RESO Data Dictionary and mapped to RealWise listing fields; asset type is derived automatically from PropertyType. Each feed runs on its own schedule with throttling, de-listing of stale records, and a detailed import log.

Part of the RealWise suite — a modular real-estate platform. Each plugin works on its own and integrates automatically with its companions when present.

**Shortcodes:** (admin only)

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install the ZIP via Plugins → Add New → Upload.
2. Activate through the 'Plugins' menu in WordPress.
3. Open the plugin's admin page and follow the "Getting Started & Tips" panel.

== Frequently Asked Questions ==

= Does this require other RealWise plugins? =
Most plugins enhance RealWise Listings but degrade gracefully when it is not active. The RealWise Suite control panel shows the full dependency map.

= Is my data removed on uninstall? =
Yes. Each plugin ships an uninstall routine that drops its tables and options when deleted (not merely deactivated).

== External services ==

This plugin imports property listings from MLS data providers. It connects to a provider only when you configure a feed with that provider's adapter and API credentials, and only on the schedule you set. Each request sends your API key and the search filters you configure (asset types, ZIP codes); listing data is received and stored locally.

Supported providers (you choose one or more per feed):

1. Bridge Interactive — https://bridgedataoutput.com/docs (terms & privacy on their site)
2. Spark Platform — https://sparkplatform.com/docs (terms & privacy on their site)
3. RETS (your MLS's RETS server) — terms governed by your MLS membership agreement
4. ATTOM Data — Terms: https://www.attomdata.com/terms/ — Privacy: https://www.attomdata.com/privacy-policy/
5. Crexi — https://www.crexi.com/ (terms & privacy on their site)

No connection is made until you add a feed and enter credentials.

**Licensing & updates (wprealwise.com).** As a commercial plugin, RealWise MLS connects to the RealWise store at https://wprealwise.com to activate your license key, revalidate it once daily, and check for plugin updates. These requests send your license key and your site URL only. This happens after you enter a license key on the License screen, plus the automatic daily/update checks while a key is stored. Terms: https://wprealwise.com/terms — Privacy: https://wprealwise.com/privacy

== Changelog ==

= 1.0.0 =
* Initial release.
