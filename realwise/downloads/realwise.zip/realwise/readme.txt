=== RealWise ===
Contributors: realwise
Tags: real estate, idx, property listings, crm, property management
Requires at least: 6.0
Tested up to: 6.8
Requires PHP: 8.0
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

The complete real-estate platform for WordPress: listings, search, investor proformas, CRM, agent portal, property management, and tours.

== Description ==

RealWise is an all-in-one real-estate platform. Six integrated modules ship in a single plugin:

* **Listings & Search** — searchable listings with Walk Score, crime grades, school ratings, an interactive map, a mortgage calculator, saved searches with email alerts, comparable sales, and a REST API.
* **Developer / Investor** — full proforma (NPV, IRR, DSCR, cash-on-cash), a 28-item renovation cost estimator, a fix-and-flip ARV analyzer, and an automated deal score.
* **CRM** — a drag-and-drop lead pipeline that auto-captures inquiries, saved searches and tour requests, with scoring, round-robin assignment, tasks, and an email drip sequence.
* **Agent Portal** — a front-end, role-gated dashboard where agents manage their own listings, leads, and profile.
* **Property Management** — properties, units, leases, a tenant portal, online rent payments (Stripe), late fees, and maintenance requests.
* **Tours & Scheduling** — a "request a tour" booking flow with availability windows, .ics invites, reminders, and automatic lead capture.

For automated MLS imports (Bridge, Spark/FlexMLS, RESO Web API, Trestle, MLS Grid, ATTOM, Crexi, RETS, CSV, and more), install the companion **RealWise MLS** plugin.

**Key shortcodes:** `[pwl_search]`, `[pwl_listing]`, `[pwl_mortgage]`, `[pwl_saved_searches]`, `[pwd_proforma]`, `[pwd_flip]`, `[pwd_renovation]`, `[pwc_lead_form]`, `[pwap_dashboard]`, `[pwpm_tenant_portal]`, `[pwt_request_tour]`.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/`, or install the ZIP via Plugins → Add New → Upload.
2. Activate through the 'Plugins' menu — all modules and their database tables are set up automatically.
3. Open **RealWise** in the admin menu and follow the "Getting Started" panel: add API keys, then create pages for `[pwl_search]` and `[pwl_listing]` and set them under Settings.

== Frequently Asked Questions ==

= Do I need the MLS plugin? =
No. RealWise is fully functional on its own — add listings manually or via the REST API. Install RealWise MLS only if you want to auto-import from an MLS/IDX feed.

= Is my data removed on uninstall? =
Yes. Deleting the plugin drops every table and option, clears scheduled events, and removes the roles it created. Tenant and agent user accounts are preserved (only their extra role is removed).

== External services ==

Features that call third-party services do so only when enabled and configured:

1. OpenStreetMap — map tiles render the interactive map in the visitor's browser. Terms: https://operations.osmfoundation.org/policies/tiles/ — Privacy: https://wiki.osmfoundation.org/wiki/Privacy_Policy
2. Walk Score, CrimeGrade, GreatSchools, FRED, ATTOM, Google Maps geocoding (optional, each requires its own API key) — used by the listings scores, mortgage rate, and comps features. Data sent is limited to a property's address/coordinates/ZIP. See each provider's site for terms and privacy.
3. Stripe (optional) — processes online rent payments when Stripe keys are configured. Card data never touches this site. Terms: https://stripe.com/legal — Privacy: https://stripe.com/privacy

No data is sent to any service unless its feature is enabled.

== Bundled libraries ==

Bundled locally (no remote/CDN loading), both GPL-compatible:

* Leaflet 1.9.4 — BSD-2-Clause — https://leafletjs.com
* Chart.js 4.4.0 — MIT — https://www.chartjs.org

== Changelog ==

= 1.0.0 =
* Initial release — Listings, Developer, CRM, Agent Portal, Property Management, and Tours unified into a single plugin.
