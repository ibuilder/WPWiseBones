/* RealWise CRM — front-end lead form */
(function ($) {
  'use strict';
  $(function () {
    $('#pwc-lead-form').on('submit', function (e) {
      e.preventDefault();
      var $form = $(this);
      var $msg  = $form.find('.pwc-lead-form__msg').removeClass('ok err').text('');
      var $btn  = $form.find('button[type=submit]').prop('disabled', true);

      var data = { action: 'pwc_submit_lead', nonce: PWC.nonce, listing_id: $form.data('listing') || 0 };
      $form.serializeArray().forEach(function (f) { data[f.name] = f.value; });

      $.post(PWC.ajax_url, data, function (res) {
        $btn.prop('disabled', false);
        if (res.success) {
          $msg.addClass('ok').text(res.data.message);
          $form[0].reset();
        } else {
          $msg.addClass('err').text((res.data && res.data.message) || 'Something went wrong.');
        }
      });
    });
  });
}(jQuery));
