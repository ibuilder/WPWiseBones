/* RealWise CRM — admin (kanban drag, lead detail actions) */
(function ($) {
  'use strict';

  // ── Kanban drag-and-drop ────────────────────────────────────────────────────
  function initBoard() {
    if (!$('.pwc-board').length || !$.fn.sortable) return;
    $('.pwc-col__body').sortable({
      connectWith: '.pwc-col__body',
      placeholder: 'pwc-card-placeholder',
      tolerance: 'pointer',
      receive: function (event, ui) {
        var leadId = ui.item.data('id');
        var stage  = $(this).data('stage');
        $.post(PWC_Admin.ajax_url, {
          action: 'pwc_update_stage', nonce: PWC_Admin.nonce,
          lead_id: leadId, stage: stage
        }, function (res) {
          if (!res.success) location.reload();
          else refreshCounts();
        });
      }
    });
  }

  function refreshCounts() {
    $('.pwc-col').each(function () {
      $(this).find('.pwc-col__count').text($(this).find('.pwc-card').length);
    });
  }

  // ── Lead detail ──────────────────────────────────────────────────────────────
  function initDetail() {
    var leadId = $('.pwc-lead-detail').data('lead');
    if (!leadId) return;

    $('#pwc-note-btn').on('click', function () {
      var note = $('#pwc-note-input').val().trim();
      if (!note) return;
      $.post(PWC_Admin.ajax_url, { action: 'pwc_add_note', nonce: PWC_Admin.nonce, lead_id: leadId, note: note }, function (res) {
        if (res.success) {
          $('#pwc-timeline').prepend(
            '<li class="pwc-timeline__item pwc-timeline__item--note"><span class="pwc-timeline__when">' +
            res.data.when + '</span><span class="pwc-timeline__text">' + $('<div>').text(note).html() + '</span></li>'
          );
          $('#pwc-note-input').val('');
        }
      });
    });

    $('#pwc-task-btn').on('click', function () {
      var title = $('#pwc-task-title').val().trim();
      var due   = $('#pwc-task-due').val();
      if (!title) return;
      $.post(PWC_Admin.ajax_url, { action: 'pwc_add_task', nonce: PWC_Admin.nonce, lead_id: leadId, title: title, due_date: due }, function (res) {
        if (res.success) location.reload();
      });
    });

    $(document).on('change', '.pwc-task-check', function () {
      var $cb = $(this);
      $.post(PWC_Admin.ajax_url, { action: 'pwc_toggle_task', nonce: PWC_Admin.nonce, task_id: $cb.data('id'), completed: $cb.is(':checked') ? 1 : 0 }, function (res) {
        if (res.success) $cb.closest('li').toggleClass('done', $cb.is(':checked'));
      });
    });

    $('#pwc-drip-toggle').on('change', function () {
      $.post(PWC_Admin.ajax_url, { action: 'pwc_toggle_drip', nonce: PWC_Admin.nonce, lead_id: leadId, active: $(this).is(':checked') ? 1 : 0 });
    });
  }

  $(function () { initBoard(); initDetail(); });
}(jQuery));
