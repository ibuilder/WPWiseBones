<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWC_Capture — bridges RealWise Listings lead-generating events into the CRM.
 *
 * RealWise Listings fires no custom hooks today, so we attach to the same
 * AJAX actions it registers, running AFTER its handler via a late priority and
 * reading the same $_POST. This keeps Listings untouched while still capturing
 * every contact-agent, saved-property, and saved-search event as a CRM lead.
 */
class PWC_Capture {

    public static function init(): void {
        // Fire after the Listings handlers (which call wp_send_json and exit),
        // so we hook the *_before pattern via a higher-priority shim instead.
        add_action( 'wp_ajax_pwl_contact_agent',        [ __CLASS__, 'on_contact_agent' ], 1 );
        add_action( 'wp_ajax_nopriv_pwl_contact_agent', [ __CLASS__, 'on_contact_agent' ], 1 );

        add_action( 'wp_ajax_pwl_save_listing', [ __CLASS__, 'on_save_listing' ], 1 );
        add_action( 'wp_ajax_pwl_save_search',  [ __CLASS__, 'on_save_search'  ], 1 );

        // Tours plugin fires this when a tour is requested
        add_action( 'pwt_tour_requested', [ __CLASS__, 'on_tour_requested' ], 10, 1 );

        // Suppress the Listings plugin's plainer agent email — the CRM sends a
        // richer one with a pipeline link, so we avoid the duplicate.
        add_filter( 'pwl_send_agent_email', '__return_false' );
    }

    /**
     * Listing inquiry → high-intent lead.
     * Runs at priority 1 (before Listings' own handler) so we capture even
     * though that handler ends the request with wp_send_json.
     */
    /**
     * Wrap an intake so a CRM-side error can NEVER break the host plugin's
     * AJAX flow (these run at priority 1, before the Listings handler).
     */
    private static function safe_intake( array $data ): void {
        try {
            PWC_Leads::intake( $data );
        } catch ( \Throwable $e ) {
            if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
                error_log( 'PWC capture failed: ' . $e->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log -- Debug-only diagnostic, guarded by WP_DEBUG.
            }
            // Swallow — the host action (contact/save) must still succeed.
        }
    }

    public static function on_contact_agent(): void {
        if ( ! check_ajax_referer( 'pwl_nonce', 'nonce', false ) ) return;
        if ( ! is_user_logged_in() ) return;
        $user       = wp_get_current_user();
        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
        $message    = isset( $_POST['message'] ) ? wp_kses( wp_unslash( $_POST['message'] ), [] ) : '';

        self::safe_intake( [
            'name'          => $user->display_name,
            'email'         => $user->user_email,
            'wp_user_id'    => $user->ID,
            'listing_id'    => $listing_id ?: null,
            'message'       => $message,
            'source'        => 'contact_agent',
            'source_detail' => $listing_id ? 'Listing #' . $listing_id : '',
        ] );
        // Do not exit — let the Listings handler complete normally.
    }

    public static function on_save_listing(): void {
        if ( ! check_ajax_referer( 'pwl_nonce', 'nonce', false ) ) return;
        if ( ! is_user_logged_in() ) return;
        $user       = wp_get_current_user();
        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
        self::safe_intake( [
            'name'          => $user->display_name,
            'email'         => $user->user_email,
            'wp_user_id'    => $user->ID,
            'listing_id'    => $listing_id ?: null,
            'source'        => 'saved_property',
            'source_detail' => $listing_id ? 'Saved listing #' . $listing_id : '',
        ] );
    }

    public static function on_save_search(): void {
        if ( ! check_ajax_referer( 'pwl_nonce', 'nonce', false ) ) return;
        if ( ! is_user_logged_in() ) return;
        $user = wp_get_current_user();
        self::safe_intake( [
            'name'          => $user->display_name,
            'email'         => $user->user_email,
            'wp_user_id'    => $user->ID,
            'source'        => 'saved_search',
            'source_detail' => sanitize_text_field( wp_unslash( $_POST['label'] ?? '' ) ),
        ] );
    }

    /**
     * @param array $tour  Tour data from the Tours plugin.
     */
    public static function on_tour_requested( array $tour ): void {
        self::safe_intake( [
            'name'          => $tour['name']  ?? '',
            'email'         => $tour['email'] ?? '',
            'phone'         => $tour['phone'] ?? '',
            'listing_id'    => $tour['listing_id'] ?? null,
            'message'       => $tour['message'] ?? '',
            'source'        => 'tour_request',
            'source_detail' => isset( $tour['requested_time'] ) ? 'Requested: ' . $tour['requested_time'] : '',
        ] );
    }
}
