<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWC_Admin — pipeline (kanban + list), lead detail, settings.
 */
class PWC_Admin {

    public static function init(): void {
        add_action( 'admin_menu',            [ __CLASS__, 'menu' ] );
        add_action( 'admin_init',            [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
        add_action( 'admin_post_pwc_save_lead', [ __CLASS__, 'save_lead' ] );
        add_action( 'admin_post_pwc_delete_lead', [ __CLASS__, 'delete_lead' ] );
        add_action( 'admin_post_pwc_export_csv', [ __CLASS__, 'export_csv' ] );
    }

    public static function export_csv(): void {
        if ( ! current_user_can( 'pwc_manage_leads' ) && ! current_user_can( 'manage_options' ) ) wp_die( 'Denied' );
        check_admin_referer( 'pwc_export_csv' );
        $result = PWC_DB::get_leads( [
            'stage'    => sanitize_key( wp_unslash( $_GET['stage'] ?? '' ) ),
            'source'   => sanitize_key( wp_unslash( $_GET['source'] ?? '' ) ),
            'search'   => sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ),
            'per_page' => 10000,
        ] );
        nocache_headers();
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=realwise-leads-' . current_time( 'Y-m-d' ) . '.csv' );
        // Streaming a download to php://output (not a filesystem write); standard CSV-export pattern.
        $out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        fputcsv( $out, [ 'ID', 'Name', 'Email', 'Phone', 'Stage', 'Source', 'Score', 'Agent', 'Budget Min', 'Budget Max', 'Created', 'Updated' ] );
        foreach ( $result['leads'] as $l ) {
            fputcsv( $out, [
                $l->id, $l->name, $l->email, $l->phone,
                PWC_Leads::stage_label( $l->stage ), PWC_Leads::source_label( $l->source ), $l->score,
                $l->agent_id ? PWC_Leads::agent_name( (int) $l->agent_id ) : '',
                $l->budget_min, $l->budget_max, $l->created_at, $l->updated_at,
            ] );
        }
        fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        exit;
    }

    public static function menu(): void {
        add_menu_page( 'RealWise CRM', __( 'Leads', 'realwise' ), 'pwc_manage_leads', 'pwc-pipeline',
            [ __CLASS__, 'page_pipeline' ], 'dashicons-groups', 57 );
        add_submenu_page( 'pwc-pipeline', __( 'Pipeline', 'realwise' ),  __( 'Pipeline', 'realwise' ),  'pwc_manage_leads', 'pwc-pipeline', [ __CLASS__, 'page_pipeline' ] );
        add_submenu_page( 'pwc-pipeline', __( 'All Leads', 'realwise' ), __( 'All Leads', 'realwise' ), 'pwc_manage_leads', 'pwc-leads',    [ __CLASS__, 'page_leads' ] );
        add_submenu_page( 'pwc-pipeline', __( 'Settings', 'realwise' ),  __( 'Settings', 'realwise' ),  'manage_options',   'pwc-settings', [ __CLASS__, 'page_settings' ] );
    }

    public static function register_settings(): void {
        foreach ( [ 'pwc_assign_mode', 'pwc_agent_pool', 'pwc_drip_enabled', 'pwc_sms_enabled' ] as $key ) {
            register_setting( 'pwc_settings_group', $key, [ 'sanitize_callback' => 'sanitize_text_field' ] );
        }
    }

    public static function assets( string $hook ): void {
        if ( strpos( $hook, 'pwc' ) === false ) return;
        wp_enqueue_style(  'pwc-admin', PWC_URL . 'assets/css/admin.css', [], PWC_VERSION );
        wp_enqueue_script( 'pwc-admin', PWC_URL . 'assets/js/admin.js', [ 'jquery', 'jquery-ui-sortable' ], PWC_VERSION, true );
        wp_localize_script( 'pwc-admin', 'PWC_Admin', [
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'pwc_admin_nonce' ),
        ] );
    }

    public static function page_pipeline(): void {
        $stages   = PWC_DB::STAGES;
        $counts   = PWC_DB::stage_counts();
        $by_stage = [];
        foreach ( $stages as $st ) {
            if ( in_array( $st, [ 'closed', 'lost' ], true ) ) continue; // keep board focused on the active funnel
            $by_stage[ $st ] = PWC_DB::get_leads( [ 'stage' => $st, 'per_page' => 100 ] )['leads'];
        }
        include PWC_DIR . 'templates/admin/pipeline.php';
    }

    public static function page_leads(): void {
        if ( isset( $_GET['lead'] ) ) {
            self::page_lead_detail( (int) $_GET['lead'] );
            return;
        }
        $page   = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $args   = [
            'stage'    => sanitize_key( wp_unslash( $_GET['stage'] ?? '' ) ),
            'source'   => sanitize_key( wp_unslash( $_GET['source'] ?? '' ) ),
            'search'   => sanitize_text_field( wp_unslash( $_GET['s'] ?? '' ) ),
            'page'     => $page,
            'per_page' => 50,
        ];
        $result = PWC_DB::get_leads( $args );
        $leads  = $result['leads'];
        $total  = $result['total'];
        $pages  = (int) ceil( $total / 50 );
        include PWC_DIR . 'templates/admin/leads.php';
    }

    private static function page_lead_detail( int $id ): void {
        $lead = PWC_DB::get_lead( $id );
        if ( ! $lead ) { echo '<div class="wrap"><h1>Lead not found</h1></div>'; return; }
        $activity = PWC_DB::get_activity( $id );
        $tasks    = PWC_DB::get_tasks( $id, 0, false );
        $agents   = self::agent_choices();
        $listing  = ( $lead->listing_id && class_exists( 'PWL_DB' ) ) ? PWL_DB::get_listing( (int) $lead->listing_id ) : null;
        include PWC_DIR . 'templates/admin/lead-detail.php';
    }

    public static function page_settings(): void {
        $agents = self::agent_choices();
        $drip   = PWC_Drip::sequence();
        include PWC_DIR . 'templates/admin/settings.php';
    }

    public static function agent_choices(): array {
        $out = [];
        if ( class_exists( 'PWL_DB' ) ) {
            global $wpdb;
            $rows = $wpdb->get_results( 'SELECT id, name FROM ' . PWL_DB::agents_table() . ' ORDER BY name ASC' );
            foreach ( $rows as $r ) $out[ (int) $r->id ] = $r->name;
        }
        return $out;
    }

    public static function save_lead(): void {
        if ( ! current_user_can( 'pwc_manage_leads' ) && ! current_user_can( 'manage_options' ) ) wp_die( 'Denied' );
        check_admin_referer( 'pwc_save_lead' );
        $id   = (int) ( $_POST['lead_id'] ?? 0 );
        $data = [
            'name'       => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
            'email'      => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ) ?: null,
            'phone'      => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ) ?: null,
            'stage'      => sanitize_key( wp_unslash( $_POST['stage'] ?? 'new' ) ),
            'agent_id'   => (int) ( $_POST['agent_id'] ?? 0 ) ?: null,
            'budget_min' => ( $_POST['budget_min'] ?? '' ) !== '' ? (float) $_POST['budget_min'] : null,
            'budget_max' => ( $_POST['budget_max'] ?? '' ) !== '' ? (float) $_POST['budget_max'] : null,
            'notes'      => sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) ),
        ];
        if ( $id ) {
            PWC_DB::update_lead( $id, $data );
        } else {
            $data['source'] = 'manual';
            $id = PWC_DB::create_lead( $data );
        }
        wp_safe_redirect( admin_url( 'admin.php?page=pwc-leads&lead=' . $id . '&msg=saved' ) );
        exit;
    }

    public static function delete_lead(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Denied' );
        check_admin_referer( 'pwc_delete_lead' );
        PWC_DB::delete_lead( (int) ( $_GET['lead'] ?? 0 ) );
        wp_safe_redirect( admin_url( 'admin.php?page=pwc-leads&msg=deleted' ) );
        exit;
    }
}

// Grant the lead-management capability to administrators on load.
add_action( 'admin_init', function () {
    $role = get_role( 'administrator' );
    if ( $role && ! $role->has_cap( 'pwc_manage_leads' ) ) {
        $role->add_cap( 'pwc_manage_leads' );
    }
} );
