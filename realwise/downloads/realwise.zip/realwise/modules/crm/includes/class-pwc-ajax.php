<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWC_Ajax — front-end lead form + admin pipeline actions.
 */
class PWC_Ajax {

    public static function init(): void {
        // Public lead form
        add_action( 'wp_ajax_pwc_submit_lead',        [ __CLASS__, 'submit_lead' ] );
        add_action( 'wp_ajax_nopriv_pwc_submit_lead', [ __CLASS__, 'submit_lead' ] );

        // Admin / agent actions (capability-checked)
        add_action( 'wp_ajax_pwc_update_stage',  [ __CLASS__, 'update_stage'  ] );
        add_action( 'wp_ajax_pwc_add_note',      [ __CLASS__, 'add_note'      ] );
        add_action( 'wp_ajax_pwc_assign_lead',   [ __CLASS__, 'assign_lead'   ] );
        add_action( 'wp_ajax_pwc_add_task',      [ __CLASS__, 'add_task'      ] );
        add_action( 'wp_ajax_pwc_toggle_task',   [ __CLASS__, 'toggle_task'   ] );
        add_action( 'wp_ajax_pwc_toggle_drip',   [ __CLASS__, 'toggle_drip'   ] );
    }

    /**
     * Per-IP rate limit. Returns false when the caller has exceeded the limit.
     */
    private static function throttle( string $bucket, int $max = 10, int $window = HOUR_IN_SECONDS ): bool {
        $ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'cli';
        $key = 'pwc_rl_' . $bucket . '_' . md5( $ip );
        $n   = (int) get_transient( $key );
        if ( $n >= $max ) return false;
        set_transient( $key, $n + 1, $window );
        return true;
    }

    // ── Public ────────────────────────────────────────────────────────────────
    public static function submit_lead(): void {
        if ( ! check_ajax_referer( 'pwc_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed.', 'realwise' ) ], 403 );
        }
        // Honeypot
        if ( ! empty( $_POST['pwc_hp'] ) ) wp_send_json_success(); // silently accept bots

        if ( ! self::throttle( 'lead', 10 ) ) {
            wp_send_json_error( [ 'message' => __( 'Too many submissions. Please try again later.', 'realwise' ) ], 429 );
        }

        $name  = sanitize_text_field( wp_unslash( $_POST['name']  ?? '' ) );
        $email = sanitize_email(       wp_unslash( $_POST['email'] ?? '' ) );
        $phone = sanitize_text_field(  wp_unslash( $_POST['phone'] ?? '' ) );
        if ( ! $email && ! $phone ) {
            wp_send_json_error( [ 'message' => __( 'Please provide an email or phone number.', 'realwise' ) ] );
        }

        $lead_id = PWC_Leads::intake( [
            'name'          => $name,
            'email'         => $email ?: null,
            'phone'         => $phone ?: null,
            'message'       => sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ),
            'listing_id'    => ( $lid = (int) ( $_POST['listing_id'] ?? 0 ) ) ?: null,
            'budget_min'    => ( $_POST['budget_min'] ?? '' ) !== '' ? (float) $_POST['budget_min'] : null,
            'budget_max'    => ( $_POST['budget_max'] ?? '' ) !== '' ? (float) $_POST['budget_max'] : null,
            'source'        => 'lead_form',
            'source_detail' => esc_url_raw( wp_unslash( $_POST['page_url'] ?? '' ) ),
        ] );
        wp_send_json_success( [ 'lead_id' => $lead_id, 'message' => __( 'Thanks! We will be in touch shortly.', 'realwise' ) ] );
    }

    // ── Admin / agent ───────────────────────────────────────────────────────────
    private static function can(): bool {
        return current_user_can( 'manage_options' ) || current_user_can( 'pwc_manage_leads' );
    }

    private static function guard(): void {
        if ( ! check_ajax_referer( 'pwc_admin_nonce', 'nonce', false ) || ! self::can() ) {
            wp_send_json_error( [ 'message' => __( 'Permission denied.', 'realwise' ) ], 403 );
        }
    }

    public static function update_stage(): void {
        self::guard();
        $id    = (int) ( $_POST['lead_id'] ?? 0 );
        $stage = sanitize_key( wp_unslash( $_POST['stage'] ?? '' ) );
        if ( ! $id ) wp_send_json_error();
        PWC_Leads::change_stage( $id, $stage );
        wp_send_json_success();
    }

    public static function add_note(): void {
        self::guard();
        $id   = (int) ( $_POST['lead_id'] ?? 0 );
        $note = sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) );
        if ( ! $id || ! $note ) wp_send_json_error();
        $aid = PWC_DB::log_activity( $id, 'note', $note );
        wp_send_json_success( [ 'activity_id' => $aid, 'when' => current_time( 'M j, Y g:i a' ) ] );
    }

    public static function assign_lead(): void {
        self::guard();
        $id    = (int) ( $_POST['lead_id'] ?? 0 );
        $agent = (int) ( $_POST['agent_id'] ?? 0 );
        if ( ! $id || ! $agent ) wp_send_json_error();
        PWC_Assignment::reassign( $id, $agent );
        wp_send_json_success( [ 'agent_name' => PWC_Leads::agent_name( $agent ) ] );
    }

    public static function add_task(): void {
        self::guard();
        $id    = (int) ( $_POST['lead_id'] ?? 0 );
        $title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
        $due   = sanitize_text_field( wp_unslash( $_POST['due_date'] ?? '' ) );
        if ( ! $id || ! $title ) wp_send_json_error();
        $lead    = PWC_DB::get_lead( $id );
        $task_id = PWC_DB::create_task( [
            'lead_id'  => $id,
            'agent_id' => $lead->agent_id ?? null,
            'title'    => $title,
            'due_date' => $due ? gmdate( 'Y-m-d H:i:s', strtotime( $due ) ) : null, // user-picked date, formatted as-is
        ] );
        wp_send_json_success( [ 'task_id' => $task_id ] );
    }

    public static function toggle_task(): void {
        self::guard();
        $id   = (int) ( $_POST['task_id'] ?? 0 );
        $done = ! empty( $_POST['completed'] );
        if ( ! $id ) wp_send_json_error();
        PWC_DB::toggle_task( $id, $done );
        wp_send_json_success();
    }

    public static function toggle_drip(): void {
        self::guard();
        $id     = (int) ( $_POST['lead_id'] ?? 0 );
        $active = ! empty( $_POST['active'] ) ? 1 : 0;
        if ( ! $id ) wp_send_json_error();
        PWC_DB::update_lead( $id, [ 'drip_active' => $active ] );
        wp_send_json_success();
    }
}
