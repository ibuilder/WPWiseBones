<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWC_DB — schema and query helpers for RealWise CRM.
 */
class PWC_DB {

    public static function leads_table()    { global $wpdb; return $wpdb->prefix . 'pwc_leads'; }
    public static function activity_table() { global $wpdb; return $wpdb->prefix . 'pwc_lead_activity'; }
    public static function tasks_table()    { global $wpdb; return $wpdb->prefix . 'pwc_tasks'; }

    const STAGES = [ 'new', 'contacted', 'nurturing', 'qualified', 'showing', 'offer', 'closed', 'lost' ];

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::leads_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name          VARCHAR(150) DEFAULT NULL,
            email         VARCHAR(190) DEFAULT NULL,
            phone         VARCHAR(40)  DEFAULT NULL,
            stage         VARCHAR(20)  NOT NULL DEFAULT 'new',
            source        VARCHAR(40)  DEFAULT 'website',
            source_detail VARCHAR(255) DEFAULT NULL,
            score         SMALLINT     DEFAULT 0,
            listing_id    BIGINT UNSIGNED DEFAULT NULL,
            agent_id      BIGINT UNSIGNED DEFAULT NULL,
            wp_user_id    BIGINT UNSIGNED DEFAULT NULL,
            budget_min    DECIMAL(14,2) DEFAULT NULL,
            budget_max    DECIMAL(14,2) DEFAULT NULL,
            message       TEXT,
            notes         TEXT,
            drip_step     SMALLINT     DEFAULT 0,
            drip_active   TINYINT(1)   DEFAULT 1,
            last_activity DATETIME     DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY stage (stage),
            KEY agent_id (agent_id),
            KEY email (email),
            KEY source (source)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::activity_table() . " (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            lead_id     BIGINT UNSIGNED NOT NULL,
            type        VARCHAR(30) NOT NULL DEFAULT 'note',
            content     TEXT,
            meta        TEXT,
            author_id   BIGINT UNSIGNED DEFAULT NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY lead_id (lead_id),
            KEY type (type)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::tasks_table() . " (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            lead_id     BIGINT UNSIGNED NOT NULL,
            agent_id    BIGINT UNSIGNED DEFAULT NULL,
            title       VARCHAR(255) NOT NULL,
            due_date    DATETIME     DEFAULT NULL,
            completed   TINYINT(1)   DEFAULT 0,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY lead_id (lead_id),
            KEY agent_id (agent_id),
            KEY completed (completed)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) dbDelta( $q );
        update_option( 'pwc_db_version', PWC_VERSION );
    }

    // ── Leads ────────────────────────────────────────────────────────────────
    public static function create_lead( array $data ): int {
        global $wpdb;
        $data = wp_parse_args( $data, [
            'stage'         => 'new',
            'source'        => 'website',
            'last_activity' => current_time( 'mysql' ),
        ] );
        // De-dupe by email: if an open lead exists, return it instead of creating a duplicate
        if ( ! empty( $data['email'] ) ) {
            $existing = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM " . self::leads_table() . " WHERE email = %s AND stage NOT IN ('closed','lost') ORDER BY id DESC LIMIT 1",
                $data['email']
            ) );
            if ( $existing ) return (int) $existing->id;
        }
        $wpdb->insert( self::leads_table(), $data );
        return $wpdb->insert_id;
    }

    public static function update_lead( int $id, array $data ): void {
        global $wpdb;
        $wpdb->update( self::leads_table(), $data, [ 'id' => $id ] );
    }

    public static function get_lead( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::leads_table() . ' WHERE id = %d', $id ) );
    }

    public static function delete_lead( int $id ): void {
        global $wpdb;
        $wpdb->delete( self::leads_table(),    [ 'id' => $id ] );
        $wpdb->delete( self::activity_table(), [ 'lead_id' => $id ] );
        $wpdb->delete( self::tasks_table(),    [ 'lead_id' => $id ] );
    }

    /**
     * @param array $args { stage, agent_id, source, search, per_page, page, order_by, order }
     */
    public static function get_leads( array $args = [] ): array {
        global $wpdb;
        $args = wp_parse_args( $args, [
            'stage' => '', 'agent_id' => 0, 'source' => '', 'search' => '',
            'per_page' => 50, 'page' => 1, 'order_by' => 'updated_at', 'order' => 'DESC',
        ] );
        $where = [ '1=1' ]; $params = [];
        if ( $args['stage'] )    { $where[] = 'stage = %s';     $params[] = $args['stage']; }
        if ( $args['agent_id'] ) { $where[] = 'agent_id = %d';  $params[] = (int) $args['agent_id']; }
        if ( $args['source'] )   { $where[] = 'source = %s';    $params[] = $args['source']; }
        if ( $args['search'] ) {
            $like = '%' . $wpdb->esc_like( $args['search'] ) . '%';
            $where[] = '(name LIKE %s OR email LIKE %s OR phone LIKE %s)';
            $params  = array_merge( $params, [ $like, $like, $like ] );
        }
        $allowed = [ 'updated_at', 'created_at', 'score', 'name', 'stage' ];
        $ob      = in_array( $args['order_by'], $allowed, true ) ? $args['order_by'] : 'updated_at';
        $dir     = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
        $where_sql = implode( ' AND ', $where );
        $offset  = ( max( 1, (int) $args['page'] ) - 1 ) * (int) $args['per_page'];
        $table   = self::leads_table();

        $count_sql = "SELECT COUNT(*) FROM $table WHERE $where_sql";
        $data_sql  = "SELECT * FROM $table WHERE $where_sql ORDER BY $ob $dir LIMIT %d OFFSET %d";

        if ( $params ) {
            $total = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, ...$params ) );
            $rows  = $wpdb->get_results( $wpdb->prepare( $data_sql, ...array_merge( $params, [ (int) $args['per_page'], $offset ] ) ) );
        } else {
            $total = (int) $wpdb->get_var( $count_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $rows  = $wpdb->get_results( $wpdb->prepare( $data_sql, (int) $args['per_page'], $offset ) );
        }
        return [ 'leads' => $rows ?: [], 'total' => $total ];
    }

    public static function stage_counts(): array {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT stage, COUNT(*) c FROM " . self::leads_table() . " GROUP BY stage" );
        $out  = array_fill_keys( self::STAGES, 0 );
        foreach ( $rows as $r ) { $out[ $r->stage ] = (int) $r->c; }
        return $out;
    }

    // ── Activity ─────────────────────────────────────────────────────────────
    public static function log_activity( int $lead_id, string $type, string $content = '', $meta = null, ?int $author_id = null ): int {
        global $wpdb;
        $wpdb->insert( self::activity_table(), [
            'lead_id'   => $lead_id,
            'type'      => $type,
            'content'   => $content,
            'meta'      => $meta ? wp_json_encode( $meta ) : null,
            'author_id' => $author_id ?? get_current_user_id(),
        ] );
        $wpdb->update( self::leads_table(), [ 'last_activity' => current_time( 'mysql' ) ], [ 'id' => $lead_id ] );
        return $wpdb->insert_id;
    }

    public static function get_activity( int $lead_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::activity_table() . ' WHERE lead_id = %d ORDER BY created_at DESC', $lead_id
        ) ) ?: [];
    }

    // ── Tasks ────────────────────────────────────────────────────────────────
    public static function create_task( array $data ): int {
        global $wpdb;
        $wpdb->insert( self::tasks_table(), $data );
        return $wpdb->insert_id;
    }

    public static function toggle_task( int $id, bool $completed ): void {
        global $wpdb;
        $wpdb->update( self::tasks_table(), [ 'completed' => $completed ? 1 : 0 ], [ 'id' => $id ] );
    }

    public static function get_tasks( int $lead_id = 0, int $agent_id = 0, bool $open_only = true ): array {
        global $wpdb;
        $where = [ '1=1' ]; $params = [];
        if ( $lead_id )  { $where[] = 'lead_id = %d';  $params[] = $lead_id; }
        if ( $agent_id ) { $where[] = 'agent_id = %d'; $params[] = $agent_id; }
        if ( $open_only ){ $where[] = 'completed = 0'; }
        $where_sql = implode( ' AND ', $where );
        $sql = "SELECT * FROM " . self::tasks_table() . " WHERE $where_sql ORDER BY due_date ASC";
        return ( $params
            ? $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) )
            : $wpdb->get_results( $sql ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        ) ?: [];
    }
}
