<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWC_Drip — automated email follow-up sequence.
 *
 * A configurable multi-step sequence. Each step has a delay (days after the
 * previous step) and a subject/body template. The cron walks active leads and
 * sends the next due step. SMS is supported via a pluggable gateway filter.
 */
class PWC_Drip {

    public static function init(): void {
        add_action( 'pwc_run_drip', [ __CLASS__, 'run' ] );
    }

    public static function ensure_scheduled(): void {
        if ( ! wp_next_scheduled( 'pwc_run_drip' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'pwc_run_drip' );
        }
    }

    public static function clear_scheduled(): void {
        wp_clear_scheduled_hook( 'pwc_run_drip' );
    }

    /**
     * Default sequence. Admins override via the pwc_drip_sequence option.
     * delay_days is measured from the lead's creation for step 0, then from the
     * previous step for subsequent steps (cumulative handled in run()).
     */
    public static function sequence(): array {
        $saved = get_option( 'pwc_drip_sequence' );
        if ( is_array( $saved ) && $saved ) return $saved;
        return [
            [ 'delay_days' => 0, 'subject' => 'Thanks for reaching out!',
              'body' => "Hi {name},\n\nThanks for your interest. I'm here to help you find the right property. When is a good time to connect?\n\n— {agent}" ],
            [ 'delay_days' => 2, 'subject' => 'A few homes you might like',
              'body' => "Hi {name},\n\nI wanted to follow up and see if you had any questions. I can put together a personalized list of homes that match what you're looking for.\n\n— {agent}" ],
            [ 'delay_days' => 5, 'subject' => 'Still searching?',
              'body' => "Hi {name},\n\nJust checking in. The market moves fast — happy to set up alerts or schedule a tour whenever you're ready.\n\n— {agent}" ],
            [ 'delay_days' => 10, 'subject' => 'Here when you need me',
              'body' => "Hi {name},\n\nNo rush at all. Whenever you're ready to take the next step, I'm one reply away.\n\n— {agent}" ],
        ];
    }

    public static function run(): void {
        if ( ! get_option( 'pwc_drip_enabled', 1 ) ) return;
        global $wpdb;
        $sequence = self::sequence();
        $max_step = count( $sequence );

        $leads = $wpdb->get_results(
            "SELECT * FROM " . PWC_DB::leads_table() . "
             WHERE drip_active = 1 AND drip_step < $max_step
             AND stage NOT IN ('closed','lost') LIMIT 100"
        );

        foreach ( $leads as $lead ) {
            $step = (int) $lead->drip_step;
            if ( ! isset( $sequence[ $step ] ) ) continue;
            // Cumulative delay from lead creation
            $cumulative = 0;
            for ( $i = 0; $i <= $step; $i++ ) {
                $cumulative += (int) ( $sequence[ $i ]['delay_days'] ?? 0 );
            }
            $due = strtotime( $lead->created_at ) + $cumulative * DAY_IN_SECONDS;
            if ( time() < $due ) continue;
            if ( empty( $lead->email ) ) { PWC_DB::update_lead( (int) $lead->id, [ 'drip_active' => 0 ] ); continue; }

            self::send_step( $lead, $sequence[ $step ] );
            PWC_DB::update_lead( (int) $lead->id, [ 'drip_step' => $step + 1 ] );
            PWC_DB::log_activity( (int) $lead->id, 'drip', sprintf(
                /* translators: %d: step number */
                __( 'Drip email #%d sent', 'realwise' ), $step + 1
            ), null, 0 );
        }
    }

    private static function send_step( object $lead, array $step ): void {
        $agent  = $lead->agent_id ? PWC_Leads::agent_name( (int) $lead->agent_id ) : get_bloginfo( 'name' );
        $tokens = [
            '{name}'  => $lead->name ?: __( 'there', 'realwise' ),
            '{agent}' => $agent,
            '{site}'  => get_bloginfo( 'name' ),
        ];
        $subject = strtr( $step['subject'] ?? '', $tokens );
        $body    = strtr( $step['body'] ?? '', $tokens );

        $headers = [];
        if ( $lead->agent_id ) {
            $agent_email = PWC_Leads::agent_email( (int) $lead->agent_id );
            if ( $agent_email ) $headers[] = 'Reply-To: ' . $agent_email;
        }
        wp_mail( $lead->email, $subject, $body, $headers );

        // Optional SMS — wire a gateway via this filter (Twilio, etc.)
        if ( $lead->phone && get_option( 'pwc_sms_enabled', 0 ) ) {
            do_action( 'pwc_send_sms', $lead->phone, $body, $lead );
        }
    }
}
