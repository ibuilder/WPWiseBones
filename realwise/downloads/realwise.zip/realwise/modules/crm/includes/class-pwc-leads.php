<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWC_Leads — high-level lead operations + scoring.
 */
class PWC_Leads {

    public static function stage_label( string $stage ): string {
        return [
            'new'        => __( 'New',        'realwise' ),
            'contacted'  => __( 'Contacted',  'realwise' ),
            'nurturing'  => __( 'Nurturing',  'realwise' ),
            'qualified'  => __( 'Qualified',  'realwise' ),
            'showing'    => __( 'Showing',    'realwise' ),
            'offer'      => __( 'Offer',      'realwise' ),
            'closed'     => __( 'Closed Won', 'realwise' ),
            'lost'       => __( 'Lost',       'realwise' ),
        ][ $stage ] ?? ucfirst( $stage );
    }

    public static function stage_color( string $stage ): string {
        return [
            'new' => '#2563eb', 'contacted' => '#7c3aed', 'nurturing' => '#0891b2',
            'qualified' => '#ca8a04', 'showing' => '#ea580c', 'offer' => '#16a34a',
            'closed' => '#15803d', 'lost' => '#6b7280',
        ][ $stage ] ?? '#6b7280';
    }

    public static function source_label( string $source ): string {
        return [
            'website'        => __( 'Website',          'realwise' ),
            'contact_agent'  => __( 'Listing Inquiry',  'realwise' ),
            'saved_search'   => __( 'Saved Search',     'realwise' ),
            'saved_property' => __( 'Saved Property',   'realwise' ),
            'tour_request'   => __( 'Tour Request',     'realwise' ),
            'lead_form'      => __( 'Lead Form',        'realwise' ),
            'manual'         => __( 'Manual Entry',     'realwise' ),
        ][ $source ] ?? ucfirst( str_replace( '_', ' ', $source ) );
    }

    /**
     * Create a lead and run the standard post-create pipeline:
     * score → assign → first-touch activity → drip enrollment.
     */
    public static function intake( array $data ): int {
        $data['score'] = self::initial_score( $data );
        $lead_id = PWC_DB::create_lead( $data );

        // Only run assignment/notify for genuinely new leads (no agent yet)
        $lead = PWC_DB::get_lead( $lead_id );
        if ( $lead && ! $lead->agent_id ) {
            $agent_id = PWC_Assignment::assign( $lead_id );
            if ( $agent_id ) {
                self::notify_agent( $lead_id, $agent_id );
            }
        }
        PWC_DB::log_activity( $lead_id, 'created', sprintf(
            /* translators: %s: source label */
            __( 'Lead created from %s', 'realwise' ),
            self::source_label( $data['source'] ?? 'website' )
        ), null, 0 );

        return $lead_id;
    }

    private static function initial_score( array $data ): int {
        $score = 0;
        if ( ! empty( $data['email'] ) )      $score += 20;
        if ( ! empty( $data['phone'] ) )      $score += 25;
        if ( ! empty( $data['budget_max'] ) ) $score += 15;
        if ( ! empty( $data['listing_id'] ) ) $score += 20; // engaged with a specific property
        if ( ! empty( $data['message'] ) )    $score += 10;
        // Source weighting
        $score += [
            'contact_agent' => 20, 'tour_request' => 25, 'lead_form' => 10,
            'saved_property' => 8, 'saved_search' => 5,
        ][ $data['source'] ?? '' ] ?? 0;
        return min( 100, $score );
    }

    public static function change_stage( int $lead_id, string $stage ): void {
        if ( ! in_array( $stage, PWC_DB::STAGES, true ) ) return;
        $lead = PWC_DB::get_lead( $lead_id );
        if ( ! $lead ) return;
        PWC_DB::update_lead( $lead_id, [ 'stage' => $stage ] );
        PWC_DB::log_activity( $lead_id, 'stage_change', sprintf(
            /* translators: 1: old stage, 2: new stage */
            __( 'Stage changed: %1$s → %2$s', 'realwise' ),
            self::stage_label( $lead->stage ), self::stage_label( $stage )
        ) );
        // Stop drip once the lead is closed or lost
        if ( in_array( $stage, [ 'closed', 'lost' ], true ) ) {
            PWC_DB::update_lead( $lead_id, [ 'drip_active' => 0 ] );
        }
    }

    public static function notify_agent( int $lead_id, int $agent_id ): void {
        $lead  = PWC_DB::get_lead( $lead_id );
        if ( ! $lead ) return;
        $email = self::agent_email( $agent_id );
        if ( ! $email ) return;

        /* translators: %s and %d are dynamic values inserted at runtime. */
        $subject = sprintf( esc_html__( 'New lead assigned: %s', 'realwise' ), $lead->name ?: $lead->email ?: __( 'Unknown', 'realwise' ) );
        $admin   = admin_url( 'admin.php?page=pwc-leads&lead=' . $lead_id );
        $body    = sprintf(
            __( "You have a new lead.\n\nName: %1\$s\nEmail: %2\$s\nPhone: %3\$s\nSource: %4\$s\n\nMessage:\n%5\$s\n\nView in CRM: %6\$s", 'realwise' ),
            $lead->name ?: '—', $lead->email ?: '—', $lead->phone ?: '—',
            self::source_label( $lead->source ), $lead->message ?: '—', $admin
        );
        wp_mail( $email, $subject, $body );
    }

    /**
     * Resolve an agent's email. Agents live in RealWise Listings' agents table;
     * fall back to a WP user if the agent_id maps to one.
     */
    public static function agent_email( int $agent_id ): ?string {
        global $wpdb;
        if ( class_exists( 'PWL_DB' ) ) {
            $email = $wpdb->get_var( $wpdb->prepare(
                'SELECT email FROM ' . PWL_DB::agents_table() . ' WHERE id = %d', $agent_id
            ) );
            if ( $email ) return $email;
        }
        $user = get_userdata( $agent_id );
        return $user ? $user->user_email : null;
    }

    public static function agent_name( int $agent_id ): string {
        global $wpdb;
        if ( class_exists( 'PWL_DB' ) ) {
            $name = $wpdb->get_var( $wpdb->prepare(
                'SELECT name FROM ' . PWL_DB::agents_table() . ' WHERE id = %d', $agent_id
            ) );
            if ( $name ) return $name;
        }
        $user = get_userdata( $agent_id );
        return $user ? $user->display_name : __( 'Unassigned', 'realwise' );
    }
}
