<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWC_Shortcodes
 *   [pwc_lead_form]  — standalone lead capture form (any page).
 */
class PWC_Shortcodes {

    public static function init(): void {
        add_shortcode( 'pwc_lead_form', [ __CLASS__, 'render_lead_form' ] );
    }

    public static function render_lead_form( array $atts ): string {
        $atts = shortcode_atts( [
            'title'       => __( 'Get in touch', 'realwise' ),
            'button'      => __( 'Send', 'realwise' ),
            'listing_id'  => 0,
            'show_budget' => 'true',
            'show_phone'  => 'true',
        ], $atts );
        ob_start();
        include PWC_DIR . 'templates/lead-form.php';
        return ob_get_clean();
    }
}
