<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWC_Assignment — agent assignment strategies.
 *
 * Modes (option pwc_assign_mode):
 *   round_robin — rotate evenly through the agent pool
 *   listing     — assign to the listing's own agent, fall back to round-robin
 *   least_busy  — assign to the agent with the fewest open leads
 *   manual      — no auto-assignment
 */
class PWC_Assignment {

    public static function assign( int $lead_id ): int {
        $mode = get_option( 'pwc_assign_mode', 'round_robin' );
        $lead = PWC_DB::get_lead( $lead_id );
        if ( ! $lead || $mode === 'manual' ) return 0;

        $agent_id = 0;
        switch ( $mode ) {
            case 'listing':    $agent_id = self::by_listing( $lead ) ?: self::round_robin(); break;
            case 'least_busy': $agent_id = self::least_busy(); break;
            case 'round_robin':
            default:           $agent_id = self::round_robin(); break;
        }

        if ( $agent_id ) {
            PWC_DB::update_lead( $lead_id, [ 'agent_id' => $agent_id ] );
            PWC_DB::log_activity( $lead_id, 'assigned', sprintf(
                /* translators: %s: agent name */
                __( 'Assigned to %s', 'realwise' ),
                PWC_Leads::agent_name( $agent_id )
            ), null, 0 );
        }
        return $agent_id;
    }

    public static function reassign( int $lead_id, int $agent_id ): void {
        PWC_DB::update_lead( $lead_id, [ 'agent_id' => $agent_id ] );
        PWC_DB::log_activity( $lead_id, 'assigned', sprintf(
            /* translators: %s and %d are dynamic values inserted at runtime. */
            __( 'Reassigned to %s', 'realwise' ), PWC_Leads::agent_name( $agent_id )
        ) );
    }

    private static function by_listing( object $lead ): int {
        if ( ! $lead->listing_id || ! class_exists( 'PWL_DB' ) ) return 0;
        $listing = PWL_DB::get_listing( (int) $lead->listing_id );
        return $listing && $listing->agent_id ? (int) $listing->agent_id : 0;
    }

    /**
     * Round-robin over the configured agent pool, persisting a pointer.
     */
    private static function round_robin(): int {
        $pool = self::agent_pool();
        if ( empty( $pool ) ) return 0;
        $ptr  = (int) get_option( 'pwc_rr_pointer', -1 );
        $ptr  = ( $ptr + 1 ) % count( $pool );
        update_option( 'pwc_rr_pointer', $ptr, false );
        return (int) $pool[ $ptr ];
    }

    private static function least_busy(): int {
        $pool = self::agent_pool();
        if ( empty( $pool ) ) return 0;
        global $wpdb;
        $counts = [];
        foreach ( $pool as $aid ) {
            $counts[ $aid ] = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . PWC_DB::leads_table() . " WHERE agent_id = %d AND stage NOT IN ('closed','lost')",
                $aid
            ) );
        }
        asort( $counts );
        return (int) array_key_first( $counts );
    }

    /**
     * The agent pool is the set of agent IDs eligible for assignment.
     * Defaults to all RealWise Listings agents; can be overridden by the
     * pwc_agent_pool option (CSV of agent IDs).
     */
    public static function agent_pool(): array {
        $custom = get_option( 'pwc_agent_pool', '' );
        if ( $custom ) {
            return array_filter( array_map( 'intval', explode( ',', $custom ) ) );
        }
        if ( class_exists( 'PWL_DB' ) ) {
            global $wpdb;
            $ids = $wpdb->get_col( 'SELECT id FROM ' . PWL_DB::agents_table() . ' ORDER BY id ASC' );
            return array_map( 'intval', $ids );
        }
        return [];
    }
}
