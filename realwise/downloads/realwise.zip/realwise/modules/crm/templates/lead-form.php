<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<form class="pwc-lead-form" id="pwc-lead-form" data-listing="<?php echo (int) $atts['listing_id']; ?>">
    <h3 class="pwc-lead-form__title"><?php echo esc_html( $atts['title'] ); ?></h3>

    <div class="pwc-field">
        <label><?php esc_html_e( 'Name', 'realwise' ); ?></label>
        <input type="text" name="name" class="pwc-input" autocomplete="name">
    </div>
    <div class="pwc-field">
        <label><?php esc_html_e( 'Email', 'realwise' ); ?></label>
        <input type="email" name="email" class="pwc-input" autocomplete="email">
    </div>
    <?php if ( $atts['show_phone'] === 'true' ) : ?>
    <div class="pwc-field">
        <label><?php esc_html_e( 'Phone', 'realwise' ); ?></label>
        <input type="tel" name="phone" class="pwc-input" autocomplete="tel">
    </div>
    <?php endif; ?>
    <?php if ( $atts['show_budget'] === 'true' ) : ?>
    <div class="pwc-field-row">
        <div class="pwc-field">
            <label><?php esc_html_e( 'Budget Min', 'realwise' ); ?></label>
            <input type="number" name="budget_min" class="pwc-input" step="10000" min="0">
        </div>
        <div class="pwc-field">
            <label><?php esc_html_e( 'Budget Max', 'realwise' ); ?></label>
            <input type="number" name="budget_max" class="pwc-input" step="10000" min="0">
        </div>
    </div>
    <?php endif; ?>
    <div class="pwc-field">
        <label><?php esc_html_e( 'Message', 'realwise' ); ?></label>
        <textarea name="message" class="pwc-input" rows="3"></textarea>
    </div>

    <!-- Honeypot (hidden from humans) -->
    <div style="position:absolute;left:-9999px" aria-hidden="true">
        <label>Leave this empty<input type="text" name="pwc_hp" tabindex="-1" autocomplete="off"></label>
    </div>

    <?php
    $pwc_host = isset( $_SERVER['HTTP_HOST'] )   ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) )   : '';
    $pwc_uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
    ?>
    <input type="hidden" name="page_url" value="<?php echo esc_url( ( is_ssl() ? 'https://' : 'http://' ) . $pwc_host . $pwc_uri ); ?>">
    <button type="submit" class="pwc-btn pwc-btn--primary"><?php echo esc_html( $atts['button'] ); ?></button>
    <div class="pwc-lead-form__msg" role="status"></div>
</form>
