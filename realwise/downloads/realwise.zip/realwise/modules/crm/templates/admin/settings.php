<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwc-admin">
    <h1><?php esc_html_e( 'CRM Settings', 'realwise' ); ?></h1>

    <div class="notice notice-info inline"><p>
        <strong><?php esc_html_e( 'Lead capture is automatic.', 'realwise' ); ?></strong>
        <?php esc_html_e( 'When RealWise Listings is active, every contact-agent inquiry, saved property, and saved search becomes a CRM lead — scored, assigned, and enrolled in the drip sequence below. Use', 'realwise' ); ?>
        <code>[pwc_lead_form]</code> <?php esc_html_e( 'to add a standalone capture form to any page.', 'realwise' ); ?>
    </p></div>

    <form method="post" action="options.php">
        <?php settings_fields( 'pwc_settings_group' ); ?>
        <h2><?php esc_html_e( 'Assignment', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Assignment mode', 'realwise' ); ?></th><td>
                <?php $rw_mode = get_option( 'pwc_assign_mode', 'round_robin' ); ?>
                <select name="pwc_assign_mode">
                    <option value="round_robin" <?php selected( $rw_mode, 'round_robin' ); ?>><?php esc_html_e( 'Round-robin (rotate evenly)', 'realwise' ); ?></option>
                    <option value="listing"     <?php selected( $rw_mode, 'listing' ); ?>><?php esc_html_e( "Listing's own agent (fallback round-robin)", 'realwise' ); ?></option>
                    <option value="least_busy"  <?php selected( $rw_mode, 'least_busy' ); ?>><?php esc_html_e( 'Least busy agent', 'realwise' ); ?></option>
                    <option value="manual"      <?php selected( $rw_mode, 'manual' ); ?>><?php esc_html_e( 'Manual only', 'realwise' ); ?></option>
                </select>
            </td></tr>
            <tr><th><?php esc_html_e( 'Agent pool', 'realwise' ); ?></th><td>
                <input type="text" name="pwc_agent_pool" value="<?php echo esc_attr( get_option( 'pwc_agent_pool', '' ) ); ?>" class="regular-text" placeholder="<?php esc_attr_e( 'e.g. 3,5,8 — blank = all agents', 'realwise' ); ?>">
                <p class="description"><?php esc_html_e( 'Comma-separated agent IDs eligible for auto-assignment. Leave blank to use all RealWise Listings agents.', 'realwise' ); ?>
                <?php if ( $agents ) : ?><br><?php esc_html_e( 'Available:', 'realwise' ); ?>
                    <?php foreach ( $agents as $aid => $aname ) echo '<code>' . (int) $aid . '</code>=' . esc_html( $aname ) . ' '; ?>
                <?php endif; ?></p>
            </td></tr>
        </table>

        <h2><?php esc_html_e( 'Drip Sequence', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Email drip', 'realwise' ); ?></th><td>
                <label><input type="checkbox" name="pwc_drip_enabled" value="1" <?php checked( get_option( 'pwc_drip_enabled', 1 ), 1 ); ?>> <?php esc_html_e( 'Enable automated follow-up emails', 'realwise' ); ?></label>
            </td></tr>
            <tr><th><?php esc_html_e( 'SMS drip', 'realwise' ); ?></th><td>
                <label><input type="checkbox" name="pwc_sms_enabled" value="1" <?php checked( get_option( 'pwc_sms_enabled', 0 ), 1 ); ?>> <?php esc_html_e( 'Also send SMS (requires a gateway hooked to', 'realwise' ); ?> <code>pwc_send_sms</code>)</label>
            </td></tr>
        </table>
        <?php submit_button(); ?>
    </form>

    <h2><?php esc_html_e( 'Current Sequence', 'realwise' ); ?></h2>
    <table class="widefat striped" style="max-width:780px">
        <thead><tr><th><?php esc_html_e( 'Step', 'realwise' ); ?></th><th><?php esc_html_e( 'Delay', 'realwise' ); ?></th><th><?php esc_html_e( 'Subject', 'realwise' ); ?></th></tr></thead>
        <tbody>
        <?php foreach ( $drip as $i => $step ) : ?>
        <tr>
            <td>#<?php echo (int) $i + 1; ?></td>
            <td><?php /* translators: %d / %s are runtime values. */ printf( esc_html( _n( '%d day', '%d days', (int) $step['delay_days'], 'realwise' ) ), (int) $step['delay_days'] ); ?></td>
            <td><?php echo esc_html( $step['subject'] ); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <p class="description"><?php esc_html_e( 'Tokens available in templates:', 'realwise' ); ?> <code>{name}</code> <code>{agent}</code> <code>{site}</code>. <?php esc_html_e( 'Override the full sequence via the', 'realwise' ); ?> <code>pwc_drip_sequence</code> <?php esc_html_e( 'option (array of steps).', 'realwise' ); ?></p>
</div>
