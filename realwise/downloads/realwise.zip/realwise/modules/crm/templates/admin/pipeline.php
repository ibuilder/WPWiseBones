<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwc-admin">
    <h1><?php esc_html_e( 'Lead Pipeline', 'realwise' ); ?>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-leads&lead=new' ) ); ?>" class="page-title-action"><?php esc_html_e( '+ Add Lead', 'realwise' ); ?></a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-leads' ) ); ?>" class="page-title-action"><?php esc_html_e( 'List View', 'realwise' ); ?></a>
    </h1>

    <div class="pwc-help notice notice-info inline"><p>
        <strong><?php esc_html_e( 'Drag leads between columns', 'realwise' ); ?></strong> <?php esc_html_e( 'to move them through your funnel. Each move is logged and stops the drip sequence when a lead is won or lost. Click a card to open the full lead record.', 'realwise' ); ?>
    </p></div>

    <div class="pwc-board">
        <?php foreach ( $by_stage as $stage => $leads ) : ?>
        <div class="pwc-col" data-stage="<?php echo esc_attr( $stage ); ?>">
            <div class="pwc-col__head" style="border-top-color:<?php echo esc_attr( PWC_Leads::stage_color( $stage ) ); ?>">
                <span class="pwc-col__title"><?php echo esc_html( PWC_Leads::stage_label( $stage ) ); ?></span>
                <span class="pwc-col__count"><?php echo (int) $counts[ $stage ]; ?></span>
            </div>
            <div class="pwc-col__body" data-stage="<?php echo esc_attr( $stage ); ?>">
                <?php foreach ( $leads as $lead ) : ?>
                <div class="pwc-card" data-id="<?php echo (int) $lead->id; ?>">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-leads&lead=' . $lead->id ) ); ?>" class="pwc-card__name">
                        <?php echo esc_html( $lead->name ?: $lead->email ?: __( 'Unknown', 'realwise' ) ); ?>
                    </a>
                    <div class="pwc-card__meta">
                        <span class="pwc-card__source"><?php echo esc_html( PWC_Leads::source_label( $lead->source ) ); ?></span>
                        <span class="pwc-card__score" title="<?php esc_attr_e( 'Lead score', 'realwise' ); ?>"><?php echo (int) $lead->score; ?></span>
                    </div>
                    <?php if ( $lead->agent_id ) : ?>
                    <div class="pwc-card__agent"><?php echo esc_html( PWC_Leads::agent_name( (int) $lead->agent_id ) ); ?></div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <div class="pwc-board-foot">
        <span class="pwc-badge pwc-badge--won"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'Closed Won: %d', 'realwise' ), (int) $counts['closed'] ); ?></span>
        <span class="pwc-badge pwc-badge--lost"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'Lost: %d', 'realwise' ), (int) $counts['lost'] ); ?></span>
    </div>
</div>
