<?php if ( ! defined( 'ABSPATH' ) ) exit;
$is_new = ( $id === 0 ) || ( isset( $_GET['lead'] ) && $_GET['lead'] === 'new' );
?>
<div class="wrap pwc-admin pwc-lead-detail" data-lead="<?php echo (int) $lead->id; ?>">
    <h1>
        <?php echo $is_new ? esc_html__( 'Add Lead', 'realwise' ) : esc_html( $lead->name ?: $lead->email ?: __( 'Lead', 'realwise' ) ); ?>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-pipeline' ) ); ?>" class="page-title-action"><?php esc_html_e( '← Pipeline', 'realwise' ); ?></a>
    </h1>

    <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'saved' ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Lead saved.', 'realwise' ); ?></p></div>
    <?php endif; ?>

    <div class="pwc-detail-grid">
        <!-- Left: editable record -->
        <div class="pwc-detail-main">
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pwc-card-box">
                <input type="hidden" name="action" value="pwc_save_lead">
                <input type="hidden" name="lead_id" value="<?php echo (int) $lead->id; ?>">
                <?php wp_nonce_field( 'pwc_save_lead' ); ?>
                <h2 class="pwc-box-title"><?php esc_html_e( 'Contact', 'realwise' ); ?></h2>
                <table class="form-table">
                    <tr><th><?php esc_html_e( 'Name', 'realwise' ); ?></th><td><input type="text" name="name" value="<?php echo esc_attr( $lead->name ?? '' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Email', 'realwise' ); ?></th><td><input type="email" name="email" value="<?php echo esc_attr( $lead->email ?? '' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Phone', 'realwise' ); ?></th><td><input type="text" name="phone" value="<?php echo esc_attr( $lead->phone ?? '' ); ?>" class="regular-text"></td></tr>
                    <tr><th><?php esc_html_e( 'Stage', 'realwise' ); ?></th><td>
                        <select name="stage">
                            <?php foreach ( PWC_DB::STAGES as $st ) : ?>
                            <option value="<?php echo esc_attr( $st ); ?>" <?php selected( $lead->stage ?? 'new', $st ); ?>><?php echo esc_html( PWC_Leads::stage_label( $st ) ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td></tr>
                    <tr><th><?php esc_html_e( 'Agent', 'realwise' ); ?></th><td>
                        <select name="agent_id">
                            <option value="0"><?php esc_html_e( '— Unassigned —', 'realwise' ); ?></option>
                            <?php foreach ( $agents as $aid => $aname ) : ?>
                            <option value="<?php echo (int) $aid; ?>" <?php selected( $lead->agent_id ?? 0, $aid ); ?>><?php echo esc_html( $aname ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </td></tr>
                    <tr><th><?php esc_html_e( 'Budget', 'realwise' ); ?></th><td>
                        <input type="number" name="budget_min" value="<?php echo esc_attr( $lead->budget_min ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Min', 'realwise' ); ?>" style="width:130px" step="10000">
                        <input type="number" name="budget_max" value="<?php echo esc_attr( $lead->budget_max ?? '' ); ?>" placeholder="<?php esc_attr_e( 'Max', 'realwise' ); ?>" style="width:130px" step="10000">
                    </td></tr>
                    <tr><th><?php esc_html_e( 'Notes', 'realwise' ); ?></th><td><textarea name="notes" rows="3" class="large-text"><?php echo esc_textarea( $lead->notes ?? '' ); ?></textarea></td></tr>
                </table>
                <p>
                    <button class="button button-primary"><?php esc_html_e( 'Save Lead', 'realwise' ); ?></button>
                    <?php if ( ! $is_new && current_user_can( 'manage_options' ) ) : ?>
                    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=pwc_delete_lead&lead=' . $lead->id ), 'pwc_delete_lead' ) ); ?>"
                       class="button" style="color:#b32d2e" onclick="return confirm('<?php esc_attr_e( 'Delete this lead?', 'realwise' ); ?>')"><?php esc_html_e( 'Delete', 'realwise' ); ?></a>
                    <?php endif; ?>
                </p>
            </form>

            <?php if ( ! $is_new && $lead->message ) : ?>
            <div class="pwc-card-box">
                <h2 class="pwc-box-title"><?php esc_html_e( 'Original Message', 'realwise' ); ?></h2>
                <blockquote class="pwc-message"><?php echo nl2br( esc_html( $lead->message ) ); ?></blockquote>
            </div>
            <?php endif; ?>

            <?php if ( ! $is_new ) : ?>
            <!-- Activity timeline -->
            <div class="pwc-card-box">
                <h2 class="pwc-box-title"><?php esc_html_e( 'Activity', 'realwise' ); ?></h2>
                <div class="pwc-note-add">
                    <textarea id="pwc-note-input" rows="2" placeholder="<?php esc_attr_e( 'Log a note or call…', 'realwise' ); ?>"></textarea>
                    <button class="button button-primary" id="pwc-note-btn"><?php esc_html_e( 'Add Note', 'realwise' ); ?></button>
                </div>
                <ul class="pwc-timeline" id="pwc-timeline">
                    <?php foreach ( $activity as $a ) : ?>
                    <li class="pwc-timeline__item pwc-timeline__item--<?php echo esc_attr( $a->type ); ?>">
                        <span class="pwc-timeline__when"><?php echo esc_html( date_i18n( 'M j, g:i a', strtotime( $a->created_at ) ) ); ?></span>
                        <span class="pwc-timeline__text"><?php echo esc_html( $a->content ); ?></span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <?php endif; ?>
        </div>

        <!-- Right: side panel -->
        <?php if ( ! $is_new ) : ?>
        <div class="pwc-detail-side">
            <div class="pwc-card-box">
                <h2 class="pwc-box-title"><?php esc_html_e( 'Summary', 'realwise' ); ?></h2>
                <ul class="pwc-summary">
                    <li><strong><?php esc_html_e( 'Score', 'realwise' ); ?>:</strong> <?php echo (int) $lead->score; ?>/100</li>
                    <li><strong><?php esc_html_e( 'Source', 'realwise' ); ?>:</strong> <?php echo esc_html( PWC_Leads::source_label( $lead->source ) ); ?></li>
                    <li><strong><?php esc_html_e( 'Created', 'realwise' ); ?>:</strong> <?php echo esc_html( date_i18n( 'M j, Y', strtotime( $lead->created_at ) ) ); ?></li>
                    <li>
                        <label><input type="checkbox" id="pwc-drip-toggle" <?php checked( $lead->drip_active, 1 ); ?>> <?php esc_html_e( 'Drip sequence active', 'realwise' ); ?></label>
                        <span class="pwc-drip-step">(<?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'step %d', 'realwise' ), (int) $lead->drip_step ); ?>)</span>
                    </li>
                </ul>
            </div>

            <?php if ( $listing ) : ?>
            <div class="pwc-card-box">
                <h2 class="pwc-box-title"><?php esc_html_e( 'Interested In', 'realwise' ); ?></h2>
                <p><strong><?php echo esc_html( PWL_Listing::format_price( $listing->list_price ) ); ?></strong><br>
                   <?php echo esc_html( $listing->address . ', ' . $listing->city ); ?></p>
                <a href="<?php echo esc_url( PWL_Listing::listing_url( $listing->id ) ); ?>" target="_blank" class="button"><?php esc_html_e( 'View listing', 'realwise' ); ?></a>
                <?php if ( class_exists( 'PWD_Proforma' ) ) :
                    // Cross-link into the Developer proforma pre-loaded with this listing
                    $dev_page = (int) get_option( 'pwd_proforma_page_id' );
                    $url = $dev_page
                        ? add_query_arg( 'listing_id', $listing->id, get_permalink( $dev_page ) )
                        : admin_url( 'admin.php?page=pwd-dashboard' );
                ?>
                <a href="<?php echo esc_url( $url ); ?>" target="_blank" class="button">&#128200; <?php esc_html_e( 'Underwrite this property', 'realwise' ); ?></a>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Tasks -->
            <div class="pwc-card-box">
                <h2 class="pwc-box-title"><?php esc_html_e( 'Follow-up Tasks', 'realwise' ); ?></h2>
                <ul class="pwc-tasks" id="pwc-tasks">
                    <?php foreach ( $tasks as $t ) : ?>
                    <li class="<?php echo $t->completed ? 'done' : ''; ?>">
                        <label><input type="checkbox" class="pwc-task-check" data-id="<?php echo (int) $t->id; ?>" <?php checked( $t->completed, 1 ); ?>>
                        <?php echo esc_html( $t->title ); ?></label>
                        <?php if ( $t->due_date ) : ?><span class="pwc-task-due"><?php echo esc_html( date_i18n( 'M j', strtotime( $t->due_date ) ) ); ?></span><?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
                <div class="pwc-task-add">
                    <input type="text" id="pwc-task-title" placeholder="<?php esc_attr_e( 'New task…', 'realwise' ); ?>">
                    <input type="date" id="pwc-task-due">
                    <button class="button" id="pwc-task-btn"><?php esc_html_e( 'Add', 'realwise' ); ?></button>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>
