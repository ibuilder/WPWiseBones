<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwc-admin">
    <h1><?php esc_html_e( 'All Leads', 'realwise' ); ?>
        <span class="pwc-count"><?php echo number_format( $total ); ?></span>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-leads&lead=new' ) ); ?>" class="page-title-action"><?php esc_html_e( '+ Add Lead', 'realwise' ); ?></a>
        <a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-pipeline' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Pipeline View', 'realwise' ); ?></a>
        <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( array_filter( [ 'action' => 'pwc_export_csv', 'stage' => $args['stage'], 's' => $args['search'] ] ), admin_url( 'admin-post.php' ) ), 'pwc_export_csv' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Export CSV', 'realwise' ); ?></a>
    </h1>

    <?php if ( isset( $_GET['msg'] ) ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php echo esc_html( $_GET['msg'] === 'deleted' ? __( 'Lead deleted.', 'realwise' ) : __( 'Saved.', 'realwise' ) ); ?></p></div>
    <?php endif; ?>

    <form method="get" class="pwc-filters">
        <input type="hidden" name="page" value="pwc-leads">
        <input type="search" name="s" value="<?php echo esc_attr( $args['search'] ); ?>" placeholder="<?php esc_attr_e( 'Search name, email, phone', 'realwise' ); ?>">
        <select name="stage">
            <option value=""><?php esc_html_e( 'All stages', 'realwise' ); ?></option>
            <?php foreach ( PWC_DB::STAGES as $st ) : ?>
            <option value="<?php echo esc_attr( $st ); ?>" <?php selected( $args['stage'], $st ); ?>><?php echo esc_html( PWC_Leads::stage_label( $st ) ); ?></option>
            <?php endforeach; ?>
        </select>
        <button class="button"><?php esc_html_e( 'Filter', 'realwise' ); ?></button>
    </form>

    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'Name', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Contact', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Stage', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Source', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Score', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Agent', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Updated', 'realwise' ); ?></th>
        </tr></thead>
        <tbody>
        <?php if ( $leads ) : foreach ( $leads as $lead ) : ?>
        <tr>
            <td><a href="<?php echo esc_url( admin_url( 'admin.php?page=pwc-leads&lead=' . $lead->id ) ); ?>"><strong><?php echo esc_html( $lead->name ?: '—' ); ?></strong></a></td>
            <td>
                <?php if ( $lead->email ) : ?><div><a href="mailto:<?php echo esc_attr( $lead->email ); ?>"><?php echo esc_html( $lead->email ); ?></a></div><?php endif; ?>
                <?php if ( $lead->phone ) : ?><div><a href="tel:<?php echo esc_attr( $lead->phone ); ?>"><?php echo esc_html( $lead->phone ); ?></a></div><?php endif; ?>
            </td>
            <td><span class="pwc-pill" style="background:<?php echo esc_attr( PWC_Leads::stage_color( $lead->stage ) ); ?>"><?php echo esc_html( PWC_Leads::stage_label( $lead->stage ) ); ?></span></td>
            <td><?php echo esc_html( PWC_Leads::source_label( $lead->source ) ); ?></td>
            <td><span class="pwc-score-chip"><?php echo (int) $lead->score; ?></span></td>
            <td><?php echo esc_html( $lead->agent_id ? PWC_Leads::agent_name( (int) $lead->agent_id ) : '—' ); ?></td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $lead->updated_at ) ) ); ?></td>
        </tr>
        <?php endforeach; else : ?>
        <tr><td colspan="7"><?php esc_html_e( 'No leads yet.', 'realwise' ); ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>

    <?php if ( $pages > 1 ) : ?>
    <div class="tablenav bottom"><div class="tablenav-pages">
        <?php for ( $i = 1; $i <= $pages; $i++ ) : ?>
        <a class="button <?php echo $i === $page ? 'button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'paged', $i ) ); ?>"><?php echo (int) $i; ?></a>
        <?php endfor; ?>
    </div></div>
    <?php endif; ?>
</div>
