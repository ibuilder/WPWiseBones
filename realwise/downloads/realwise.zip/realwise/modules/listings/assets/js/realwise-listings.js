/* RealWise Listings — Front-end JS */
/* global PWL, L, Chart */
(function ($) {
  'use strict';

  var map, markersLayer;

  // ── Map init ──────────────────────────────────────────────────────────────
  function initSearchMap() {
    var el = document.getElementById('pwl-map');
    if (!el || !window.L) return;
    map = L.map('pwl-map').setView([39.5, -98.35], 4);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© <a href="https://openstreetmap.org/copyright">OpenStreetMap</a>'
    }).addTo(map);
    markersLayer = L.layerGroup().addTo(map);
    loadMapData();
  }

  function loadMapData() {
    if (!map) return;
    $.post(PWL.ajax_url, { action: 'pwl_map_data', nonce: PWL.nonce }, function (res) {
      if (!res || !res.features) return;
      markersLayer.clearLayers();
      res.features.forEach(function (f) {
        var p = f.properties;
        var m = L.circleMarker([f.geometry.coordinates[1], f.geometry.coordinates[0]], {
          radius: 8, fillColor: '#1a6fd4', color: '#fff', weight: 2, fillOpacity: 0.85
        }).addTo(markersLayer);
        m.bindPopup(
          '<a href="' + p.url + '"><strong>' + formatPrice(p.price) + '</strong></a>' +
          '<br>' + (p.addr || '') +
          (p.beds ? '<br>' + p.beds + ' bd / ' + p.baths + ' ba · ' + formatNum(p.sqft) + ' sqft' : '')
        );
      });
      if (res.features.length) {
        var coords = res.features.map(function (f) {
          return [f.geometry.coordinates[1], f.geometry.coordinates[0]];
        });
        map.fitBounds(coords, { maxZoom: 13, padding: [20, 20] });
      }
    });
  }

  function initDetailMap() {
    var el = document.getElementById('pwl-detail-map');
    if (!el || !window.L) return;
    var lat = parseFloat(el.dataset.lat);
    var lon = parseFloat(el.dataset.lon);
    var addr = el.dataset.addr || '';
    var m = L.map('pwl-detail-map').setView([lat, lon], 15);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap'
    }).addTo(m);
    L.marker([lat, lon]).addTo(m).bindPopup(addr).openPopup();
  }

  // ── AJAX search ────────────────────────────────────────────────────────────
  function initSearch() {
    var $form = $('#pwl-search-form');
    if (!$form.length) return;
    $form.on('submit', function (e) {
      e.preventDefault();
      var args = {};
      $form.serializeArray().forEach(function (f) { args[f.name] = f.value; });
      $('#pwl-results').addClass('pwl-loading');
      $.post(PWL.ajax_url, {
        action: 'pwl_search',
        nonce: PWL.nonce,
        args: args
      }, function (res) {
        $('#pwl-results').removeClass('pwl-loading');
        if (res.success) {
          $('#pwl-results .pwl-grid').replaceWith($(res.data.html));
          $('.pwl-results-count').text(res.data.total + ' properties found');
          initSaveButtons();
        }
      });
    });
  }

  // ── Mortgage calculator ────────────────────────────────────────────────────
  function initMortgage() {
    var $calc = $('#pwl-mortgage-calc');
    if (!$calc.length) return;

    var chart = null;

    function recalc() {
      var price    = parseFloat($('#pwl-mort-price').val()) || 0;
      var down_pct = parseFloat($('#pwl-mort-down').val()) || 20;
      var rate     = parseFloat($('#pwl-mort-rate').val()) || 0;
      var years    = parseInt($('#pwl-mort-years').val()) || 30;
      $('#pwl-mort-down-pct').text(down_pct);
      $.post(PWL.ajax_url, {
        action: 'pwl_mortgage_calc',
        nonce: PWL.nonce,
        price: price, down_pct: down_pct, rate: rate, years: years
      }, function (res) {
        if (!res.success) return;
        var s = res.data.summary;
        $('#pwl-mort-monthly').text(fmt(s.monthly_total));
        $('#pwl-mort-loan').text(fmt(s.loan_amount));
        $('#pwl-mort-down-amt').text(fmt(s.down_payment));
        $('#pwl-mort-int').text(fmt(s.total_interest));
        $('#pwl-mort-total').text(fmt(s.total_paid));
        drawAmortChart(res.data.sched);
      });
    }

    function fmt(v) { return (PWL.currency || '$') + Number(v).toLocaleString('en-US', {maximumFractionDigits: 0}); }

    function drawAmortChart(sched) {
      var ctx = document.getElementById('pwl-amort-chart');
      if (!ctx || !window.Chart) return;
      var labels = sched.filter(function (_, i) { return i % 12 === 0; }).map(function (r) { return 'Yr ' + Math.ceil(r.month / 12); });
      var balances = sched.filter(function (_, i) { return i % 12 === 0; }).map(function (r) { return r.balance; });
      var interests = sched.filter(function (_, i) { return i % 12 === 0; }).map(function (r) { return r.cumulative_interest; });
      if (chart) chart.destroy();
      chart = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            { label: 'Remaining Balance', data: balances, borderColor: '#1a6fd4', tension: .3, fill: false },
            { label: 'Cumulative Interest', data: interests, borderColor: '#dc2626', tension: .3, fill: false }
          ]
        },
        options: { responsive: true, plugins: { legend: { position: 'bottom' } },
          scales: { y: { ticks: { callback: function (v) { return '$' + (v/1000).toFixed(0) + 'k'; } } } } }
      });
    }

    $('#pwl-mort-price, #pwl-mort-rate, #pwl-mort-years').on('change', recalc);
    $('#pwl-mort-down').on('input', function () { $('#pwl-mort-down-pct').text(this.value); }).on('change', recalc);

    // Draw chart immediately with the server-rendered initial values
    recalc();
  }

  // ── Price history chart ────────────────────────────────────────────────────
  function initPriceChart() {
    var ctx = document.getElementById('pwl-price-chart');
    if (!ctx || !window.Chart) return;
    var labels = JSON.parse(ctx.dataset.labels || '[]');
    var values = JSON.parse(ctx.dataset.values || '[]');
    if (!labels.length) return;
    new Chart(ctx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [{ label: 'List Price', data: values, borderColor: '#1a6fd4', backgroundColor: 'rgba(26,111,212,.08)', fill: true, tension: .3 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } },
        scales: { y: { ticks: { callback: function (v) { return '$' + (v/1000).toFixed(0) + 'k'; } } } } }
    });
  }

  // ── Save / Unsave ─────────────────────────────────────────────────────────
  function initSaveButtons() {
    // Mark already-saved listings on page load
    var saved = PWL.saved_ids || [];
    if (saved.length) {
      saved.forEach(function (id) {
        $('.pwl-save-btn[data-id="' + id + '"]').addClass('saved').html('&#9829; Saved');
      });
    }

    $(document).on('click', '.pwl-save-btn', function () {
      var $btn = $(this);
      var id = $btn.data('id');
      if ($btn.hasClass('saved')) return; // already saved
      $.post(PWL.ajax_url, { action: 'pwl_save_listing', nonce: PWL.nonce, listing_id: id }, function (res) {
        if (res.success) $btn.addClass('saved').html('&#9829; Saved');
      });
    });
    $(document).on('click', '.pwl-unsave-btn', function () {
      var $btn = $(this);
      var id = $btn.data('id');
      $.post(PWL.ajax_url, { action: 'pwl_unsave_listing', nonce: PWL.nonce, listing_id: id }, function (res) {
        if (res.success) $btn.closest('tr').remove();
      });
    });
  }

  // ── Agent contact form ────────────────────────────────────────────────────
  function initContactForm() {
    $(document).on('submit', '.pwl-contact-form', function (e) {
      e.preventDefault();
      var $form  = $(this);
      var $msg   = $form.find('.pwl-contact-form__msg');
      var $btn   = $form.find('button[type=submit]');
      $btn.prop('disabled', true).text('Sending…');
      $.post(PWL.ajax_url, {
        action: 'pwl_contact_agent',
        nonce: PWL.nonce,
        listing_id: $form.data('listing'),
        message: $form.find('textarea[name=message]').val()
      }, function (res) {
        $btn.prop('disabled', false).text('Contact Agent');
        $msg.text(res.success ? 'Message sent!' : (res.data || 'Error sending.'));
        if (res.success) $form.find('textarea').val('');
      });
    });
  }

  // ── Saved searches ─────────────────────────────────────────────────────────
  function initSavedSearches() {
    var $modal = $('#pwl-save-search-modal');

    $('#pwl-save-search-btn').on('click', function () {
      $modal.prop('hidden', false);
    });
    $modal.on('click', '[data-close]', function () {
      $modal.prop('hidden', true);
    });

    $('#pwl-ss-confirm').on('click', function () {
      var $btn = $(this).prop('disabled', true);
      // Collect the current filter form values as criteria
      var criteria = {};
      $('#pwl-search-form').serializeArray().forEach(function (f) {
        if (f.value !== '' && f.name !== 'order_by' && f.name !== 'pwl_page') {
          // map form field 'type' -> 'asset_type'
          criteria[f.name === 'type' ? 'asset_type' : f.name] = f.value;
        }
      });
      $.post(PWL.ajax_url, {
        action: 'pwl_save_search',
        nonce: PWL.nonce,
        label: $('#pwl-ss-label').val(),
        frequency: $('#pwl-ss-frequency').val(),
        criteria: criteria
      }, function (res) {
        $btn.prop('disabled', false);
        var $msg = $('#pwl-ss-msg');
        if (res.success) {
          $msg.css('color', '#16a34a').text('Saved! You\'ll get alerts for "' + res.data.label + '".');
          setTimeout(function () { $modal.prop('hidden', true); $msg.text(''); }, 1800);
        } else {
          $msg.css('color', '#dc2626').text(res.data || 'Could not save search.');
        }
      });
    });

    // Delete from the saved-searches management page
    $(document).on('click', '.pwl-delete-search', function () {
      var $row = $(this).closest('tr');
      var id = $(this).data('id');
      if (!confirm('Delete this saved search?')) return;
      $.post(PWL.ajax_url, { action: 'pwl_delete_search', nonce: PWL.nonce, search_id: id }, function (res) {
        if (res.success) $row.remove();
      });
    });
  }

  // ── Utilities ────────────────────────────────────────────────────────────
  function formatPrice(n) {
    var sym = PWL.currency || '$';
    if (n >= 1e6) return sym + (n / 1e6).toFixed(2) + 'M';
    return sym + Number(n).toLocaleString();
  }
  function formatNum(n) { return n ? Number(n).toLocaleString() : ''; }

  // ── Boot ────────────────────────────────────────────────────────────────
  $(function () {
    initSearchMap();
    initDetailMap();
    initSearch();
    initMortgage();
    initPriceChart();
    initSaveButtons();
    initContactForm();
    initSavedSearches();
  });

}(jQuery));
