<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWL_Scores — Walk Score, CrimeGrade, GreatSchools with DB caching.
 */
class PWL_Scores {

    public static function get_walk_score( object $listing ): array {
        $cached = self::get_cached( $listing->id, 'walk' );
        if ( $cached ) return $cached;

        $api_key = get_option( 'pwl_walkscore_key', '' );
        if ( ! $api_key ) return self::empty_walk();

        $url = add_query_arg( [
            'format'   => 'json',
            'address'  => rawurlencode( $listing->address . ', ' . $listing->city . ', ' . $listing->state ),
            'lat'      => $listing->latitude,
            'lon'      => $listing->longitude,
            'transit'  => 1,
            'bike'     => 1,
            'wsapikey' => $api_key,
        ], 'https://api.walkscore.com/score' );

        $response = wp_remote_get( $url, [ 'timeout' => 10 ] );
        if ( is_wp_error( $response ) ) return self::empty_walk();
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $data ) ) return self::empty_walk();

        $scores = [
            'walk'         => (int)    ( $data['walkscore']             ?? 0 ),
            'walk_desc'    =>           $data['description']            ?? '',
            'transit'      => (int)    ( $data['transit']['score']      ?? 0 ),
            'transit_desc' =>           $data['transit']['description'] ?? '',
            'bike'         => (int)    ( $data['bike']['score']         ?? 0 ),
            'bike_desc'    =>           $data['bike']['description']    ?? '',
        ];

        self::cache_score( $listing->id, 'walk',    $scores['walk'],    null, wp_json_encode( $scores ) );
        self::cache_score( $listing->id, 'transit', $scores['transit'] );
        self::cache_score( $listing->id, 'bike',    $scores['bike'] );

        global $wpdb;
        $wpdb->update( PWL_DB::listings_table(), [
            'walk_score'    => $scores['walk'],
            'transit_score' => $scores['transit'],
            'bike_score'    => $scores['bike'],
        ], [ 'id' => $listing->id ] );

        return $scores;
    }

    public static function get_crime( object $listing ): array {
        $cached = self::get_cached( $listing->id, 'crime' );
        if ( $cached ) return $cached;

        $api_key = get_option( 'pwl_crime_api_key', '' );
        if ( ! $api_key ) return self::empty_crime();

        $url = add_query_arg( [
            'lat' => $listing->latitude,
            'lon' => $listing->longitude,
            'key' => $api_key,
        ], 'https://api.crimegrade.org/safeplaces/point/' );

        $response = wp_remote_get( $url, [ 'timeout' => 10 ] );
        if ( is_wp_error( $response ) ) return self::empty_crime();
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( empty( $data ) ) return self::empty_crime();

        $grade  = $data['overall_grade'] ?? null;
        $score  = self::grade_to_score( $grade );
        $result = [
            'grade'       => $grade,
            'score'       => $score,
            'description' => self::crime_grade_label( $grade ),
        ];
        self::cache_score( $listing->id, 'crime', $score, $grade, wp_json_encode( $result ) );

        global $wpdb;
        $wpdb->update( PWL_DB::listings_table(), [
            'crime_score' => $score,
            'crime_grade' => $grade,
        ], [ 'id' => $listing->id ] );

        return $result;
    }

    public static function get_schools( object $listing ): array {
        $cached = self::get_cached( $listing->id, 'schools' );
        if ( $cached ) return $cached;

        $api_key = get_option( 'pwl_greatschools_key', '' );
        if ( ! $api_key ) return [ 'schools' => [], 'summary_rating' => null ];

        $url = add_query_arg( [
            'key'   => $api_key,
            'zip'   => $listing->zip_code,
            'limit' => 5,
            'sort'  => 'rating',
        ], 'https://api.greatschools.org/schools/nearby' );

        $response = wp_remote_get( $url, [ 'timeout' => 10 ] );
        if ( is_wp_error( $response ) ) return [ 'schools' => [] ];
        $data    = json_decode( wp_remote_retrieve_body( $response ), true );
        $schools = [];
        foreach ( (array) ( $data['schools'] ?? [] ) as $s ) {
            $schools[] = [
                'name'       => sanitize_text_field( $s['name']       ?? '' ),
                'level'      => sanitize_text_field( $s['level']      ?? '' ),
                'rating'     => (int)   ( $s['gsRating']   ?? 0 ),
                'enrollment' => (int)   ( $s['enrollment'] ?? 0 ),
                'distance'   => round( (float) ( $s['distance'] ?? 0 ), 2 ),
            ];
        }
        $ratings = array_column( $schools, 'rating' );
        $avg     = $ratings ? round( array_sum( $ratings ) / count( $ratings ), 1 ) : null;
        $result  = [ 'schools' => $schools, 'summary_rating' => $avg ];
        self::cache_score( $listing->id, 'schools', $avg, null, wp_json_encode( $result ) );

        global $wpdb;
        $wpdb->update( PWL_DB::listings_table(), [ 'school_rating' => $avg ], [ 'id' => $listing->id ] );
        return $result;
    }

    private static function get_cached( int $listing_id, string $type ) {
        global $wpdb;
        $ttl = (int) get_option( 'pwl_score_cache_hours', 72 ) * HOUR_IN_SECONDS;
        $row = $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . PWL_DB::scores_table() . ' WHERE listing_id = %d AND score_type = %s',
            $listing_id, $type
        ) );
        if ( ! $row ) return false;
        if ( strtotime( $row->fetched_at ) < ( time() - $ttl ) ) return false;
        $raw = json_decode( $row->raw_response ?? '{}', true );
        return $raw ?: [ 'score_value' => $row->score_value, 'score_label' => $row->score_label ];
    }

    private static function cache_score( int $listing_id, string $type, $value, $label = null, $raw = null ): void {
        global $wpdb;
        $table  = PWL_DB::scores_table();
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM $table WHERE listing_id = %d AND score_type = %s", $listing_id, $type
        ) );
        $data = [
            'listing_id'   => $listing_id,
            'score_type'   => $type,
            'score_value'  => $value,
            'score_label'  => $label,
            'raw_response' => $raw,
            'fetched_at'   => current_time( 'mysql' ),
        ];
        $exists
            ? $wpdb->update( $table, $data, [ 'listing_id' => $listing_id, 'score_type' => $type ] )
            : $wpdb->insert( $table, $data );
    }

    private static function grade_to_score( ?string $grade ): int {
        $map = [ 'A+' => 97, 'A' => 93, 'A-' => 90, 'B+' => 87, 'B' => 83, 'B-' => 80,
                 'C+' => 77, 'C' => 73, 'C-' => 70, 'D+' => 67, 'D' => 63, 'D-' => 60, 'F' => 40 ];
        return $map[ strtoupper( $grade ?? '' ) ] ?? 0;
    }

    private static function crime_grade_label( ?string $grade ): string {
        if ( ! $grade ) return 'Data unavailable';
        $g = strtoupper( $grade );
        if ( str_starts_with( $g, 'A' ) ) return 'Very safe neighborhood';
        if ( str_starts_with( $g, 'B' ) ) return 'Safer than average';
        if ( str_starts_with( $g, 'C' ) ) return 'Average crime level';
        if ( str_starts_with( $g, 'D' ) ) return 'Above-average crime';
        return 'High crime area';
    }

    private static function empty_walk(): array {
        return [ 'walk' => null, 'transit' => null, 'bike' => null, 'walk_desc' => '', 'transit_desc' => '', 'bike_desc' => '' ];
    }
    private static function empty_crime(): array {
        return [ 'grade' => null, 'score' => null, 'description' => '' ];
    }
}
