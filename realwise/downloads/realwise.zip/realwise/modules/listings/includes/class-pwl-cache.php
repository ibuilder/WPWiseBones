<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWL_Cache — thin caching layer over the object cache / transients.
 *
 * Uses a namespace version number so the entire cache can be invalidated in
 * O(1) (bump the version) rather than enumerating and deleting every key —
 * important because transient keys for search permutations are unbounded.
 */
class PWL_Cache {

    const VERSION_KEY = 'pwl_cache_version';

    private static function version(): int {
        $v = (int) get_option( self::VERSION_KEY, 0 );
        if ( $v === 0 ) {
            $v = 1;
            update_option( self::VERSION_KEY, $v, false );
        }
        return $v;
    }

    private static function key( string $raw ): string {
        // Prefix with namespace version; keep under the 172-char transient limit.
        return 'pwlc' . self::version() . '_' . substr( $raw, 0, 150 );
    }

    public static function get( string $key ) {
        return get_transient( self::key( $key ) );
    }

    public static function set( string $key, $value, int $ttl = 300 ): void {
        set_transient( self::key( $key ), $value, $ttl );
    }

    public static function delete( string $key ): void {
        delete_transient( self::key( $key ) );
    }

    /**
     * Invalidate the entire RealWise cache namespace by bumping the version.
     * Old transients expire naturally and are never read again.
     */
    public static function flush(): void {
        update_option( self::VERSION_KEY, self::version() + 1, false );
    }
}
