<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWL_REST — public read REST API under /wp-json/realwise/v1/.
 *
 * Endpoints:
 *   GET /listings              Search/list (paginated, filterable)
 *   GET /listings/{id}         Single listing with scores
 *   GET /map                   GeoJSON FeatureCollection of active listings
 *   GET /listings/{id}/comps   Comparable sold listings + suggested ARV
 *
 * All GET responses are cached via transients. Cache is busted on any
 * listing upsert (see PWL_Cache::flush).
 */
class PWL_REST {

    const NS = 'realwise/v1';

    public static function init(): void {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
    }

    public static function register_routes(): void {
        register_rest_route( self::NS, '/listings', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_listings' ],
            'permission_callback' => '__return_true',
            'args'                => [
                'q'          => [ 'sanitize_callback' => 'sanitize_text_field' ],
                'type'       => [ 'sanitize_callback' => 'sanitize_text_field' ],
                'min_price'  => [ 'sanitize_callback' => 'floatval' ],
                'max_price'  => [ 'sanitize_callback' => 'floatval' ],
                'min_beds'   => [ 'sanitize_callback' => 'absint' ],
                'min_baths'  => [ 'sanitize_callback' => 'floatval' ],
                'city'       => [ 'sanitize_callback' => 'sanitize_text_field' ],
                'zip'        => [ 'sanitize_callback' => 'sanitize_text_field' ],
                'status'     => [ 'sanitize_callback' => 'sanitize_text_field' ],
                'page'       => [ 'sanitize_callback' => 'absint', 'default' => 1 ],
                'per_page'   => [ 'sanitize_callback' => 'absint', 'default' => 24 ],
            ],
        ] );

        register_rest_route( self::NS, '/listings/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_listing' ],
            'permission_callback' => '__return_true',
            'args'                => [ 'id' => [ 'sanitize_callback' => 'absint' ] ],
        ] );

        register_rest_route( self::NS, '/listings/(?P<id>\d+)/comps', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_comps' ],
            'permission_callback' => '__return_true',
            'args'                => [ 'id' => [ 'sanitize_callback' => 'absint' ] ],
        ] );

        register_rest_route( self::NS, '/map', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_map' ],
            'permission_callback' => '__return_true',
        ] );
    }

    // ── GET /listings ──────────────────────────────────────────────────────────
    public static function get_listings( WP_REST_Request $req ): WP_REST_Response {
        $args = [
            'q'          => $req['q']         ?? '',
            'asset_type' => $req['type']      ?? 'all',
            'min_price'  => $req['min_price'] ?? 0,
            'max_price'  => $req['max_price'] ?? 0,
            'min_beds'   => $req['min_beds']  ?? 0,
            'min_baths'  => $req['min_baths'] ?? 0,
            'city'       => $req['city']      ?? '',
            'zip'        => $req['zip']       ?? '',
            'status'     => $req['status']    ?? 'active',
            'page'       => max( 1, (int) ( $req['page'] ?? 1 ) ),
            'per_page'   => min( 100, max( 1, (int) ( $req['per_page'] ?? 24 ) ) ),
        ];

        $cache_key = 'pwl_rest_list_' . md5( wp_json_encode( $args ) );
        $cached    = PWL_Cache::get( $cache_key );
        if ( $cached !== false ) {
            return self::respond( $cached, true );
        }

        $result   = PWL_DB::search( $args );
        $payload  = [
            'total'    => (int) $result['total'],
            'page'     => $args['page'],
            'per_page' => $args['per_page'],
            'pages'    => (int) ceil( $result['total'] / $args['per_page'] ),
            'listings' => array_map( [ __CLASS__, 'shape_listing' ], $result['listings'] ),
        ];
        PWL_Cache::set( $cache_key, $payload, 5 * MINUTE_IN_SECONDS );
        return self::respond( $payload, false );
    }

    // ── GET /listings/{id} ──────────────────────────────────────────────────────
    public static function get_listing( WP_REST_Request $req ) {
        $id      = (int) $req['id'];
        $listing = PWL_DB::get_listing( $id );
        if ( ! $listing ) {
            return new WP_Error( 'not_found', 'Listing not found.', [ 'status' => 404 ] );
        }
        $data            = self::shape_listing( $listing, true );
        $data['scores']  = [
            'walk'    => PWL_Scores::get_walk_score( $listing ),
            'crime'   => PWL_Scores::get_crime( $listing ),
            'schools' => PWL_Scores::get_schools( $listing ),
        ];
        $data['price_history'] = PWL_DB::get_price_history( $id );
        return self::respond( $data, false );
    }

    // ── GET /listings/{id}/comps ────────────────────────────────────────────────
    public static function get_comps( WP_REST_Request $req ) {
        $id      = (int) $req['id'];
        $listing = PWL_DB::get_listing( $id );
        if ( ! $listing ) {
            return new WP_Error( 'not_found', 'Listing not found.', [ 'status' => 404 ] );
        }
        $comps = PWL_Comps::find( $listing );
        return self::respond( $comps, false );
    }

    // ── GET /map ────────────────────────────────────────────────────────────────
    public static function get_map( WP_REST_Request $req ): WP_REST_Response {
        $cached = PWL_Cache::get( 'pwl_rest_map' );
        if ( $cached !== false ) {
            return self::respond( $cached, true );
        }
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT id, address, city, list_price, asset_type, bedrooms, bathrooms, sqft, latitude, longitude
             FROM " . PWL_DB::listings_table() . " WHERE status='active' AND latitude IS NOT NULL LIMIT 2000"
        );
        $features = [];
        foreach ( $rows as $r ) {
            $features[] = [
                'type'       => 'Feature',
                'geometry'   => [ 'type' => 'Point', 'coordinates' => [ (float) $r->longitude, (float) $r->latitude ] ],
                'properties' => [
                    'id'    => (int) $r->id,
                    'price' => (float) $r->list_price,
                    'addr'  => $r->address . ', ' . $r->city,
                    'type'  => $r->asset_type,
                    'beds'  => (int) $r->bedrooms,
                    'baths' => (float) $r->bathrooms,
                    'sqft'  => (int) $r->sqft,
                    'url'   => PWL_Listing::listing_url( $r->id ),
                ],
            ];
        }
        $payload = [ 'type' => 'FeatureCollection', 'features' => $features ];
        PWL_Cache::set( 'pwl_rest_map', $payload, 10 * MINUTE_IN_SECONDS );
        return self::respond( $payload, false );
    }

    // ── Helpers ─────────────────────────────────────────────────────────────────
    private static function shape_listing( object $l, bool $full = false ): array {
        $data = [
            'id'             => (int) $l->id,
            'mls_id'         => $l->mls_id,
            'asset_type'     => $l->asset_type,
            'status'         => $l->status,
            'list_price'     => (float) $l->list_price,
            'address'        => $l->address,
            'city'           => $l->city,
            'state'          => $l->state,
            'zip_code'       => $l->zip_code,
            'latitude'       => $l->latitude  !== null ? (float) $l->latitude  : null,
            'longitude'      => $l->longitude !== null ? (float) $l->longitude : null,
            'bedrooms'       => $l->bedrooms  !== null ? (int) $l->bedrooms    : null,
            'bathrooms'      => $l->bathrooms !== null ? (float) $l->bathrooms : null,
            'sqft'           => $l->sqft      !== null ? (int) $l->sqft        : null,
            'days_on_market' => (int) $l->days_on_market,
            'photo'          => PWL_Listing::first_photo( $l ),
            'url'            => PWL_Listing::listing_url( $l->id ),
            'walk_score'     => $l->walk_score    !== null ? (int) $l->walk_score : null,
            'crime_grade'    => $l->crime_grade,
            'school_rating'  => $l->school_rating !== null ? (float) $l->school_rating : null,
        ];
        if ( $full ) {
            $data['county']         = $l->county;
            $data['lot_sqft']       = $l->lot_sqft      !== null ? (int) $l->lot_sqft : null;
            $data['year_built']     = $l->year_built    !== null ? (int) $l->year_built : null;
            $data['garage_spaces']  = $l->garage_spaces !== null ? (int) $l->garage_spaces : null;
            $data['pool']           = (bool) $l->pool;
            $data['hoa_fee']        = (float) $l->hoa_fee;
            $data['property_taxes'] = $l->property_taxes !== null ? (float) $l->property_taxes : null;
            $data['cap_rate']       = $l->cap_rate !== null ? (float) $l->cap_rate : null;
            $data['noi']            = $l->noi      !== null ? (float) $l->noi : null;
            $data['num_units']      = $l->num_units !== null ? (int) $l->num_units : null;
            $data['description']    = $l->description;
            $data['virtual_tour']   = $l->virtual_tour;
            $data['photos']         = json_decode( $l->photos ?? '[]', true ) ?: [];
            $data['agent']          = [
                'name'      => $l->agent_name      ?? null,
                'email'     => $l->agent_email     ?? null,
                'phone'     => $l->agent_phone     ?? null,
                'brokerage' => $l->agent_brokerage ?? null,
            ];
        }
        return $data;
    }

    private static function respond( $data, bool $cached ): WP_REST_Response {
        $res = new WP_REST_Response( $data, 200 );
        $res->header( 'X-RealWise-Cache', $cached ? 'HIT' : 'MISS' );
        $res->header( 'Cache-Control', 'public, max-age=300' );
        return $res;
    }
}
