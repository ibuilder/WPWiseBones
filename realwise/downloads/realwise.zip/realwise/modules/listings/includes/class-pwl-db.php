<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWL_DB — schema installer and query helpers for RealWise Listings.
 */
class PWL_DB {

    public static function listings_table()     { global $wpdb; return $wpdb->prefix . 'pwl_listings'; }
    public static function agents_table()       { global $wpdb; return $wpdb->prefix . 'pwl_agents'; }
    public static function saved_table()        { global $wpdb; return $wpdb->prefix . 'pwl_saved'; }
    public static function scores_table()       { global $wpdb; return $wpdb->prefix . 'pwl_scores'; }
    public static function price_hist_table()   { global $wpdb; return $wpdb->prefix . 'pwl_price_history'; }
    public static function saved_search_table() { global $wpdb; return $wpdb->prefix . 'pwl_saved_searches'; }

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::agents_table() . " (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            mls_agent_id VARCHAR(64)  DEFAULT NULL,
            name         VARCHAR(120) NOT NULL DEFAULT '',
            email        VARCHAR(120) DEFAULT NULL,
            phone        VARCHAR(30)  DEFAULT NULL,
            brokerage    VARCHAR(150) DEFAULT NULL,
            license_num  VARCHAR(40)  DEFAULT NULL,
            photo_url    VARCHAR(255) DEFAULT NULL,
            bio          TEXT,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY email (email),
            KEY mls_agent_id (mls_agent_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::listings_table() . " (
            id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            mls_id           VARCHAR(80)   NOT NULL,
            asset_type       VARCHAR(32)   NOT NULL DEFAULT 'residential',
            status           VARCHAR(16)   NOT NULL DEFAULT 'active',
            list_price       DECIMAL(14,2) DEFAULT NULL,
            address          VARCHAR(255)  DEFAULT NULL,
            city             VARCHAR(80)   DEFAULT NULL,
            state            VARCHAR(4)    DEFAULT NULL,
            zip_code         VARCHAR(12)   DEFAULT NULL,
            latitude         DECIMAL(10,7) DEFAULT NULL,
            longitude        DECIMAL(10,7) DEFAULT NULL,
            county           VARCHAR(80)   DEFAULT NULL,
            bedrooms         TINYINT UNSIGNED DEFAULT NULL,
            bathrooms        DECIMAL(4,1)  DEFAULT NULL,
            sqft             MEDIUMINT UNSIGNED DEFAULT NULL,
            lot_sqft         INT UNSIGNED  DEFAULT NULL,
            year_built       SMALLINT UNSIGNED DEFAULT NULL,
            garage_spaces    TINYINT UNSIGNED DEFAULT NULL,
            pool             TINYINT(1)    DEFAULT 0,
            hoa_fee          DECIMAL(10,2) DEFAULT 0,
            property_taxes   DECIMAL(10,2) DEFAULT NULL,
            flood_zone       VARCHAR(12)   DEFAULT NULL,
            zoning           VARCHAR(32)   DEFAULT NULL,
            cap_rate         DECIMAL(5,2)  DEFAULT NULL,
            noi              DECIMAL(14,2) DEFAULT NULL,
            occupancy_rate   DECIMAL(5,2)  DEFAULT NULL,
            num_units        SMALLINT UNSIGNED DEFAULT NULL,
            virtual_tour     VARCHAR(255)  DEFAULT NULL,
            photos           LONGTEXT      DEFAULT NULL,
            description      LONGTEXT      DEFAULT NULL,
            days_on_market   SMALLINT UNSIGNED DEFAULT 0,
            price_reductions TINYINT UNSIGNED  DEFAULT 0,
            agent_id         BIGINT UNSIGNED   DEFAULT NULL,
            walk_score       TINYINT UNSIGNED  DEFAULT NULL,
            bike_score       TINYINT UNSIGNED  DEFAULT NULL,
            transit_score    TINYINT UNSIGNED  DEFAULT NULL,
            crime_score      TINYINT UNSIGNED  DEFAULT NULL,
            crime_grade      VARCHAR(4)    DEFAULT NULL,
            school_rating    DECIMAL(3,1)  DEFAULT NULL,
            pulled_at        DATETIME      DEFAULT NULL,
            created_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY mls_id (mls_id),
            KEY status_type (status, asset_type),
            KEY city_zip    (city, zip_code),
            KEY lat_lon     (latitude, longitude),
            KEY list_price  (list_price),
            KEY agent_id    (agent_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::saved_table() . " (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT UNSIGNED NOT NULL,
            listing_id BIGINT UNSIGNED NOT NULL,
            notes      TEXT,
            saved_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_listing (user_id, listing_id),
            KEY user_id (user_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::scores_table() . " (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            listing_id   BIGINT UNSIGNED NOT NULL,
            score_type   VARCHAR(32)  NOT NULL,
            score_value  DECIMAL(5,1) DEFAULT NULL,
            score_label  VARCHAR(16)  DEFAULT NULL,
            raw_response LONGTEXT     DEFAULT NULL,
            fetched_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY listing_type (listing_id, score_type)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::price_hist_table() . " (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            listing_id BIGINT UNSIGNED NOT NULL,
            price      DECIMAL(14,2) NOT NULL,
            event_type VARCHAR(32)   DEFAULT 'price_change',
            event_date DATE          NOT NULL,
            PRIMARY KEY (id),
            KEY listing_id (listing_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::saved_search_table() . " (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id        BIGINT UNSIGNED NOT NULL,
            label          VARCHAR(150) NOT NULL DEFAULT 'My Search',
            criteria_json  LONGTEXT,
            frequency      VARCHAR(16)  NOT NULL DEFAULT 'daily',
            last_notified  DATETIME     DEFAULT NULL,
            last_max_id    BIGINT UNSIGNED DEFAULT 0,
            active         TINYINT(1)   DEFAULT 1,
            created_at     DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY freq_active (frequency, active)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) dbDelta( $q );
        update_option( 'pwl_db_version', PWL_DB_VER );
    }

    public static function deactivate(): void {}

    public static function search( array $args = [] ): array {
        global $wpdb;
        $defaults = [
            'q'          => '',
            'asset_type' => 'all',
            'min_price'  => 0,
            'max_price'  => 0,
            'min_beds'   => 0,
            'min_baths'  => 0,
            'city'       => '',
            'zip'        => '',
            'status'     => 'active',
            'min_id'     => 0,
            'order_by'   => 'days_on_market',
            'order'      => 'ASC',
            'per_page'   => 24,
            'page'       => 1,
        ];
        $args   = wp_parse_args( $args, $defaults );
        $where  = [ '1=1' ];
        $params = [];

        if ( $args['status'] !== 'all' )     { $where[] = 'status = %s';      $params[] = $args['status']; }
        if ( $args['asset_type'] !== 'all' ) { $where[] = 'asset_type = %s';  $params[] = $args['asset_type']; }
        if ( $args['q'] ) {
            $like = '%' . $wpdb->esc_like( $args['q'] ) . '%';
            $where[] = '(address LIKE %s OR city LIKE %s OR zip_code LIKE %s OR description LIKE %s)';
            $params  = array_merge( $params, [ $like, $like, $like, $like ] );
        }
        if ( $args['min_price'] > 0 ) { $where[] = 'list_price >= %f'; $params[] = (float) $args['min_price']; }
        if ( $args['max_price'] > 0 ) { $where[] = 'list_price <= %f'; $params[] = (float) $args['max_price']; }
        if ( $args['min_beds']  > 0 ) { $where[] = 'bedrooms >= %d';   $params[] = (int)   $args['min_beds']; }
        if ( $args['min_baths'] > 0 ) { $where[] = 'bathrooms >= %f';  $params[] = (float) $args['min_baths']; }
        if ( $args['city'] )          { $where[] = 'city = %s';         $params[] = $args['city']; }
        if ( $args['zip'] )           { $where[] = 'zip_code = %s';     $params[] = $args['zip']; }
        if ( $args['min_id']  > 0 )   { $where[] = 'id > %d';           $params[] = (int) $args['min_id']; }

        // list_price_d is a convenience alias for list_price DESC
        if ( $args['order_by'] === 'list_price_d' ) {
            $args['order_by'] = 'list_price';
            $args['order']    = 'DESC';
        }
        $allowed  = [ 'list_price', 'days_on_market', 'created_at', 'sqft', 'year_built' ];
        $order_by = in_array( $args['order_by'], $allowed ) ? $args['order_by'] : 'days_on_market';
        $order    = strtoupper( $args['order'] ) === 'DESC' ? 'DESC' : 'ASC';
        $where_sql = implode( ' AND ', $where );
        $offset    = ( max( 1, (int) $args['page'] ) - 1 ) * (int) $args['per_page'];
        $table     = self::listings_table();

        $count_sql = "SELECT COUNT(*) FROM $table WHERE $where_sql";
        $data_sql  = "SELECT * FROM $table WHERE $where_sql ORDER BY $order_by $order LIMIT %d OFFSET %d";

        if ( $params ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared -- dynamic WHERE is built from a whitelist
            $total    = (int) $wpdb->get_var( $wpdb->prepare( $count_sql, ...$params ) );
            $listings = $wpdb->get_results( $wpdb->prepare( $data_sql, ...array_merge( $params, [ (int) $args['per_page'], $offset ] ) ) );
        } else {
            // No user-supplied params — count query is safe to run without prepare()
            $total    = (int) $wpdb->get_var( $count_sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $listings = $wpdb->get_results( $wpdb->prepare( $data_sql, (int) $args['per_page'], $offset ) );
        }
        return compact( 'listings', 'total' );
    }

    public static function get_listing( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT l.*, a.name as agent_name, a.email as agent_email, a.phone as agent_phone,
                    a.brokerage as agent_brokerage, a.photo_url as agent_photo
             FROM ' . self::listings_table() . ' l
             LEFT JOIN ' . self::agents_table() . ' a ON l.agent_id = a.id
             WHERE l.id = %d', $id
        ) );
    }

    public static function get_by_mls_id( string $mls_id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . self::listings_table() . ' WHERE mls_id = %s', $mls_id
        ) );
    }

    public static function upsert_listing( array $data ): int {
        global $wpdb;
        $existing = self::get_by_mls_id( $data['mls_id'] );
        if ( $existing ) {
            $wpdb->update( self::listings_table(), $data, [ 'mls_id' => $data['mls_id'] ] );
            $id = $existing->id;
        } else {
            $wpdb->insert( self::listings_table(), $data );
            $id = $wpdb->insert_id;
        }
        // Invalidate cached search/map/REST responses
        if ( class_exists( 'PWL_Cache' ) ) PWL_Cache::flush();
        return $id;
    }

    public static function upsert_agent( array $data ): int {
        global $wpdb;
        $table = self::agents_table();
        if ( ! empty( $data['email'] ) ) {
            $existing = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM $table WHERE email = %s", $data['email'] ) );
            if ( $existing ) {
                $wpdb->update( $table, $data, [ 'email' => $data['email'] ] );
                return $existing->id;
            }
        }
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }

    public static function get_price_history( int $listing_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::price_hist_table() . ' WHERE listing_id = %d ORDER BY event_date ASC', $listing_id
        ) ) ?: [];
    }

    public static function save_listing_for_user( int $user_id, int $listing_id, string $notes = '' ): bool {
        global $wpdb;
        $exists = $wpdb->get_var( $wpdb->prepare(
            'SELECT id FROM ' . self::saved_table() . ' WHERE user_id = %d AND listing_id = %d', $user_id, $listing_id
        ) );
        if ( $exists ) return false;
        return (bool) $wpdb->insert( self::saved_table(), compact( 'user_id', 'listing_id', 'notes' ) );
    }

    public static function get_saved_for_user( int $user_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT s.*, l.address, l.city, l.state, l.list_price, l.bedrooms, l.bathrooms,
                    l.sqft, l.asset_type, l.photos, l.status, l.days_on_market
             FROM ' . self::saved_table() . ' s
             JOIN ' . self::listings_table() . ' l ON s.listing_id = l.id
             WHERE s.user_id = %d ORDER BY s.saved_at DESC', $user_id
        ) ) ?: [];
    }

    public static function get_nearby( float $lat, float $lon, int $radius_miles = 1, int $limit = 5 ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT *, (3959 * acos(cos(radians(%f)) * cos(radians(latitude)) *
             cos(radians(longitude) - radians(%f)) + sin(radians(%f)) * sin(radians(latitude))))
             AS distance FROM ' . self::listings_table() .
            ' WHERE status = %s AND latitude IS NOT NULL
             HAVING distance < %d ORDER BY distance ASC LIMIT %d',
            $lat, $lon, $lat, 'active', $radius_miles, $limit
        ) ) ?: [];
    }

    // ── Saved searches ────────────────────────────────────────────────────────
    public static function save_search( int $user_id, string $label, array $criteria, string $frequency = 'daily' ): int {
        global $wpdb;
        // Seed last_max_id with current max so the user is only alerted to NEW listings
        $max_id = (int) $wpdb->get_var( 'SELECT MAX(id) FROM ' . self::listings_table() );
        $wpdb->insert( self::saved_search_table(), [
            'user_id'       => $user_id,
            'label'         => $label,
            'criteria_json' => wp_json_encode( $criteria ),
            'frequency'     => in_array( $frequency, [ 'instant', 'daily', 'weekly' ], true ) ? $frequency : 'daily',
            'last_max_id'   => $max_id,
        ] );
        return $wpdb->insert_id;
    }

    public static function get_user_searches( int $user_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::saved_search_table() . ' WHERE user_id = %d ORDER BY created_at DESC', $user_id
        ) ) ?: [];
    }

    public static function get_search( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . self::saved_search_table() . ' WHERE id = %d', $id
        ) );
    }

    public static function delete_search( int $id, int $user_id ): bool {
        global $wpdb;
        return (bool) $wpdb->delete( self::saved_search_table(), [ 'id' => $id, 'user_id' => $user_id ] );
    }

    public static function get_searches_by_frequency( string $frequency ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::saved_search_table() . ' WHERE frequency = %s AND active = 1', $frequency
        ) ) ?: [];
    }

    public static function update_search_notified( int $id, int $max_id ): void {
        global $wpdb;
        $wpdb->update( self::saved_search_table(),
            [ 'last_notified' => current_time( 'mysql' ), 'last_max_id' => $max_id ],
            [ 'id' => $id ]
        );
    }
}
