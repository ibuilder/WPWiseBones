<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class PWL_Widgets {
    public static function init(): void {
        add_action( 'widgets_init', function () {
            register_widget( 'PWL_Featured_Widget' );
            register_widget( 'PWL_Mortgage_Widget' );
            register_widget( 'PWL_Search_Widget' );
        } );
    }
}

/**
 * PWL_Featured_Widget — sidebar featured listings.
 */
class PWL_Featured_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'pwl_featured', 'RealWise: Featured Listings', [
            'description' => 'Show featured property listings in a sidebar.',
            'classname'   => 'pwl-widget pwl-widget--featured',
        ] );
    }

    public function widget( $args, $instance ): void {
        $title  = apply_filters( 'widget_title', $instance['title'] ?? 'Featured Listings' );
        $type   = $instance['asset_type'] ?? 'all';
        $limit  = (int) ( $instance['limit'] ?? 4 );
        $result = PWL_DB::search( [ 'asset_type' => $type, 'per_page' => $limit, 'order_by' => 'created_at', 'order' => 'DESC' ] );

        echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress-provided widget wrapper markup.
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WP-provided title wrappers; title is escaped.
        echo '<ul class="pwl-widget__list">';
        foreach ( $result['listings'] as $listing ) {
            $photo = PWL_Listing::first_photo( $listing );
            $url   = PWL_Listing::listing_url( $listing->id );
            printf(
                '<li class="pwl-widget__item">%s<a href="%s" class="pwl-widget__title">%s</a><span class="pwl-widget__price">%s</span></li>',
                $photo ? '<img src="' . esc_url( $photo ) . '" class="pwl-widget__thumb" alt="" loading="lazy">' : '',
                esc_url( $url ),
                esc_html( $listing->address . ', ' . $listing->city ),
                esc_html( PWL_Listing::format_price( $listing->list_price ) )
            );
        }
        echo '</ul>';
        echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress-provided widget wrapper markup.
    }

    public function form( $instance ): void {
        $title = $instance['title']      ?? 'Featured Listings';
        $type  = $instance['asset_type'] ?? 'all';
        $limit = (int) ( $instance['limit'] ?? 4 );
        $types = [ 'all', 'residential', 'commercial', 'industrial', 'land', 'multifamily', 'aviation' ];
        ?>
        <p><label><?php esc_html_e( 'Title', 'realwise' ); ?>
            <input class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </label></p>
        <p><label><?php esc_html_e( 'Asset Type', 'realwise' ); ?>
            <select class="widefat" name="<?php echo esc_attr( $this->get_field_name( 'asset_type' ) ); ?>">
                <?php foreach ( $types as $t ) : ?>
                    <option value="<?php echo esc_attr( $t ); ?>" <?php selected( $type, $t ); ?>><?php echo esc_html( ucfirst( $t ) ); ?></option>
                <?php endforeach; ?>
            </select>
        </label></p>
        <p><label><?php esc_html_e( 'Count', 'realwise' ); ?>
            <input class="tiny-text" name="<?php echo esc_attr( $this->get_field_name( 'limit' ) ); ?>" type="number" value="<?php echo esc_attr( $limit ); ?>" min="1" max="12">
        </label></p>
        <?php
    }

    public function update( $new, $old ): array {
        return [
            'title'      => sanitize_text_field( $new['title']      ?? '' ),
            'asset_type' => sanitize_key(        $new['asset_type'] ?? 'all' ),
            'limit'      => (int)                $new['limit'],
        ];
    }
}

/**
 * PWL_Mortgage_Widget — sidebar mortgage calculator.
 */
class PWL_Mortgage_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'pwl_mortgage_widget', 'RealWise: Mortgage Calculator', [
            'description' => 'Quick mortgage calculator in a sidebar.',
            'classname'   => 'pwl-widget pwl-widget--mortgage',
        ] );
    }

    public function widget( $args, $instance ): void {
        $title = apply_filters( 'widget_title', $instance['title'] ?? 'Mortgage Calculator' );
        echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress-provided widget wrapper markup.
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WP-provided title wrappers; title is escaped.
        echo do_shortcode( '[pwl_mortgage]' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Shortcode output is already escaped by its handler.
        echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress-provided widget wrapper markup.
    }

    public function form( $instance ): void {
        $title = $instance['title'] ?? 'Mortgage Calculator';
        echo '<p><label>' . esc_html__( 'Title', 'realwise' )
            . '<input class="widefat" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '"></label></p>';
    }

    public function update( $new, $old ): array {
        return [ 'title' => sanitize_text_field( $new['title'] ?? '' ) ];
    }
}

/**
 * PWL_Search_Widget — compact sidebar search form.
 */
class PWL_Search_Widget extends WP_Widget {

    public function __construct() {
        parent::__construct( 'pwl_search_widget', 'RealWise: Property Search', [
            'description' => 'Quick property search form for sidebars.',
            'classname'   => 'pwl-widget pwl-widget--search',
        ] );
    }

    public function widget( $args, $instance ): void {
        $title      = apply_filters( 'widget_title', $instance['title'] ?? 'Search Properties' );
        $search_url = PWL_Listing::search_url();
        echo $args['before_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress-provided widget wrapper markup.
        if ( $title ) echo $args['before_title'] . esc_html( $title ) . $args['after_title']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WP-provided title wrappers; title is escaped.
        ?>
        <form class="pwl-widget__search-form" action="<?php echo esc_url( $search_url ); ?>" method="get">
            <input type="text" name="q" placeholder="<?php esc_attr_e( 'City, ZIP, or address…', 'realwise' ); ?>" class="pwl-widget__search-input">
            <select name="type" class="pwl-widget__search-select">
                <option value="all"><?php esc_html_e( 'All Types', 'realwise' ); ?></option>
                <?php foreach ( [ 'residential', 'commercial', 'industrial', 'land', 'multifamily', 'aviation' ] as $t ) : ?>
                    <option value="<?php echo esc_attr( $t ); ?>"><?php echo esc_html( ucfirst( $t ) ); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="pwl-widget__search-btn"><?php esc_html_e( 'Search', 'realwise' ); ?></button>
        </form>
        <?php
        echo $args['after_widget']; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- WordPress-provided widget wrapper markup.
    }

    public function form( $instance ): void {
        $title = $instance['title'] ?? 'Search Properties';
        echo '<p><label>' . esc_html__( 'Title', 'realwise' )
            . '<input class="widefat" name="' . esc_attr( $this->get_field_name( 'title' ) ) . '" type="text" value="' . esc_attr( $title ) . '"></label></p>';
    }

    public function update( $new, $old ): array {
        return [ 'title' => sanitize_text_field( $new['title'] ?? '' ) ];
    }
}
