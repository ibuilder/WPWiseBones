<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWL_Ajax — AJAX endpoints for search, save, mortgage, scores, map.
 */
class PWL_Ajax {

    public static function init(): void {
        $actions = [
            'pwl_search'          => [ 'search',         true  ],
            'pwl_save_listing'    => [ 'save_listing',   false ],
            'pwl_unsave_listing'  => [ 'unsave',         false ],
            'pwl_mortgage_calc'   => [ 'mortgage_calc',  true  ],
            'pwl_contact_agent'   => [ 'contact_agent',  false ],
            'pwl_get_scores'      => [ 'get_scores',     true  ],
            'pwl_map_data'        => [ 'map_data',       true  ],
            'pwl_save_search'     => [ 'save_search',    false ],
            'pwl_delete_search'   => [ 'delete_search',  false ],
        ];
        foreach ( $actions as $action => [ $callback, $nopriv ] ) {
            add_action( 'wp_ajax_' . $action, [ __CLASS__, $callback ] );
            if ( $nopriv ) add_action( 'wp_ajax_nopriv_' . $action, [ __CLASS__, $callback ] );
        }
    }

    private static function verify(): void {
        if ( ! check_ajax_referer( 'pwl_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed.' ], 403 );
        }
    }

    public static function search(): void {
        self::verify();
        $args   = array_map( 'sanitize_text_field', wp_unslash( (array) ( $_POST['args'] ?? [] ) ) );
        $result = PWL_DB::search( $args );
        ob_start();
        $listings = $result['listings'];
        include PWL_DIR . 'templates/listing-grid.php';
        $html = ob_get_clean();
        wp_send_json_success( [ 'html' => $html, 'total' => $result['total'] ] );
    }

    public static function map_data(): void {
        self::verify();
        // Served from cache when warm — same payload as the REST /map endpoint
        $cached = PWL_Cache::get( 'pwl_ajax_map' );
        if ( $cached !== false ) {
            wp_send_json( $cached );
        }
        global $wpdb;
        $rows = $wpdb->get_results(
            "SELECT id, address, city, list_price, asset_type, bedrooms, bathrooms, sqft, latitude, longitude
             FROM " . PWL_DB::listings_table() . " WHERE status='active' AND latitude IS NOT NULL LIMIT 2000"
        );
        $features = [];
        foreach ( $rows as $r ) {
            $features[] = [
                'type'       => 'Feature',
                'geometry'   => [ 'type' => 'Point', 'coordinates' => [ (float) $r->longitude, (float) $r->latitude ] ],
                'properties' => [
                    'id'    => (int) $r->id, 'price' => (float) $r->list_price,
                    'addr'  => $r->address . ', ' . $r->city,
                    'type'  => $r->asset_type,
                    'beds'  => (int) $r->bedrooms, 'baths' => (float) $r->bathrooms, 'sqft' => (int) $r->sqft,
                    'url'   => PWL_Listing::listing_url( $r->id ),
                ],
            ];
        }
        $payload = [ 'type' => 'FeatureCollection', 'features' => $features ];
        PWL_Cache::set( 'pwl_ajax_map', $payload, 10 * MINUTE_IN_SECONDS );
        wp_send_json( $payload );
    }

    public static function save_listing(): void {
        self::verify();
        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
        $notes      = sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) );
        if ( ! $listing_id ) wp_send_json_error( 'Invalid listing.' );
        $saved = PWL_DB::save_listing_for_user( get_current_user_id(), $listing_id, $notes );
        wp_send_json_success( [ 'saved' => $saved ] );
    }

    public static function unsave(): void {
        self::verify();
        global $wpdb;
        $wpdb->delete( PWL_DB::saved_table(), [
            'user_id'    => get_current_user_id(),
            'listing_id' => (int) ( $_POST['listing_id'] ?? 0 ),
        ] );
        wp_send_json_success();
    }

    // ── Saved searches ────────────────────────────────────────────────────────
    public static function save_search(): void {
        self::verify();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'Login required.' );
        $label     = sanitize_text_field( wp_unslash( $_POST['label'] ?? 'My Search' ) );
        $frequency = sanitize_key( wp_unslash( $_POST['frequency'] ?? 'daily' ) );
        $raw       = (array) ( $_POST['criteria'] ?? [] );

        // Whitelist + sanitize criteria fields
        $allowed  = [ 'q', 'asset_type', 'min_price', 'max_price', 'min_beds', 'min_baths', 'city', 'zip', 'status' ];
        $criteria = [];
        foreach ( $allowed as $key ) {
            if ( ! isset( $raw[ $key ] ) || $raw[ $key ] === '' ) continue;
            $criteria[ $key ] = in_array( $key, [ 'min_price', 'max_price', 'min_baths' ], true )
                ? (float) $raw[ $key ]
                : ( $key === 'min_beds' ? (int) $raw[ $key ] : sanitize_text_field( $raw[ $key ] ) );
        }
        // Cap number of saved searches per user
        $existing = PWL_DB::get_user_searches( get_current_user_id() );
        if ( count( $existing ) >= 25 ) {
            wp_send_json_error( 'You have reached the maximum of 25 saved searches.' );
        }
        $id = PWL_DB::save_search( get_current_user_id(), $label, $criteria, $frequency );
        wp_send_json_success( [ 'search_id' => $id, 'label' => $label ] );
    }

    public static function delete_search(): void {
        self::verify();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'Login required.' );
        $id = (int) ( $_POST['search_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'Invalid search.' );
        PWL_DB::delete_search( $id, get_current_user_id() );
        wp_send_json_success();
    }

    public static function mortgage_calc(): void {
        self::verify();
        $price    = (float) ( $_POST['price']    ?? 0 );
        $down_pct = (float) ( $_POST['down_pct'] ?? 20 ) / 100;
        $rate     = (float) ( $_POST['rate']     ?? 0  ) / 100;
        $years    = (int)   ( $_POST['years']    ?? 30 );
        if ( $rate <= 0 ) $rate = PWL_Mortgage::current_rate();
        $summary = PWL_Mortgage::summary( $price, $down_pct, $rate, $years );
        $closing = PWL_Mortgage::closing_costs( $price );
        $sched   = array_slice( PWL_Mortgage::amortization( $price * ( 1 - $down_pct ), $rate, $years ), 0, 360 );
        wp_send_json_success( compact( 'summary', 'closing', 'sched' ) );
    }

    public static function get_scores(): void {
        self::verify();
        $id      = (int) ( $_POST['listing_id'] ?? 0 );
        $listing = PWL_DB::get_listing( $id );
        if ( ! $listing ) wp_send_json_error( 'Not found', 404 );
        wp_send_json_success( [
            'walk'    => PWL_Scores::get_walk_score( $listing ),
            'crime'   => PWL_Scores::get_crime( $listing ),
            'schools' => PWL_Scores::get_schools( $listing ),
        ] );
    }

    public static function contact_agent(): void {
        self::verify();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'Login required.' );

        // Rate limit: 5 contact emails per user per hour
        $user_id    = get_current_user_id();
        $rate_key   = 'pwl_contact_rate_' . $user_id;
        $rate_count = (int) get_transient( $rate_key );
        if ( $rate_count >= 5 ) {
            wp_send_json_error( 'Too many messages. Please wait before sending another.' );
        }
        set_transient( $rate_key, $rate_count + 1, HOUR_IN_SECONDS );

        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
        $message    = wp_kses( wp_unslash( $_POST['message'] ?? '' ), [] );
        $listing    = PWL_DB::get_listing( $listing_id );
        if ( ! $listing )            wp_send_json_error( 'Listing not found.' );
        if ( ! $listing->agent_email ) wp_send_json_error( 'No agent contact on file.' );
        $user = wp_get_current_user();

        // When RealWise CRM is active it sends a richer agent notification with a
        // CRM link, so suppress this plainer one to avoid a duplicate email.
        $send_email = apply_filters( 'pwl_send_agent_email', true, $listing, $user );

        $sent = false;
        if ( $send_email ) {
            $to      = sanitize_email( $listing->agent_email );
            $subject = sprintf( 'New inquiry: %s', $listing->address );
            $body    = sprintf(
                "Inquiry from %s (%s):\n\n%s, %s — listed at %s\n\n\"%s\"\n\nReply directly to this email.",
                $user->display_name, $user->user_email, $listing->address, $listing->city,
                PWL_Listing::format_price( $listing->list_price ), $message
            );
            $sent = wp_mail( $to, $subject, $body, [ 'Reply-To: ' . $user->user_email ] );
        }
        wp_send_json_success( [ 'sent' => $sent ] );
    }
}
