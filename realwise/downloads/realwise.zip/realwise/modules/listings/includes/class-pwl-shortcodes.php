<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWL_Shortcodes
 *
 * [pwl_search]              — search bar + results grid + map
 * [pwl_listing id="123"]    — single listing detail
 * [pwl_mortgage]            — standalone mortgage calculator
 * [pwl_saved]               — logged-in user's saved properties
 * [pwl_featured limit="6"]  — featured listings grid
 */
class PWL_Shortcodes {

    public static function init(): void {
        $codes = [
            'pwl_search'         => 'render_search',
            'pwl_listing'        => 'render_listing',
            'pwl_mortgage'       => 'render_mortgage',
            'pwl_saved'          => 'render_saved',
            'pwl_featured'       => 'render_featured',
            'pwl_saved_searches' => 'render_saved_searches',
        ];
        foreach ( $codes as $tag => $method ) {
            add_shortcode( $tag, [ __CLASS__, $method ] );
        }
    }

    public static function render_search( array $atts ): string {
        $atts = shortcode_atts( [
            'show_map'     => 'true',
            'default_type' => 'all',
            'per_page'     => 12,
            'show_filters' => 'true',
        ], $atts );

        $args = [
            'q'          => sanitize_text_field( wp_unslash( $_GET['q']       ?? '' ) ),
            'asset_type' => sanitize_text_field( wp_unslash( $_GET['type']    ?? $atts['default_type'] ) ),
            'min_price'  => (float) ( $_GET['min_price'] ?? 0 ),
            'max_price'  => (float) ( $_GET['max_price'] ?? 0 ),
            'min_beds'   => (int)    ( $_GET['min_beds']  ?? 0 ),
            'min_baths'  => (float)  ( $_GET['min_baths'] ?? 0 ),
            'status'     => in_array( $_GET['status'] ?? 'active', [ 'active', 'pending', 'closed', 'all' ] ) ? $_GET['status'] : 'active',
            'zip'        => sanitize_text_field( wp_unslash( $_GET['zip']     ?? '' ) ),
            'city'       => sanitize_text_field( wp_unslash( $_GET['city']    ?? '' ) ),
            'order_by'   => sanitize_key( wp_unslash( $_GET['order_by'] ?? 'days_on_market' ) ),
            'order'      => in_array( strtoupper( $_GET['order'] ?? '' ), [ 'ASC', 'DESC' ] ) ? strtoupper( $_GET['order'] ) : 'ASC',
            'per_page'   => (int) $atts['per_page'],
            'page'       => max( 1, (int) ( $_GET['pwl_page'] ?? 1 ) ),
        ];

        $result   = PWL_DB::search( $args );
        $listings = $result['listings'];
        $total    = $result['total'];
        $pages    = (int) ceil( $total / $args['per_page'] );

        ob_start();
        include PWL_DIR . 'templates/search.php';
        return ob_get_clean();
    }

    public static function render_listing( array $atts ): string {
        $atts    = shortcode_atts( [ 'id' => 0 ], $atts );
        $id      = (int) $atts['id'] ?: (int) ( $_GET['pwl_id'] ?? 0 );
        if ( ! $id ) return '<p class="pwl-error">No listing ID specified.</p>';

        $listing = PWL_DB::get_listing( $id );
        if ( ! $listing ) return '<p class="pwl-error">Listing not found.</p>';

        $walk    = PWL_Scores::get_walk_score( $listing );
        $crime   = PWL_Scores::get_crime( $listing );
        $schools = PWL_Scores::get_schools( $listing );
        $rate        = PWL_Mortgage::current_rate();
        $summary     = PWL_Mortgage::summary( (float) $listing->list_price, 0.20, $rate, 30 );
        $closing_est = PWL_Mortgage::closing_costs( (float) $listing->list_price, $listing->state ?? '' );
        $price_history = PWL_DB::get_price_history( $id );
        $nearby  = ( $listing->latitude && $listing->longitude )
            ? PWL_DB::get_nearby( (float) $listing->latitude, (float) $listing->longitude, 1, 4 )
            : [];
        $photos  = json_decode( $listing->photos ?? '[]', true ) ?: [];

        ob_start();
        include PWL_DIR . 'templates/listing-detail.php';
        return ob_get_clean();
    }

    public static function render_mortgage( array $atts ): string {
        $atts = shortcode_atts( [
            'price'      => 300000,
            'down_pct'   => 20,
            'rate'       => '',
            'years'      => 30,
            'show_table' => 'false',
        ], $atts );

        $rate        = $atts['rate'] ? (float) $atts['rate'] / 100 : PWL_Mortgage::current_rate();
        $summary     = PWL_Mortgage::summary( (float) $atts['price'], (float) $atts['down_pct'] / 100, $rate, (int) $atts['years'] );
        $closing_est = PWL_Mortgage::closing_costs( (float) $atts['price'] );

        ob_start();
        include PWL_DIR . 'templates/mortgage-calculator.php';
        return ob_get_clean();
    }

    public static function render_saved( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="pwl-notice">' . esc_html__( 'Please log in to view your saved properties.', 'realwise' ) . '</p>';
        }
        $saved = PWL_DB::get_saved_for_user( get_current_user_id() );
        ob_start();
        include PWL_DIR . 'templates/saved-properties.php';
        return ob_get_clean();
    }

    public static function render_featured( array $atts ): string {
        $atts   = shortcode_atts( [ 'type' => 'all', 'limit' => 6, 'order_by' => 'created_at', 'order' => 'DESC' ], $atts );
        $result = PWL_DB::search( [
            'asset_type' => $atts['type'],
            'per_page'   => (int) $atts['limit'],
            'order_by'   => sanitize_key( $atts['order_by'] ),
            'order'      => strtoupper( $atts['order'] ),
        ] );
        $listings = $result['listings'];
        ob_start();
        include PWL_DIR . 'templates/listing-grid.php';
        return ob_get_clean();
    }

    public static function render_saved_searches( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="pwl-notice">' . esc_html__( 'Please log in to manage your saved searches and alerts.', 'realwise' ) . '</p>';
        }
        $searches = PWL_DB::get_user_searches( get_current_user_id() );
        ob_start();
        include PWL_DIR . 'templates/saved-searches.php';
        return ob_get_clean();
    }
}
