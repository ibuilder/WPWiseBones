<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWL_Admin — admin menu, settings, listings table, agents table.
 */
class PWL_Admin {

    private static array $fields = [];

    public static function init(): void {
        add_action( 'admin_menu',          [ __CLASS__, 'menu'              ] );
        add_action( 'admin_init',          [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets'          ] );
        add_action( 'admin_post_pwl_flush_scores',  [ __CLASS__, 'flush_scores'   ] );
        add_action( 'admin_post_pwl_save_listing',  [ __CLASS__, 'save_listing'   ] );
        add_action( 'admin_post_pwl_delete_listing',[ __CLASS__, 'delete_listing' ] );
        add_action( 'admin_post_pwl_save_agent',    [ __CLASS__, 'save_agent'     ] );
        add_action( 'admin_post_pwl_delete_agent',  [ __CLASS__, 'delete_agent'   ] );
    }

    public static function init_front(): void {
        add_action( 'wp_head', [ __CLASS__, 'seo_meta' ] );
    }

    public static function seo_meta(): void {
        $listing_page = (int) get_option( 'pwl_listing_page_id' );
        if ( ! $listing_page || ! is_page( $listing_page ) ) return;
        $id = (int) ( $_GET['pwl_id'] ?? 0 );
        if ( ! $id ) return;
        $listing = PWL_DB::get_listing( $id );
        if ( ! $listing ) return;

        $title    = esc_attr( $listing->address . ', ' . $listing->city . ', ' . $listing->state . ' — ' . PWL_Listing::format_price( $listing->list_price ) );
        $desc     = esc_attr( wp_trim_words( $listing->description ?? '', 30, '…' ) );
        $photo    = esc_url( PWL_Listing::first_photo( $listing ) );
        $url      = esc_url( PWL_Listing::listing_url( $id ) );
        $canon    = esc_url( add_query_arg( 'pwl_id', $id, get_permalink( $listing_page ) ) );

        // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- Every interpolated value is escaped at assignment above (esc_attr / esc_url).
        echo "<meta name=\"description\" content=\"{$desc}\">\n";
        echo "<link rel=\"canonical\" href=\"{$canon}\">\n";
        echo "<meta property=\"og:title\" content=\"{$title}\">\n";
        echo "<meta property=\"og:description\" content=\"{$desc}\">\n";
        echo "<meta property=\"og:url\" content=\"{$url}\">\n";
        echo "<meta property=\"og:type\" content=\"website\">\n";
        if ( $photo ) {
            echo "<meta property=\"og:image\" content=\"{$photo}\">\n";
        }
        echo "<meta name=\"twitter:card\" content=\"summary_large_image\">\n";
        echo "<meta name=\"twitter:title\" content=\"{$title}\">\n";
        if ( $photo ) echo "<meta name=\"twitter:image\" content=\"{$photo}\">\n";
        // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped
    }

    public static function menu(): void {
        add_menu_page(
            'RealWise Listings', 'RealWise', 'manage_options',
            'pwl-dashboard', [ __CLASS__, 'page_dashboard' ],
            'dashicons-building', 56
        );
        // The dashboard add_menu_page above auto-creates a first submenu duplicate;
        // overwrite its label to "Dashboard" by registering it explicitly first.
        // $position keeps a stable order even though the Tours and Investor Tools
        // (Developer) modules attach their own pages to this same menu.
        $sub = [
            'pwl-dashboard'    => [ __( 'Dashboard',    'realwise' ), 'page_dashboard',    10 ],
            'pwl-listings'     => [ __( 'All Listings', 'realwise' ), 'page_listings',     20 ],
            'pwl-listing-edit' => [ __( 'Add Listing',  'realwise' ), 'page_listing_edit', 30 ],
            'pwl-agents'       => [ __( 'Agents',       'realwise' ), 'page_agents',       40 ],
            'pwl-settings'     => [ __( 'Settings',     'realwise' ), 'page_settings',    100 ],
        ];
        foreach ( $sub as $slug => [ $label, $cb, $pos ] ) {
            // Every page stays registered AND visible so it is always accessible.
            add_submenu_page( 'pwl-dashboard', $label, $label, 'manage_options', $slug, [ __CLASS__, $cb ], $pos );
        }
    }

    public static function register_settings(): void {
        self::$fields = [
            'pwl_walkscore_key'       => 'Walk Score API Key',
            'pwl_crime_api_key'       => 'CrimeGrade API Key',
            'pwl_greatschools_key'    => 'GreatSchools API Key',
            'pwl_google_maps_key'     => 'Google Maps API Key',
            'pwl_fred_api_key'        => 'FRED API Key (live mortgage rates)',
            'pwl_default_rate'        => 'Default Interest Rate (%)',
            'pwl_currency_symbol'     => 'Currency Symbol',
            'pwl_cc_origination_pct'  => 'Loan Origination (%)',
            'pwl_cc_title_pct'        => 'Title Insurance (%)',
            'pwl_cc_transfer_tax_pct' => 'Transfer Tax (%)',
            'pwl_cc_prepaid_pct'      => 'Prepaid / Escrow (%)',
            'pwl_cc_appraisal'        => 'Appraisal Fee ($)',
            'pwl_cc_inspection'       => 'Inspection Fee ($)',
            'pwl_cc_attorney'         => 'Attorney Fee ($)',
            'pwl_cc_recording'        => 'Recording Fee ($)',
            'pwl_cc_warranty'         => 'Home Warranty ($)',
            'pwl_cc_misc'             => 'Miscellaneous ($)',
            'pwl_attom_api_key'       => 'ATTOM API Key (comps / ARV)',
            'pwl_comps_radius'        => 'Comps Search Radius (miles)',
            'pwl_listing_page_id'     => 'Listing Detail Page ID',
            'pwl_search_page_id'      => 'Search Page ID',
            'pwl_score_cache_hours'   => 'Score Cache Duration (hours)',
        ];
        foreach ( array_keys( self::$fields ) as $key ) {
            register_setting( 'pwl_settings_group', $key, [ 'sanitize_callback' => 'sanitize_text_field' ] );
        }
    }

    public static function assets( string $hook ): void {
        if ( strpos( $hook, 'pwl' ) === false ) return;
        wp_enqueue_style( 'pwl-admin', PWL_URL . 'assets/css/admin.css', [], PWL_VERSION );
    }

    public static function page_dashboard(): void {
        global $wpdb;
        $stats = [
            'total'  => $wpdb->get_var( 'SELECT COUNT(*) FROM ' . PWL_DB::listings_table() ),
            'active' => $wpdb->get_var( "SELECT COUNT(*) FROM " . PWL_DB::listings_table() . " WHERE status='active'" ),
            'agents' => $wpdb->get_var( 'SELECT COUNT(*) FROM ' . PWL_DB::agents_table() ),
            'saved'  => $wpdb->get_var( 'SELECT COUNT(*) FROM ' . PWL_DB::saved_table() ),
        ];
        $recent = $wpdb->get_results( "SELECT * FROM " . PWL_DB::listings_table() . " ORDER BY created_at DESC LIMIT 10" );
        include PWL_DIR . 'templates/admin/dashboard.php';
    }

    public static function page_listings(): void {
        global $wpdb;
        $per_page = 30;
        $page     = max( 1, (int) ( $_GET['paged'] ?? 1 ) );
        $offset   = ( $page - 1 ) * $per_page;
        $total    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . PWL_DB::listings_table() );
        $listings = $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . PWL_DB::listings_table() . ' ORDER BY updated_at DESC LIMIT %d OFFSET %d',
            $per_page, $offset
        ) );
        $pages = (int) ceil( $total / $per_page );
        include PWL_DIR . 'templates/admin/listings.php';
    }

    public static function page_agents(): void {
        global $wpdb;
        $editing = isset( $_GET['id'] ) ? $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . PWL_DB::agents_table() . ' WHERE id = %d', (int) $_GET['id']
        ) ) : null;
        $agents = $wpdb->get_results( 'SELECT * FROM ' . PWL_DB::agents_table() . ' ORDER BY name ASC LIMIT 200' );
        include PWL_DIR . 'templates/admin/agents.php';
    }

    public static function save_agent(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        check_admin_referer( 'pwl_save_agent' );
        $id   = (int) ( $_POST['agent_id'] ?? 0 );
        $data = [
            'name'        => sanitize_text_field( wp_unslash( $_POST['name']        ?? '' ) ),
            'email'       => sanitize_email( wp_unslash( $_POST['email']       ?? '' ) ) ?: null,
            'phone'       => sanitize_text_field( wp_unslash( $_POST['phone']       ?? '' ) ) ?: null,
            'brokerage'   => sanitize_text_field( wp_unslash( $_POST['brokerage']   ?? '' ) ) ?: null,
            'license_num' => sanitize_text_field( wp_unslash( $_POST['license_num'] ?? '' ) ) ?: null,
            'photo_url'   => esc_url_raw( wp_unslash( $_POST['photo_url']   ?? '' ) ) ?: null,
            'bio'         => sanitize_textarea_field( wp_unslash( $_POST['bio']     ?? '' ) ) ?: null,
        ];
        global $wpdb;
        if ( $id ) {
            $wpdb->update( PWL_DB::agents_table(), $data, [ 'id' => $id ] );
        } else {
            $wpdb->insert( PWL_DB::agents_table(), array_filter( $data, fn($v) => $v !== null ) );
            $id = $wpdb->insert_id;
        }
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwl-agents', 'id' => $id, 'msg' => 'saved' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function delete_agent(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        check_admin_referer( 'pwl_delete_agent' );
        $id = (int) ( $_GET['id'] ?? 0 );
        if ( $id ) {
            global $wpdb;
            $wpdb->delete( PWL_DB::agents_table(), [ 'id' => $id ] );
            // Unlink from listings
            $wpdb->update( PWL_DB::listings_table(), [ 'agent_id' => null ], [ 'agent_id' => $id ] );
        }
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwl-agents', 'msg' => 'deleted' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function page_settings(): void {
        $fields = self::$fields ?: [];
        include PWL_DIR . 'templates/admin/settings.php';
    }

    public static function page_listing_edit(): void {
        $id      = (int) ( $_GET['id'] ?? 0 );
        $listing = $id ? PWL_DB::get_listing( $id ) : null;
        $agents  = ( function () {
            global $wpdb;
            return $wpdb->get_results( 'SELECT id, name FROM ' . PWL_DB::agents_table() . ' ORDER BY name ASC LIMIT 500' );
        } )();
        $asset_types = [ 'residential', 'commercial', 'industrial', 'land', 'multifamily', 'aviation' ];
        $statuses    = [ 'active', 'pending', 'closed', 'delisted' ];
        include PWL_DIR . 'templates/admin/listing-edit.php';
    }

    public static function save_listing(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        check_admin_referer( 'pwl_save_listing' );
        $id = (int) ( $_POST['listing_id'] ?? 0 );
        $data = [
            'mls_id'         => sanitize_text_field( wp_unslash( $_POST['mls_id']         ?? '' ) ),
            'asset_type'     => sanitize_key( wp_unslash( $_POST['asset_type']     ?? 'residential' ) ),
            'status'         => sanitize_key( wp_unslash( $_POST['status']         ?? 'active' ) ),
            'list_price'     => (float)               $_POST['list_price']    ?? 0,
            'address'        => sanitize_text_field( wp_unslash( $_POST['address']        ?? '' ) ),
            'city'           => sanitize_text_field( wp_unslash( $_POST['city']           ?? '' ) ),
            'state'          => strtoupper( sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ) ) ),
            'zip_code'       => sanitize_text_field( wp_unslash( $_POST['zip_code']       ?? '' ) ),
            'county'         => sanitize_text_field( wp_unslash( $_POST['county']         ?? '' ) ),
            'latitude'       => $_POST['latitude']  !== '' ? (float) $_POST['latitude']  : null,
            'longitude'      => $_POST['longitude'] !== '' ? (float) $_POST['longitude'] : null,
            'bedrooms'       => $_POST['bedrooms']  !== '' ? (int)   $_POST['bedrooms']  : null,
            'bathrooms'      => $_POST['bathrooms'] !== '' ? (float) $_POST['bathrooms'] : null,
            'sqft'           => $_POST['sqft']      !== '' ? (int)   $_POST['sqft']      : null,
            'lot_sqft'       => $_POST['lot_sqft']  !== '' ? (int)   $_POST['lot_sqft']  : null,
            'year_built'     => $_POST['year_built']!== '' ? (int)   $_POST['year_built']: null,
            'garage_spaces'  => $_POST['garage_spaces'] !== '' ? (int) $_POST['garage_spaces'] : null,
            'pool'           => isset( $_POST['pool'] ) ? 1 : 0,
            'hoa_fee'        => (float) ( $_POST['hoa_fee']        ?? 0 ),
            'property_taxes' => $_POST['property_taxes'] !== '' ? (float) $_POST['property_taxes'] : null,
            'flood_zone'     => sanitize_text_field( wp_unslash( $_POST['flood_zone']  ?? '' ) ) ?: null,
            'zoning'         => sanitize_text_field( wp_unslash( $_POST['zoning']      ?? '' ) ) ?: null,
            'description'    => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
            'virtual_tour'   => esc_url_raw( wp_unslash( $_POST['virtual_tour'] ?? '' ) ) ?: null,
            'days_on_market' => (int) ( $_POST['days_on_market'] ?? 0 ),
            'agent_id'       => $_POST['agent_id'] !== '' ? (int) $_POST['agent_id'] : null,
            // Commercial fields
            'cap_rate'       => $_POST['cap_rate']   !== '' ? (float) $_POST['cap_rate']   : null,
            'noi'            => $_POST['noi']         !== '' ? (float) $_POST['noi']         : null,
            'num_units'      => $_POST['num_units']   !== '' ? (int)   $_POST['num_units']   : null,
        ];
        // Remove nulls so we don't overwrite existing DB values with NULL on partial edit
        $data = array_filter( $data, fn( $v ) => $v !== null );
        if ( $id ) {
            global $wpdb;
            $wpdb->update( PWL_DB::listings_table(), $data, [ 'id' => $id ] );
        } else {
            if ( empty( $data['mls_id'] ) ) $data['mls_id'] = 'MANUAL-' . uniqid();
            $wpdb->insert( PWL_DB::listings_table(), $data );
            $id = $wpdb->insert_id;
        }
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwl-listing-edit', 'id' => $id, 'msg' => 'saved' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function delete_listing(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );
        check_admin_referer( 'pwl_delete_listing' );
        $id = (int) ( $_GET['id'] ?? 0 );
        if ( $id ) {
            global $wpdb;
            $wpdb->delete( PWL_DB::listings_table(), [ 'id' => $id ] );
            $wpdb->delete( PWL_DB::saved_table(),    [ 'listing_id' => $id ] );
        }
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwl-listings', 'msg' => 'deleted' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function flush_scores(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'No permission.' );
        check_admin_referer( 'pwl_flush_scores' );
        global $wpdb;
        $wpdb->query( 'TRUNCATE TABLE ' . PWL_DB::scores_table() );
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwl-settings', 'msg' => 'scores_flushed' ], admin_url( 'admin.php' ) ) );
        exit;
    }
}
