<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWL_Alerts — saved-search matching and email notifications.
 *
 * Runs on WP-Cron. For each saved search, finds listings newer than the last
 * notification (id > last_max_id) that still match the saved criteria, and
 * emails the user a digest. Only NEW listings are ever included.
 */
class PWL_Alerts {

    public static function init(): void {
        add_filter( 'cron_schedules', [ __CLASS__, 'add_intervals' ] );
        add_action( 'pwl_run_alerts_daily',   [ __CLASS__, 'run_daily'   ] );
        add_action( 'pwl_run_alerts_weekly',  [ __CLASS__, 'run_weekly'  ] );
        add_action( 'pwl_run_alerts_instant', [ __CLASS__, 'run_instant' ] );
        // Schedule on `init`, never before it (WordPress requirement: cron events
        // must not be scheduled before the init action — scheduling can run the
        // cron_schedules filter and other code that may load translations).
        add_action( 'init', [ __CLASS__, 'ensure_scheduled' ] );
    }

    public static function add_intervals( array $schedules ): array {
        // NOTE: cron schedule display labels are intentionally NOT translated.
        // This filter can run before the `init` action (e.g. via wp_schedule_event),
        // and translating here triggers WP 6.7's "textdomain loaded too early" notice.
        if ( ! isset( $schedules['weekly'] ) ) {
            $schedules['weekly'] = [ 'interval' => WEEK_IN_SECONDS, 'display' => 'Once Weekly' ];
        }
        if ( ! isset( $schedules['every_15_min'] ) ) {
            $schedules['every_15_min'] = [ 'interval' => 15 * MINUTE_IN_SECONDS, 'display' => 'Every 15 Minutes' ];
        }
        return $schedules;
    }

    public static function ensure_scheduled(): void {
        if ( ! wp_next_scheduled( 'pwl_run_alerts_daily' ) ) {
            wp_schedule_event( strtotime( 'tomorrow 7am' ), 'daily', 'pwl_run_alerts_daily' );
        }
        if ( ! wp_next_scheduled( 'pwl_run_alerts_weekly' ) ) {
            wp_schedule_event( strtotime( 'next monday 7am' ), 'weekly', 'pwl_run_alerts_weekly' );
        }
        if ( ! wp_next_scheduled( 'pwl_run_alerts_instant' ) ) {
            wp_schedule_event( time() + 900, 'every_15_min', 'pwl_run_alerts_instant' );
        }
    }

    public static function clear_scheduled(): void {
        wp_clear_scheduled_hook( 'pwl_run_alerts_daily' );
        wp_clear_scheduled_hook( 'pwl_run_alerts_weekly' );
        wp_clear_scheduled_hook( 'pwl_run_alerts_instant' );
    }

    public static function run_daily(): void   { self::process( 'daily' ); }
    public static function run_weekly(): void  { self::process( 'weekly' ); }
    public static function run_instant(): void { self::process( 'instant' ); }

    /**
     * Process all saved searches of a given frequency.
     */
    public static function process( string $frequency ): void {
        $searches = PWL_DB::get_searches_by_frequency( $frequency );
        foreach ( $searches as $search ) {
            self::process_one( $search );
        }
    }

    public static function process_one( object $search ): int {
        $criteria = json_decode( $search->criteria_json ?? '{}', true ) ?: [];
        // Only NEW listings: id greater than the last one we notified about
        $criteria['min_id']   = (int) $search->last_max_id;
        $criteria['status']   = $criteria['status'] ?? 'active';
        $criteria['per_page'] = 50;
        $criteria['order_by'] = 'created_at';
        $criteria['order']    = 'DESC';

        $result   = PWL_DB::search( $criteria );
        $listings = $result['listings'];
        if ( empty( $listings ) ) return 0;

        // Highest id in this batch becomes the new watermark
        $new_max = (int) $search->last_max_id;
        foreach ( $listings as $l ) {
            $new_max = max( $new_max, (int) $l->id );
        }

        $user = get_userdata( (int) $search->user_id );
        if ( $user && $user->user_email ) {
            self::send_email( $user, $search, $listings );
        }
        PWL_DB::update_search_notified( (int) $search->id, $new_max );
        return count( $listings );
    }

    private static function send_email( \WP_User $user, object $search, array $listings ): void {
        $site   = get_bloginfo( 'name' );
        $count  = count( $listings );
        $subject = sprintf(
            /* translators: 1: count, 2: search label */
            _n( '%1$d new home matches "%2$s"', '%1$d new homes match "%2$s"', $count, 'realwise' ),
            $count, $search->label
        );

        $rows = '';
        foreach ( $listings as $l ) {
            $url   = PWL_Listing::listing_url( $l->id );
            $photo = PWL_Listing::first_photo( $l );
            $price = PWL_Listing::format_price( $l->list_price );
            $meta  = PWL_Listing::beds_baths_label( $l );
            $rows .= '<tr><td style="padding:12px;border-bottom:1px solid #eee;">'
                  . ( $photo ? '<img src="' . esc_url( $photo ) . '" alt="" width="120" style="border-radius:6px;vertical-align:top;margin-right:12px;">' : '' )
                  . '<div style="display:inline-block;vertical-align:top;">'
                  . '<a href="' . esc_url( $url ) . '" style="font-size:18px;font-weight:700;color:#1a6fd4;text-decoration:none;">' . esc_html( $price ) . '</a>'
                  . '<div style="font-size:14px;color:#333;">' . esc_html( $l->address . ', ' . $l->city . ', ' . $l->state ) . '</div>'
                  . '<div style="font-size:13px;color:#666;">' . esc_html( $meta ) . '</div>'
                  . '</div></td></tr>';
        }

        $manage_url = PWL_Listing::search_url();
        $body = '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;">'
              . '<h2 style="color:#1a6fd4;">' . esc_html( $subject ) . '</h2>'
              /* translators: %s and %d are dynamic values inserted at runtime. */
              . '<p style="color:#555;">' . sprintf( esc_html__( 'New listings matching your saved search on %s:', 'realwise' ), esc_html( $site ) ) . '</p>'
              . '<table style="width:100%;border-collapse:collapse;">' . $rows . '</table>'
              . '<p style="margin-top:20px;font-size:12px;color:#999;">'
              /* translators: %s and %d are dynamic values inserted at runtime. */
              . sprintf( esc_html__( 'You are receiving this because you saved the search "%s".', 'realwise' ), esc_html( $search->label ) )
              . ' <a href="' . esc_url( $manage_url ) . '">' . esc_html__( 'Manage your alerts', 'realwise' ) . '</a></p>'
              . '</div>';

        $html_type = fn() => 'text/html';
        add_filter( 'wp_mail_content_type', $html_type );
        wp_mail( $user->user_email, $subject, $body );
        remove_filter( 'wp_mail_content_type', $html_type );
    }
}
