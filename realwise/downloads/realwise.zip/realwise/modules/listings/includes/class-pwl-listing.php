<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWL_Listing — thin model wrapper with formatting helpers.
 */
class PWL_Listing {

    public static function format_price( $price ): string {
        $sym = get_option( 'pwl_currency_symbol', '$' );
        if ( $price >= 1_000_000 ) return $sym . number_format( $price / 1_000_000, 2 ) . 'M';
        if ( $price >= 1_000 )     return $sym . number_format( $price );
        return $sym . (string) $price;
    }

    public static function beds_baths_label( object $l ): string {
        $parts = [];
        if ( $l->bedrooms  ) $parts[] = $l->bedrooms  . ' bd';
        if ( $l->bathrooms ) $parts[] = $l->bathrooms . ' ba';
        if ( $l->sqft      ) $parts[] = number_format( $l->sqft ) . ' sqft';
        return implode( ' · ', $parts );
    }

    public static function status_label( string $status ): string {
        return match( $status ) {
            'active'   => 'Active',
            'pending'  => 'Under Contract',
            'closed'   => 'Sold',
            'delisted' => 'Off Market',
            default    => ucfirst( $status ),
        };
    }

    public static function status_class( string $status ): string {
        return match( $status ) {
            'active'  => 'pwl-badge--green',
            'pending' => 'pwl-badge--yellow',
            'closed'  => 'pwl-badge--gray',
            default   => 'pwl-badge--blue',
        };
    }

    public static function first_photo( object $l ): string {
        $photos = json_decode( $l->photos ?? '[]', true );
        return $photos[0]['MediaURL'] ?? $photos[0]['url'] ?? $photos[0] ?? '';
    }

    public static function listing_url( int $id ): string {
        $page = get_option( 'pwl_listing_page_id' );
        return $page ? add_query_arg( 'pwl_id', $id, get_permalink( $page ) ) : '#';
    }

    public static function search_url( array $params = [] ): string {
        $page = get_option( 'pwl_search_page_id' );
        return $page ? add_query_arg( $params, get_permalink( $page ) ) : '#';
    }
}
