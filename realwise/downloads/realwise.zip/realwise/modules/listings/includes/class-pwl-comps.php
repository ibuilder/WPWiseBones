<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWL_Comps — comparable-sales engine and ARV (After-Repair Value) suggestion.
 *
 * Strategy:
 *   1. Find nearby sold/closed listings of the same asset type with similar
 *      beds/baths/sqft from the local RealWise database (free, instant).
 *   2. If too few local comps and an ATTOM API key is configured, augment
 *      with ATTOM sale comps.
 *   3. Derive a suggested ARV from the comps' median price-per-sqft applied to
 *      the subject's square footage.
 */
class PWL_Comps {

    /**
     * @param object $subject  A listing row (from PWL_DB::get_listing()).
     * @param array  $opts {
     *     @type float $radius_miles   Search radius (default 2).
     *     @type float $sqft_pct       Allowed sqft variance, e.g. 0.25 = ±25%.
     *     @type int   $limit          Max comps to return.
     * }
     * @return array { comps: [], stats: {…}, suggested_arv: float, source: string }
     */
    public static function find( object $subject, array $opts = [] ): array {
        $opts = array_merge( [
            'radius_miles' => (float) get_option( 'pwl_comps_radius', 2 ),
            'sqft_pct'     => 0.25,
            'limit'        => 8,
        ], $opts );

        $comps  = self::local_comps( $subject, $opts );
        $source = 'local';

        if ( count( $comps ) < 3 && get_option( 'pwl_attom_api_key' ) ) {
            $attom = self::attom_comps( $subject, $opts );
            if ( $attom ) {
                $comps  = array_merge( $comps, $attom );
                $source = $comps && count( $comps ) > count( $attom ) ? 'mixed' : 'attom';
            }
        }

        $stats = self::stats( $comps );
        $arv   = self::suggest_arv( $subject, $stats );

        return [
            'subject'       => [
                'id'        => (int) $subject->id,
                'address'   => $subject->address,
                'sqft'      => (int) $subject->sqft,
                'beds'      => (int) $subject->bedrooms,
                'baths'     => (float) $subject->bathrooms,
                'list_price'=> (float) $subject->list_price,
            ],
            'comps'         => array_slice( $comps, 0, $opts['limit'] ),
            'stats'         => $stats,
            'suggested_arv' => $arv,
            'source'        => $source,
        ];
    }

    private static function local_comps( object $subject, array $opts ): array {
        global $wpdb;
        if ( ! $subject->latitude || ! $subject->longitude ) {
            // Fall back to same-ZIP matching when we have no coordinates
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT * FROM " . PWL_DB::listings_table() . "
                 WHERE zip_code = %s AND asset_type = %s AND id <> %d
                 AND status IN ('closed','active') AND sqft > 0
                 ORDER BY ABS(sqft - %d) ASC LIMIT 20",
                $subject->zip_code, $subject->asset_type, $subject->id, (int) $subject->sqft
            ) );
        } else {
            $sqft_min = (int) ( $subject->sqft * ( 1 - $opts['sqft_pct'] ) );
            $sqft_max = (int) ( $subject->sqft * ( 1 + $opts['sqft_pct'] ) );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT *, (3959 * acos(cos(radians(%f)) * cos(radians(latitude)) *
                    cos(radians(longitude) - radians(%f)) + sin(radians(%f)) * sin(radians(latitude)))) AS distance
                 FROM " . PWL_DB::listings_table() . "
                 WHERE id <> %d AND asset_type = %s AND latitude IS NOT NULL
                   AND status IN ('closed','active') AND sqft BETWEEN %d AND %d
                 HAVING distance <= %f
                 ORDER BY distance ASC, ABS(sqft - %d) ASC
                 LIMIT 20",
                $subject->latitude, $subject->longitude, $subject->latitude,
                $subject->id, $subject->asset_type,
                $sqft_min ?: 0, $sqft_max ?: 999999,
                $opts['radius_miles'], (int) $subject->sqft
            ) );
        }

        $comps = [];
        foreach ( (array) $rows as $r ) {
            $price = (float) $r->list_price;
            $sqft  = (int) $r->sqft;
            if ( $price <= 0 || $sqft <= 0 ) continue;
            $comps[] = [
                'id'          => (int) $r->id,
                'address'     => $r->address . ', ' . $r->city,
                'price'       => $price,
                'sqft'        => $sqft,
                'beds'        => (int) $r->bedrooms,
                'baths'       => (float) $r->bathrooms,
                'ppsf'        => round( $price / $sqft, 2 ),
                'status'      => $r->status,
                'distance'    => isset( $r->distance ) ? round( (float) $r->distance, 2 ) : null,
                'url'         => PWL_Listing::listing_url( $r->id ),
                'source'      => 'local',
            ];
        }
        return $comps;
    }

    private static function attom_comps( object $subject, array $opts ): array {
        $key = get_option( 'pwl_attom_api_key' );
        if ( ! $key || ! $subject->zip_code ) return [];

        $url = add_query_arg( [
            'postalcode' => $subject->zip_code,
            'propertytype' => 'SFR',
            'pagesize'   => 20,
            'orderby'    => 'saleamt',
        ], 'https://api.attomdata.com/propertyapi/v1.0.0/sale/snapshot' );

        $resp = wp_remote_get( $url, [
            'timeout' => 12,
            'headers' => [ 'apikey' => $key, 'Accept' => 'application/json' ],
        ] );
        if ( is_wp_error( $resp ) ) return [];
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );

        $comps = [];
        foreach ( (array) ( $data['property'] ?? [] ) as $p ) {
            $price = (float) ( $p['sale']['amount']['saleamt'] ?? 0 );
            $sqft  = (int)   ( $p['building']['size']['universalsize'] ?? 0 );
            if ( $price <= 0 || $sqft <= 0 ) continue;
            $comps[] = [
                'id'       => 0,
                'address'  => trim( ( $p['address']['line1'] ?? '' ) . ', ' . ( $p['address']['locality'] ?? '' ) ),
                'price'    => $price,
                'sqft'     => $sqft,
                'beds'     => (int)   ( $p['building']['rooms']['beds'] ?? 0 ),
                'baths'    => (float) ( $p['building']['rooms']['bathstotal'] ?? 0 ),
                'ppsf'     => round( $price / $sqft, 2 ),
                'status'   => 'sold',
                'distance' => null,
                'url'      => null,
                'source'   => 'attom',
            ];
        }
        return $comps;
    }

    private static function stats( array $comps ): array {
        if ( empty( $comps ) ) {
            return [ 'count' => 0, 'median_ppsf' => null, 'avg_ppsf' => null, 'low_ppsf' => null, 'high_ppsf' => null ];
        }
        $ppsf = array_column( $comps, 'ppsf' );
        sort( $ppsf );
        $n      = count( $ppsf );
        $median = $n % 2 ? $ppsf[ intdiv( $n, 2 ) ] : ( $ppsf[ $n / 2 - 1 ] + $ppsf[ $n / 2 ] ) / 2;
        return [
            'count'       => $n,
            'median_ppsf' => round( $median, 2 ),
            'avg_ppsf'    => round( array_sum( $ppsf ) / $n, 2 ),
            'low_ppsf'    => round( min( $ppsf ), 2 ),
            'high_ppsf'   => round( max( $ppsf ), 2 ),
        ];
    }

    private static function suggest_arv( object $subject, array $stats ): ?float {
        if ( empty( $stats['median_ppsf'] ) || ! $subject->sqft ) return null;
        // ARV = median price-per-sqft of comps × subject square footage
        return round( $stats['median_ppsf'] * (int) $subject->sqft, -2 );
    }
}
