<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWL_Mortgage — P&I math, amortization, affordability, and closing costs.
 */
class PWL_Mortgage {

    public static function monthly_payment( float $principal, float $annual_rate, int $years ): float {
        if ( $principal <= 0 ) return 0.0;
        if ( $annual_rate <= 0 ) return $principal / ( $years * 12 );
        $r = $annual_rate / 12;
        $n = $years * 12;
        return $principal * ( $r * pow( 1 + $r, $n ) ) / ( pow( 1 + $r, $n ) - 1 );
    }

    public static function amortization( float $principal, float $annual_rate, int $years ): array {
        $pmt      = self::monthly_payment( $principal, $annual_rate, $years );
        $r        = $annual_rate / 12;
        $balance  = $principal;
        $cum_int  = 0.0;
        $schedule = [];
        for ( $month = 1; $month <= $years * 12; $month++ ) {
            $interest    = $balance * $r;
            $principal_p = $pmt - $interest;
            $balance    -= $principal_p;
            $cum_int    += $interest;
            $schedule[]  = [
                'month'               => $month,
                'payment'             => round( $pmt, 2 ),
                'principal'           => round( $principal_p, 2 ),
                'interest'            => round( $interest, 2 ),
                'balance'             => round( max( $balance, 0 ), 2 ),
                'cumulative_interest' => round( $cum_int, 2 ),
            ];
        }
        return $schedule;
    }

    public static function summary( float $purchase_price, float $down_pct, float $annual_rate, int $years ): array {
        $down     = $purchase_price * $down_pct;
        $loan     = $purchase_price - $down;
        $monthly  = self::monthly_payment( $loan, $annual_rate, $years );
        $total_pd = $monthly * $years * 12;
        $pmi      = ( $down_pct < 0.20 ) ? round( $loan * 0.008 / 12, 2 ) : 0;
        return [
            'purchase_price'  => $purchase_price,
            'down_payment'    => round( $down, 2 ),
            'down_pct'        => round( $down_pct * 100, 1 ),
            'loan_amount'     => round( $loan, 2 ),
            'monthly_payment' => round( $monthly, 2 ),
            'monthly_pmi'     => $pmi,
            'monthly_total'   => round( $monthly + $pmi, 2 ),
            'total_paid'      => round( $total_pd, 2 ),
            'total_interest'  => round( $total_pd - $loan, 2 ),
            'interest_pct'    => $loan > 0 ? round( ( $total_pd - $loan ) / $loan * 100, 1 ) : 0,
            'annual_rate_pct' => round( $annual_rate * 100, 3 ),
            'years'           => $years,
        ];
    }

    public static function max_price( float $monthly_budget, float $annual_rate, int $years, float $down_pct = 0.20 ): float {
        if ( $annual_rate <= 0 ) {
            $loan = $monthly_budget * $years * 12;
        } else {
            $r    = $annual_rate / 12;
            $n    = $years * 12;
            $loan = $monthly_budget * ( pow( 1 + $r, $n ) - 1 ) / ( $r * pow( 1 + $r, $n ) );
        }
        return round( $loan / ( 1 - $down_pct ), 2 );
    }

    public static function closing_costs( float $purchase_price, string $state = '' ): array {
        $items = [
            'Loan Origination'  => round( $purchase_price * (float) get_option( 'pwl_cc_origination_pct',  1.0 ) / 100, 2 ),
            'Title Insurance'   => round( $purchase_price * (float) get_option( 'pwl_cc_title_pct',        0.5 ) / 100, 2 ),
            'Transfer Tax'      => round( $purchase_price * (float) get_option( 'pwl_cc_transfer_tax_pct', 0.2 ) / 100, 2 ),
            'Escrow / Prepaid'  => round( $purchase_price * (float) get_option( 'pwl_cc_prepaid_pct',      1.5 ) / 100, 2 ),
            'Appraisal'         => (float) get_option( 'pwl_cc_appraisal',  550 ),
            'Home Inspection'   => (float) get_option( 'pwl_cc_inspection', 450 ),
            'Attorney Fees'     => (float) get_option( 'pwl_cc_attorney',   750 ),
            'Recording Fees'    => (float) get_option( 'pwl_cc_recording',  200 ),
            'Home Warranty'     => (float) get_option( 'pwl_cc_warranty',   600 ),
            'Miscellaneous'     => (float) get_option( 'pwl_cc_misc',       350 ),
        ];
        $items['Total Closing Costs'] = array_sum( $items );
        return $items;
    }

    public static function current_rate(): float {
        $cached = get_transient( 'pwl_mortgage_rate' );
        if ( $cached !== false ) return (float) $cached;
        $fred_key = get_option( 'pwl_fred_api_key', '' );
        if ( ! $fred_key ) return (float) get_option( 'pwl_default_rate', 7.0 ) / 100;
        $url = add_query_arg( [
            'series_id'  => 'MORTGAGE30US',
            'api_key'    => $fred_key,
            'sort_order' => 'desc',
            'limit'      => 1,
            'file_type'  => 'json',
        ], 'https://api.stlouisfed.org/fred/series/observations' );
        $response = wp_remote_get( $url, [ 'timeout' => 8 ] );
        if ( is_wp_error( $response ) ) return (float) get_option( 'pwl_default_rate', 7.0 ) / 100;
        $data = json_decode( wp_remote_retrieve_body( $response ), true );
        $rate = (float) ( $data['observations'][0]['value'] ?? get_option( 'pwl_default_rate', 7.0 ) ) / 100;
        set_transient( 'pwl_mortgage_rate', $rate, 6 * HOUR_IN_SECONDS );
        return $rate;
    }
}
