<?php if ( ! defined( 'ABSPATH' ) ) exit;
$freq_labels = [
    'instant' => __( 'As they hit the market', 'realwise' ),
    'daily'   => __( 'Daily digest',           'realwise' ),
    'weekly'  => __( 'Weekly digest',          'realwise' ),
];
?>
<div class="pwl-saved-searches" id="pwl-saved-searches">
    <h2><?php esc_html_e( 'My Saved Searches & Alerts', 'realwise' ); ?></h2>

    <?php if ( empty( $searches ) ) : ?>
        <p class="pwl-notice">
            <?php esc_html_e( 'You have no saved searches yet. Run a search and click', 'realwise' ); ?>
            <strong>&#128276; <?php esc_html_e( 'Save this search', 'realwise' ); ?></strong>
            <?php esc_html_e( 'to get email alerts when new matching homes hit the market.', 'realwise' ); ?>
        </p>
    <?php else : ?>
    <table class="pwl-table pwl-table--searches widefat">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Search', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Criteria', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Alerts', 'realwise' ); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $searches as $rw_row ) :
            $criteria = json_decode( $rw_row->criteria_json ?? '{}', true ) ?: [];
            $bits = [];
            if ( ! empty( $criteria['q'] ) )          $bits[] = '"' . esc_html( $criteria['q'] ) . '"';
            if ( ! empty( $criteria['asset_type'] ) && $criteria['asset_type'] !== 'all' ) $bits[] = esc_html( ucfirst( $criteria['asset_type'] ) );
            if ( ! empty( $criteria['min_price'] ) )  $bits[] = '≥ ' . esc_html( PWL_Listing::format_price( $criteria['min_price'] ) );
            if ( ! empty( $criteria['max_price'] ) )  $bits[] = '≤ ' . esc_html( PWL_Listing::format_price( $criteria['max_price'] ) );
            if ( ! empty( $criteria['min_beds'] ) )   $bits[] = esc_html( $criteria['min_beds'] ) . '+ bd';
            if ( ! empty( $criteria['min_baths'] ) )  $bits[] = esc_html( $criteria['min_baths'] ) . '+ ba';
            if ( ! empty( $criteria['city'] ) )       $bits[] = esc_html( $criteria['city'] );
            if ( ! empty( $criteria['zip'] ) )        $bits[] = esc_html( $criteria['zip'] );
            $search_link = PWL_Listing::search_url( $criteria );
        ?>
        <tr data-id="<?php echo (int) $rw_row->id; ?>">
            <td>
                <a href="<?php echo esc_url( $search_link ); ?>" class="pwl-saved-search__label"><?php echo esc_html( $rw_row->label ); ?></a>
                <?php if ( $rw_row->last_notified ) : ?>
                <div class="pwl-saved-search__last"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'Last alert: %s', 'realwise' ), esc_html( date_i18n( 'M j, Y', strtotime( $rw_row->last_notified ) ) ) ); ?></div>
                <?php endif; ?>
            </td>
            <td><?php echo $bits ? implode( ' · ', $bits ) : esc_html__( 'Any', 'realwise' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></td>
            <td><?php echo esc_html( $freq_labels[ $rw_row->frequency ] ?? $rw_row->frequency ); ?></td>
            <td>
                <a href="<?php echo esc_url( $search_link ); ?>" class="pwl-btn pwl-btn--sm"><?php esc_html_e( 'View', 'realwise' ); ?></a>
                <button class="pwl-delete-search pwl-btn pwl-btn--sm pwl-btn--danger" data-id="<?php echo (int) $rw_row->id; ?>">&times;</button>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
