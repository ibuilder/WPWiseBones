<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwl-saved">
    <h2><?php esc_html_e( 'Saved Properties', 'realwise' ); ?></h2>
    <?php if ( empty( $saved ) ) : ?>
        <p class="pwl-notice"><?php esc_html_e( 'You have no saved properties yet. Browse listings and click ♡ to save.', 'realwise' ); ?></p>
    <?php else : ?>
    <table class="pwl-table pwl-table--saved widefat">
        <thead>
            <tr>
                <th><?php esc_html_e( 'Property', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Price', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Beds/Baths', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Status', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Notes', 'realwise' ); ?></th>
                <th></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $saved as $item ) : ?>
        <tr class="pwl-saved__row" data-id="<?php echo (int) $item->listing_id; ?>">
            <td>
                <a href="<?php echo esc_url( PWL_Listing::listing_url( $item->listing_id ) ); ?>">
                    <?php echo esc_html( $item->address . ', ' . $item->city ); ?>
                </a>
            </td>
            <td><?php echo esc_html( PWL_Listing::format_price( $item->list_price ) ); ?></td>
            <td><?php echo esc_html( ( $item->bedrooms ?? '—' ) . ' bd / ' . ( $item->bathrooms ?? '—' ) . ' ba' ); ?></td>
            <td><span class="pwl-badge <?php echo esc_attr( PWL_Listing::status_class( $item->status ) ); ?>"><?php echo esc_html( PWL_Listing::status_label( $item->status ) ); ?></span></td>
            <td><?php echo esc_html( $item->notes ?? '' ); ?></td>
            <td><button class="pwl-unsave-btn pwl-btn pwl-btn--sm pwl-btn--danger" data-id="<?php echo (int) $item->listing_id; ?>" title="Remove">&times;</button></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
