<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwl-admin">
    <h1>RealWise Listings — Settings</h1>
    <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'scores_flushed' ) : ?>
    <div class="notice notice-success"><p>Score cache cleared. Scores will be re-fetched on next listing view.</p></div>
    <?php endif; ?>
    <?php settings_errors(); ?>

    <form method="post" action="options.php">
        <?php settings_fields( 'pwl_settings_group' ); ?>

        <h2>API Keys</h2>
        <table class="form-table">
            <?php
            $api_keys = [ 'pwl_walkscore_key', 'pwl_crime_api_key', 'pwl_greatschools_key', 'pwl_google_maps_key', 'pwl_fred_api_key', 'pwl_attom_api_key' ];
            foreach ( $api_keys as $key ) :
                $stored = get_option( $key, '' );
            ?>
            <tr>
                <th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $fields[ $key ] ); ?></label></th>
                <td>
                    <input type="password" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>"
                           value="<?php echo esc_attr( $stored ); ?>" class="regular-text" autocomplete="new-password">
                    <?php if ( $stored ) : ?>
                    <p class="description">Key set (ends …<?php echo esc_html( substr( $stored, -4 ) ); ?>). Overwrite to change.</p>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>

        <h2>Mortgage Defaults</h2>
        <table class="form-table">
            <tr>
                <th><label for="pwl_default_rate">Default Interest Rate (%)</label></th>
                <td><input type="number" id="pwl_default_rate" name="pwl_default_rate" step="0.125" min="1" max="20"
                           value="<?php echo esc_attr( get_option( 'pwl_default_rate', '7.0' ) ); ?>" class="small-text">
                    <p class="description">Used when FRED API key is not set or unavailable.</p></td>
            </tr>
            <tr>
                <th><label for="pwl_currency_symbol">Currency Symbol</label></th>
                <td><input type="text" id="pwl_currency_symbol" name="pwl_currency_symbol"
                           value="<?php echo esc_attr( get_option( 'pwl_currency_symbol', '$' ) ); ?>" class="small-text"></td>
            </tr>
        </table>

        <h2>Closing Costs</h2>
        <table class="form-table">
            <?php
            $cc = [ 'pwl_cc_origination_pct' => 'Origination (%)', 'pwl_cc_title_pct' => 'Title Insurance (%)',
                    'pwl_cc_transfer_tax_pct' => 'Transfer Tax (%)', 'pwl_cc_prepaid_pct' => 'Prepaid/Escrow (%)' ];
            foreach ( $cc as $key => $label ) : ?>
            <tr>
                <th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
                <td><input type="number" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>"
                           step="0.01" min="0" max="10" value="<?php echo esc_attr( get_option( $key ) ); ?>" class="small-text"></td>
            </tr>
            <?php endforeach;
            $flat = [ 'pwl_cc_appraisal' => 'Appraisal ($)', 'pwl_cc_inspection' => 'Inspection ($)',
                      'pwl_cc_attorney'  => 'Attorney ($)',  'pwl_cc_recording'  => 'Recording ($)',
                      'pwl_cc_warranty'  => 'Home Warranty ($)', 'pwl_cc_misc'   => 'Misc ($)' ];
            foreach ( $flat as $key => $label ) : ?>
            <tr>
                <th><label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th>
                <td><input type="number" id="<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $key ); ?>"
                           step="10" min="0" value="<?php echo esc_attr( get_option( $key ) ); ?>" class="small-text"></td>
            </tr>
            <?php endforeach; ?>
        </table>

        <h2>Page IDs</h2>
        <table class="form-table">
            <tr>
                <th><label for="pwl_listing_page_id">Listing Detail Page ID</label></th>
                <td><input type="number" id="pwl_listing_page_id" name="pwl_listing_page_id"
                           value="<?php echo esc_attr( get_option( 'pwl_listing_page_id' ) ); ?>" class="small-text">
                    <p class="description">The page where <code>[pwl_listing]</code> is placed.</p></td>
            </tr>
            <tr>
                <th><label for="pwl_search_page_id">Search Page ID</label></th>
                <td><input type="number" id="pwl_search_page_id" name="pwl_search_page_id"
                           value="<?php echo esc_attr( get_option( 'pwl_search_page_id' ) ); ?>" class="small-text">
                    <p class="description">The page where <code>[pwl_search]</code> is placed.</p></td>
            </tr>
            <tr>
                <th><label for="pwl_score_cache_hours">Score Cache (hours)</label></th>
                <td><input type="number" id="pwl_score_cache_hours" name="pwl_score_cache_hours"
                           value="<?php echo esc_attr( get_option( 'pwl_score_cache_hours', 72 ) ); ?>" class="small-text" min="1" max="720"></td>
            </tr>
            <tr>
                <th><label for="pwl_comps_radius">Comps Search Radius (miles)</label></th>
                <td><input type="number" id="pwl_comps_radius" name="pwl_comps_radius"
                           value="<?php echo esc_attr( get_option( 'pwl_comps_radius', 2 ) ); ?>" class="small-text" min="0.5" max="25" step="0.5">
                    <p class="description">Used by the Developer plugin's comps / ARV engine. ATTOM key above enables external comps fallback.</p></td>
            </tr>
        </table>

        <?php submit_button(); ?>
    </form>

    <hr>
    <h2>Maintenance</h2>
    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="pwl_flush_scores">
        <?php wp_nonce_field( 'pwl_flush_scores' ); ?>
        <p><input type="submit" class="button button-secondary" value="Flush Score Cache"></p>
        <p class="description">Clears all cached Walk Score, crime, and school data. Scores will be re-fetched on next view (API calls will be made).</p>
    </form>
</div>
