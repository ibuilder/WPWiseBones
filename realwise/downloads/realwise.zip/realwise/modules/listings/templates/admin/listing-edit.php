<?php if ( ! defined( 'ABSPATH' ) ) exit;
$is_new = ! $listing;
$l      = $listing; // shorthand — safe nullsafe access via ?->
?>
<div class="wrap pwl-admin">
    <h1>
        <?php echo $is_new ? esc_html__( 'Add Listing', 'realwise' ) : esc_html__( 'Edit Listing', 'realwise' ); ?>
        <?php if ( ! $is_new ) : ?>
        <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwl-listing-edit' ], admin_url( 'admin.php' ) ) ); ?>"
           class="page-title-action"><?php esc_html_e( '+ Add New', 'realwise' ); ?></a>
        <?php endif; ?>
    </h1>

    <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'saved' ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Listing saved.', 'realwise' ); ?></p></div>
    <?php endif; ?>

    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action"     value="pwl_save_listing">
        <input type="hidden" name="listing_id" value="<?php echo (int) $l?->id; ?>">
        <?php wp_nonce_field( 'pwl_save_listing' ); ?>

        <div class="pwl-edit-grid">

            <!-- Core -->
            <div class="pwl-edit-card">
                <h2 class="pwl-edit-card__title"><?php esc_html_e( 'Core Details', 'realwise' ); ?></h2>
                <table class="form-table">
                    <tr><th><label for="pwl-mls-id"><?php esc_html_e( 'MLS #', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-mls-id" name="mls_id" value="<?php echo esc_attr( $l?->mls_id ?? '' ); ?>" class="regular-text">
                            <p class="description"><?php esc_html_e( 'Leave blank to auto-generate for manual entries.', 'realwise' ); ?></p></td></tr>
                    <tr><th><label for="pwl-asset-type"><?php esc_html_e( 'Asset Type', 'realwise' ); ?></label></th>
                        <td><select id="pwl-asset-type" name="asset_type" class="regular-text">
                            <?php foreach ( $asset_types as $t ) : ?>
                            <option value="<?php echo esc_attr( $t ); ?>" <?php selected( $l?->asset_type ?? 'residential', $t ); ?>><?php echo esc_html( ucfirst( $t ) ); ?></option>
                            <?php endforeach; ?>
                        </select></td></tr>
                    <tr><th><label for="pwl-status"><?php esc_html_e( 'Status', 'realwise' ); ?></label></th>
                        <td><select id="pwl-status" name="status" class="regular-text">
                            <?php foreach ( $statuses as $rw_row ) : ?>
                            <option value="<?php echo esc_attr( $rw_row ); ?>" <?php selected( $l?->status ?? 'active', $rw_row ); ?>><?php echo esc_html( ucfirst( $rw_row ) ); ?></option>
                            <?php endforeach; ?>
                        </select></td></tr>
                    <tr><th><label for="pwl-price"><?php esc_html_e( 'List Price ($)', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-price" name="list_price" value="<?php echo esc_attr( $l?->list_price ?? '' ); ?>" class="regular-text" step="1000" min="0"></td></tr>
                    <tr><th><label for="pwl-dom"><?php esc_html_e( 'Days on Market', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-dom" name="days_on_market" value="<?php echo esc_attr( $l?->days_on_market ?? 0 ); ?>" class="small-text" min="0"></td></tr>
                </table>
            </div>

            <!-- Address -->
            <div class="pwl-edit-card">
                <h2 class="pwl-edit-card__title"><?php esc_html_e( 'Location', 'realwise' ); ?></h2>
                <table class="form-table">
                    <tr><th><label for="pwl-address"><?php esc_html_e( 'Street Address', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-address" name="address" value="<?php echo esc_attr( $l?->address ?? '' ); ?>" class="regular-text" required></td></tr>
                    <tr><th><label for="pwl-city"><?php esc_html_e( 'City', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-city" name="city" value="<?php echo esc_attr( $l?->city ?? '' ); ?>" class="regular-text"></td></tr>
                    <tr><th><label for="pwl-state"><?php esc_html_e( 'State', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-state" name="state" value="<?php echo esc_attr( $l?->state ?? '' ); ?>" class="small-text" maxlength="4" placeholder="TX"></td></tr>
                    <tr><th><label for="pwl-zip"><?php esc_html_e( 'ZIP', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-zip" name="zip_code" value="<?php echo esc_attr( $l?->zip_code ?? '' ); ?>" class="small-text"></td></tr>
                    <tr><th><label for="pwl-county"><?php esc_html_e( 'County', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-county" name="county" value="<?php echo esc_attr( $l?->county ?? '' ); ?>" class="regular-text"></td></tr>
                    <tr><th><label><?php esc_html_e( 'Lat / Lon', 'realwise' ); ?></label></th>
                        <td>
                            <input type="number" name="latitude"  value="<?php echo esc_attr( $l?->latitude  ?? '' ); ?>" placeholder="Latitude"  step="any" style="width:140px">
                            <input type="number" name="longitude" value="<?php echo esc_attr( $l?->longitude ?? '' ); ?>" placeholder="Longitude" step="any" style="width:140px">
                            <p class="description"><?php esc_html_e( 'Used for map pin and nearby listings. Leave blank to auto-geocode (requires Google Maps key).', 'realwise' ); ?></p>
                        </td></tr>
                </table>
            </div>

            <!-- Property Details -->
            <div class="pwl-edit-card">
                <h2 class="pwl-edit-card__title"><?php esc_html_e( 'Property Details', 'realwise' ); ?></h2>
                <table class="form-table">
                    <tr><th><label><?php esc_html_e( 'Beds / Baths', 'realwise' ); ?></label></th>
                        <td>
                            <input type="number" name="bedrooms"  value="<?php echo esc_attr( $l?->bedrooms  ?? '' ); ?>" placeholder="Beds"  min="0" step="1"   style="width:80px">
                            <input type="number" name="bathrooms" value="<?php echo esc_attr( $l?->bathrooms ?? '' ); ?>" placeholder="Baths" min="0" step="0.5" style="width:80px">
                        </td></tr>
                    <tr><th><label for="pwl-sqft"><?php esc_html_e( 'Living Sqft', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-sqft" name="sqft" value="<?php echo esc_attr( $l?->sqft ?? '' ); ?>" class="small-text" min="0"></td></tr>
                    <tr><th><label for="pwl-lot"><?php esc_html_e( 'Lot Sqft', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-lot" name="lot_sqft" value="<?php echo esc_attr( $l?->lot_sqft ?? '' ); ?>" class="small-text" min="0"></td></tr>
                    <tr><th><label for="pwl-year"><?php esc_html_e( 'Year Built', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-year" name="year_built" value="<?php echo esc_attr( $l?->year_built ?? '' ); ?>" class="small-text" min="1800" max="<?php echo (int) gmdate('Y') + 5; ?>"></td></tr>
                    <tr><th><label for="pwl-garage"><?php esc_html_e( 'Garage Spaces', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-garage" name="garage_spaces" value="<?php echo esc_attr( $l?->garage_spaces ?? '' ); ?>" class="small-text" min="0"></td></tr>
                    <tr><th><?php esc_html_e( 'Pool', 'realwise' ); ?></th>
                        <td><label><input type="checkbox" name="pool" value="1" <?php checked( $l?->pool ?? 0, 1 ); ?>> <?php esc_html_e( 'Has pool', 'realwise' ); ?></label></td></tr>
                    <tr><th><label for="pwl-hoa"><?php esc_html_e( 'HOA Fee/mo ($)', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-hoa" name="hoa_fee" value="<?php echo esc_attr( $l?->hoa_fee ?? 0 ); ?>" class="small-text" min="0" step="1"></td></tr>
                    <tr><th><label for="pwl-taxes"><?php esc_html_e( 'Annual Taxes ($)', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-taxes" name="property_taxes" value="<?php echo esc_attr( $l?->property_taxes ?? '' ); ?>" class="small-text" min="0" step="1"></td></tr>
                    <tr><th><label for="pwl-flood"><?php esc_html_e( 'Flood Zone', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-flood" name="flood_zone" value="<?php echo esc_attr( $l?->flood_zone ?? '' ); ?>" class="small-text" placeholder="e.g. AE"></td></tr>
                    <tr><th><label for="pwl-zoning"><?php esc_html_e( 'Zoning', 'realwise' ); ?></label></th>
                        <td><input type="text" id="pwl-zoning" name="zoning" value="<?php echo esc_attr( $l?->zoning ?? '' ); ?>" class="regular-text"></td></tr>
                </table>
            </div>

            <!-- Commercial fields -->
            <div class="pwl-edit-card">
                <h2 class="pwl-edit-card__title"><?php esc_html_e( 'Investment / Commercial', 'realwise' ); ?></h2>
                <table class="form-table">
                    <tr><th><label for="pwl-cap"><?php esc_html_e( 'Cap Rate (%)', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-cap" name="cap_rate" value="<?php echo esc_attr( $l?->cap_rate ?? '' ); ?>" class="small-text" step="0.01" min="0"></td></tr>
                    <tr><th><label for="pwl-noi"><?php esc_html_e( 'NOI ($/yr)', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-noi" name="noi" value="<?php echo esc_attr( $l?->noi ?? '' ); ?>" class="small-text" step="1" min="0"></td></tr>
                    <tr><th><label for="pwl-units"><?php esc_html_e( 'Number of Units', 'realwise' ); ?></label></th>
                        <td><input type="number" id="pwl-units" name="num_units" value="<?php echo esc_attr( $l?->num_units ?? '' ); ?>" class="small-text" min="1"></td></tr>
                </table>
            </div>

            <!-- Media & Agent -->
            <div class="pwl-edit-card pwl-edit-card--wide">
                <h2 class="pwl-edit-card__title"><?php esc_html_e( 'Description, Media & Agent', 'realwise' ); ?></h2>
                <table class="form-table">
                    <tr><th><label for="pwl-desc"><?php esc_html_e( 'Description', 'realwise' ); ?></label></th>
                        <td><textarea id="pwl-desc" name="description" rows="6" class="large-text"><?php echo esc_textarea( $l?->description ?? '' ); ?></textarea></td></tr>
                    <tr><th><label for="pwl-tour"><?php esc_html_e( 'Virtual Tour URL', 'realwise' ); ?></label></th>
                        <td><input type="url" id="pwl-tour" name="virtual_tour" value="<?php echo esc_attr( $l?->virtual_tour ?? '' ); ?>" class="regular-text"></td></tr>
                    <tr><th><label for="pwl-agent-sel"><?php esc_html_e( 'Agent', 'realwise' ); ?></label></th>
                        <td>
                            <select id="pwl-agent-sel" name="agent_id" class="regular-text">
                                <option value=""><?php esc_html_e( '— No agent —', 'realwise' ); ?></option>
                                <?php foreach ( $agents as $a ) : ?>
                                <option value="<?php echo (int) $a->id; ?>" <?php selected( $l?->agent_id ?? '', $a->id ); ?>><?php echo esc_html( $a->name ); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwl-agents' ], admin_url( 'admin.php' ) ) ); ?>" class="button"><?php esc_html_e( 'Manage Agents', 'realwise' ); ?></a>
                        </td></tr>
                </table>
            </div>
        </div><!-- .pwl-edit-grid -->

        <p class="submit">
            <input type="submit" class="button button-primary button-large" value="<?php echo $is_new ? esc_attr__( 'Add Listing', 'realwise' ) : esc_attr__( 'Update Listing', 'realwise' ); ?>">
            <a href="<?php echo esc_url( add_query_arg( 'page', 'pwl-listings', admin_url( 'admin.php' ) ) ); ?>" class="button button-large"><?php esc_html_e( 'Cancel', 'realwise' ); ?></a>
            <?php if ( ! $is_new ) : ?>
            <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'page' => 'pwl-listing-edit', 'action' => 'pwl_delete_listing', 'id' => $l->id ], admin_url( 'admin-post.php' ) ), 'pwl_delete_listing' ) ); ?>"
               class="button pwl-btn-delete" onclick="return confirm('<?php esc_attr_e( 'Permanently delete this listing?', 'realwise' ); ?>')"
               style="float:right;color:#b32d2e;border-color:#b32d2e"><?php esc_html_e( 'Delete Listing', 'realwise' ); ?></a>
            <?php endif; ?>
        </p>
    </form>
</div>

<style>
.pwl-edit-grid { display:grid; grid-template-columns:1fr 1fr; gap:20px; margin-bottom:20px; }
.pwl-edit-card { background:#fff; border:1px solid #c3c4c7; border-radius:4px; padding:16px 20px; }
.pwl-edit-card--wide { grid-column: 1 / -1; }
.pwl-edit-card__title { font-size:14px; font-weight:600; margin:0 0 12px; padding-bottom:8px; border-bottom:1px solid #f0f0f1; }
@media(max-width:900px){ .pwl-edit-grid{ grid-template-columns:1fr; } }
</style>
