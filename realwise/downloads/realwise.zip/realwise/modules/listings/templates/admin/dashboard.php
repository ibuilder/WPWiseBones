<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwl-admin">
    <h1>RealWise Listings — Dashboard</h1>

    <script>
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.pwl-help-toggle');
        if (!btn) return;
        btn.setAttribute('aria-expanded', btn.getAttribute('aria-expanded') === 'true' ? 'false' : 'true');
    });
    </script>
    <div class="pwl-help-panel">
        <button type="button" class="pwl-help-toggle" aria-expanded="true">
            <span class="dashicons dashicons-lightbulb"></span> Getting Started &amp; Tips
            <span class="pwl-help-chevron">▾</span>
        </button>
        <div class="pwl-help-body">
            <div class="pwl-help-cols">
                <div class="pwl-help-col">
                    <h3>What this plugin does</h3>
                    <p>RealWise Listings is the foundation of the suite. It stores your property database and powers searchable listings with Walk Score, crime grades, school ratings, an interactive map, and a built-in mortgage calculator.</p>
                    <h3>Quick start</h3>
                    <ol>
                        <li>Open <strong>Settings</strong> and add your API keys (Walk Score, CrimeGrade, GreatSchools, Google Maps, FRED).</li>
                        <li>Create two pages: one with <code>[pwl_search]</code>, one with <code>[pwl_listing]</code>.</li>
                        <li>Back in <strong>Settings</strong>, set the <em>Search Page ID</em> and <em>Listing Detail Page ID</em> so links resolve correctly.</li>
                        <li>Add listings via <strong>Add Listing</strong>, or auto-import them with <strong>RealWise MLS Connect</strong>.</li>
                        <li>Drop the sidebar widgets (Featured, Mortgage, Search) under <strong>Appearance → Widgets</strong>.</li>
                    </ol>
                </div>
                <div class="pwl-help-col">
                    <h3>Tips</h3>
                    <ul class="pwl-help-tips">
                        <li><strong>Scores are cached</strong> for the hours set in Settings (default 72). Use <em>Flush Score Cache</em> to force a refresh — note this triggers new API calls.</li>
                        <li><strong>No FRED key?</strong> The mortgage calculator falls back to your <em>Default Interest Rate</em> setting.</li>
                        <li><strong>Latitude/longitude</strong> are required for a listing to appear on the map and in "nearby" results.</li>
                        <li>The amortization table renders with <code>[pwl_mortgage show_table="true"]</code>.</li>
                        <li><strong>SEO:</strong> listing detail pages automatically output Open Graph, Twitter Card, and canonical tags.</li>
                        <li>Closing-cost line items and percentages are fully editable in <strong>Settings</strong>.</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="pwl-admin-stats">
        <div class="pwl-stat-card"><span class="pwl-stat-card__num"><?php echo number_format( $stats['total'] ); ?></span><span class="pwl-stat-card__label">Total Listings</span></div>
        <div class="pwl-stat-card"><span class="pwl-stat-card__num"><?php echo number_format( $stats['active'] ); ?></span><span class="pwl-stat-card__label">Active</span></div>
        <div class="pwl-stat-card"><span class="pwl-stat-card__num"><?php echo number_format( $stats['agents'] ); ?></span><span class="pwl-stat-card__label">Agents</span></div>
        <div class="pwl-stat-card"><span class="pwl-stat-card__num"><?php echo number_format( $stats['saved'] ); ?></span><span class="pwl-stat-card__label">Saved by Users</span></div>
    </div>

    <h2>Recent Listings</h2>
    <table class="widefat striped pwl-admin-table">
        <thead><tr><th>Address</th><th>City</th><th>Type</th><th>Price</th><th>Status</th><th>Added</th></tr></thead>
        <tbody>
        <?php foreach ( $recent as $l ) : ?>
        <tr>
            <td><?php echo esc_html( $l->address ); ?></td>
            <td><?php echo esc_html( $l->city . ', ' . $l->state ); ?></td>
            <td><?php echo esc_html( ucfirst( $l->asset_type ) ); ?></td>
            <td><?php echo esc_html( PWL_Listing::format_price( $l->list_price ) ); ?></td>
            <td><span class="pwl-badge <?php echo esc_attr( PWL_Listing::status_class( $l->status ) ); ?>"><?php echo esc_html( PWL_Listing::status_label( $l->status ) ); ?></span></td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $l->created_at ) ) ); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <div class="pwl-admin-shortcodes">
        <h2>Shortcodes Quick Reference</h2>
        <table class="widefat">
            <thead><tr><th>Shortcode</th><th>Description</th><th>Attributes</th></tr></thead>
            <tbody>
                <tr><td><code>[pwl_search]</code></td><td>Full search page with filters, results grid, and map</td><td><code>show_map</code>, <code>show_filters</code>, <code>default_type</code>, <code>per_page</code></td></tr>
                <tr><td><code>[pwl_listing id="X"]</code></td><td>Single listing detail (or pass <code>?pwl_id=X</code> in URL)</td><td><code>id</code></td></tr>
                <tr><td><code>[pwl_mortgage]</code></td><td>Standalone mortgage calculator</td><td><code>price</code>, <code>down_pct</code>, <code>rate</code>, <code>years</code>, <code>show_table</code></td></tr>
                <tr><td><code>[pwl_saved]</code></td><td>Logged-in user's saved properties</td><td>—</td></tr>
                <tr><td><code>[pwl_featured limit="6" type="residential"]</code></td><td>Featured listings grid</td><td><code>type</code>, <code>limit</code>, <code>order_by</code>, <code>order</code></td></tr>
            </tbody>
        </table>
    </div>
</div>
