<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwl-admin">
    <h1><?php esc_html_e( 'All Listings', 'realwise' ); ?>
        <span class="pwl-count"><?php echo number_format( $total ); ?> total</span>
        <a href="<?php echo esc_url( add_query_arg( 'page', 'pwl-listing-edit', admin_url( 'admin.php' ) ) ); ?>"
           class="page-title-action"><?php esc_html_e( '+ Add Listing', 'realwise' ); ?></a>
    </h1>
    <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'deleted' ) : ?>
    <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Listing deleted.', 'realwise' ); ?></p></div>
    <?php endif; ?>
    <table class="widefat striped pwl-admin-table">
        <thead>
            <tr>
                <th><?php esc_html_e( 'MLS #', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Address', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Type', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Price', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Bed/Bath', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Sqft', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Walk', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Crime', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Schools', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Status', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Updated', 'realwise' ); ?></th>
                <th><?php esc_html_e( 'Actions', 'realwise' ); ?></th>
            </tr>
        </thead>
        <tbody>
        <?php foreach ( $listings as $l ) :
            $edit_url   = add_query_arg( [ 'page' => 'pwl-listing-edit', 'id' => $l->id ], admin_url( 'admin.php' ) );
            $delete_url = wp_nonce_url(
                add_query_arg( [ 'action' => 'pwl_delete_listing', 'id' => $l->id ], admin_url( 'admin-post.php' ) ),
                'pwl_delete_listing'
            );
        ?>
        <tr>
            <td><?php echo esc_html( $l->mls_id ); ?></td>
            <td>
                <a href="<?php echo esc_url( $edit_url ); ?>" style="font-weight:600"><?php echo esc_html( $l->address ); ?></a>
                <div style="color:#666;font-size:12px"><?php echo esc_html( $l->city . ', ' . $l->state ); ?></div>
            </td>
            <td><?php echo esc_html( ucfirst( $l->asset_type ) ); ?></td>
            <td><?php echo esc_html( PWL_Listing::format_price( $l->list_price ) ); ?></td>
            <td><?php echo esc_html( ( $l->bedrooms ?? '—' ) . ' / ' . ( $l->bathrooms ?? '—' ) ); ?></td>
            <td><?php echo $l->sqft ? number_format( $l->sqft ) : '—'; ?></td>
            <td><?php echo $l->walk_score  ? '<span title="Walk Score">' . (int) $l->walk_score . '</span>'  : '—'; ?></td>
            <td><?php echo $l->crime_grade ? '<span title="Crime Grade">' . esc_html( $l->crime_grade ) . '</span>' : '—'; ?></td>
            <td><?php echo $l->school_rating ? esc_html( number_format( $l->school_rating, 1 ) ) . '/10' : '—'; ?></td>
            <td><span class="pwl-badge <?php echo esc_attr( PWL_Listing::status_class( $l->status ) ); ?>"><?php echo esc_html( PWL_Listing::status_label( $l->status ) ); ?></span></td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $l->updated_at ) ) ); ?></td>
            <td>
                <a href="<?php echo esc_url( $edit_url ); ?>" class="button button-small"><?php esc_html_e( 'Edit', 'realwise' ); ?></a>
                <a href="<?php echo esc_url( $delete_url ); ?>" class="button button-small"
                   onclick="return confirm('<?php esc_attr_e( 'Delete this listing?', 'realwise' ); ?>')"
                   style="color:#b32d2e;border-color:#b32d2e"><?php esc_html_e( 'Delete', 'realwise' ); ?></a>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php if ( $pages > 1 ) : ?>
    <div class="tablenav bottom"><div class="tablenav-pages">
        <?php for ( $i = 1; $i <= $pages; $i++ ) : ?>
        <a class="button <?php echo $i === $page ? 'button-primary' : ''; ?>"
           href="<?php echo esc_url( add_query_arg( 'paged', $i ) ); ?>"><?php echo (int) $i; ?></a>
        <?php endfor; ?>
    </div></div>
    <?php endif; ?>
</div>
