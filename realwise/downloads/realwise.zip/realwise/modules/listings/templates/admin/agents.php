<?php if ( ! defined( 'ABSPATH' ) ) exit;
$a = $editing; // shorthand — null when adding new
?>
<div class="wrap pwl-admin">
    <h1><?php esc_html_e( 'Agents', 'realwise' ); ?>
        <?php if ( $a ) : ?>
        <a href="<?php echo esc_url( add_query_arg( 'page', 'pwl-agents', admin_url('admin.php') ) ); ?>"
           class="page-title-action"><?php esc_html_e( '+ Add New', 'realwise' ); ?></a>
        <?php endif; ?>
    </h1>

    <?php if ( isset( $_GET['msg'] ) ) : ?>
    <div class="notice notice-success is-dismissible">
        <p><?php echo $_GET['msg'] === 'saved' ? esc_html__( 'Agent saved.', 'realwise' ) : esc_html__( 'Agent deleted.', 'realwise' ); ?></p>
    </div>
    <?php endif; ?>

    <!-- Add / Edit form -->
    <div class="pwl-edit-card" style="max-width:680px;margin-bottom:24px">
        <h2 class="pwl-edit-card__title"><?php echo $a ? esc_html__( 'Edit Agent', 'realwise' ) : esc_html__( 'Add Agent', 'realwise' ); ?></h2>
        <form method="post" action="<?php echo esc_url( admin_url('admin-post.php') ); ?>">
            <input type="hidden" name="action"   value="pwl_save_agent">
            <input type="hidden" name="agent_id" value="<?php echo (int) $a?->id; ?>">
            <?php wp_nonce_field( 'pwl_save_agent' ); ?>
            <table class="form-table">
                <tr><th><label for="pwl-agent-name"><?php esc_html_e( 'Name', 'realwise' ); ?> <span style="color:red">*</span></label></th>
                    <td><input type="text" id="pwl-agent-name" name="name" value="<?php echo esc_attr( $a?->name ?? '' ); ?>" class="regular-text" required></td></tr>
                <tr><th><label for="pwl-agent-email"><?php esc_html_e( 'Email', 'realwise' ); ?></label></th>
                    <td><input type="email" id="pwl-agent-email" name="email" value="<?php echo esc_attr( $a?->email ?? '' ); ?>" class="regular-text"></td></tr>
                <tr><th><label for="pwl-agent-phone"><?php esc_html_e( 'Phone', 'realwise' ); ?></label></th>
                    <td><input type="text" id="pwl-agent-phone" name="phone" value="<?php echo esc_attr( $a?->phone ?? '' ); ?>" class="regular-text"></td></tr>
                <tr><th><label for="pwl-agent-brokerage"><?php esc_html_e( 'Brokerage', 'realwise' ); ?></label></th>
                    <td><input type="text" id="pwl-agent-brokerage" name="brokerage" value="<?php echo esc_attr( $a?->brokerage ?? '' ); ?>" class="regular-text"></td></tr>
                <tr><th><label for="pwl-agent-license"><?php esc_html_e( 'License #', 'realwise' ); ?></label></th>
                    <td><input type="text" id="pwl-agent-license" name="license_num" value="<?php echo esc_attr( $a?->license_num ?? '' ); ?>" class="regular-text"></td></tr>
                <tr><th><label for="pwl-agent-photo"><?php esc_html_e( 'Photo URL', 'realwise' ); ?></label></th>
                    <td>
                        <input type="url" id="pwl-agent-photo" name="photo_url" value="<?php echo esc_attr( $a?->photo_url ?? '' ); ?>" class="regular-text">
                        <?php if ( $a?->photo_url ) : ?>
                        <br><img src="<?php echo esc_url( $a->photo_url ); ?>" style="width:60px;height:60px;border-radius:50%;object-fit:cover;margin-top:6px">
                        <?php endif; ?>
                    </td></tr>
                <tr><th><label for="pwl-agent-bio"><?php esc_html_e( 'Bio', 'realwise' ); ?></label></th>
                    <td><textarea id="pwl-agent-bio" name="bio" rows="4" class="large-text"><?php echo esc_textarea( $a?->bio ?? '' ); ?></textarea></td></tr>
            </table>
            <p>
                <input type="submit" class="button button-primary" value="<?php echo $a ? esc_attr__( 'Update Agent', 'realwise' ) : esc_attr__( 'Add Agent', 'realwise' ); ?>">
                <?php if ( $a ) : ?>
                <a href="<?php echo esc_url( add_query_arg( 'page', 'pwl-agents', admin_url('admin.php') ) ); ?>" class="button"><?php esc_html_e( 'Cancel', 'realwise' ); ?></a>
                <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'pwl_delete_agent', 'id' => $a->id ], admin_url('admin-post.php') ), 'pwl_delete_agent' ) ); ?>"
                   class="button" style="float:right;color:#b32d2e;border-color:#b32d2e"
                   onclick="return confirm('<?php esc_attr_e('Delete this agent?','realwise'); ?>')"><?php esc_html_e( 'Delete Agent', 'realwise' ); ?></a>
                <?php endif; ?>
            </p>
        </form>
    </div>

    <!-- Agents table -->
    <h2><?php esc_html_e( 'All Agents', 'realwise' ); ?> <span class="pwl-count"><?php echo count( $agents ); ?></span></h2>
    <table class="widefat striped pwl-admin-table">
        <thead><tr>
            <th><?php esc_html_e( 'Photo', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Name', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Email', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Phone', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Brokerage', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'License', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'realwise' ); ?></th>
        </tr></thead>
        <tbody>
        <?php if ( $agents ) : ?>
            <?php foreach ( $agents as $row ) : ?>
            <tr>
                <td><?php if ( $row->photo_url ) : ?><img src="<?php echo esc_url( $row->photo_url ); ?>" style="width:36px;height:36px;border-radius:50%;object-fit:cover"><?php endif; ?></td>
                <td><strong><?php echo esc_html( $row->name ); ?></strong></td>
                <td><?php echo esc_html( $row->email ?? '—' ); ?></td>
                <td><?php echo esc_html( $row->phone ?? '—' ); ?></td>
                <td><?php echo esc_html( $row->brokerage ?? '—' ); ?></td>
                <td><?php echo esc_html( $row->license_num ?? '—' ); ?></td>
                <td>
                    <a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwl-agents', 'id' => $row->id ], admin_url('admin.php') ) ); ?>" class="button button-small"><?php esc_html_e( 'Edit', 'realwise' ); ?></a>
                </td>
            </tr>
            <?php endforeach; ?>
        <?php else : ?>
            <tr><td colspan="7"><?php esc_html_e( 'No agents yet. Add one above or import via MLS Connect.', 'realwise' ); ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>

<style>
.pwl-edit-card { background:#fff; border:1px solid #c3c4c7; border-radius:4px; padding:16px 20px; }
.pwl-edit-card__title { font-size:14px; font-weight:600; margin:0 0 12px; padding-bottom:8px; border-bottom:1px solid #f0f0f1; }
</style>
