<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwl-grid">
<?php if ( empty( $listings ) ) : ?>
    <p class="pwl-grid__empty"><?php esc_html_e( 'No properties found matching your search.', 'realwise' ); ?></p>
<?php else : ?>
    <?php foreach ( $listings as $listing ) :
        $photo = PWL_Listing::first_photo( $listing );
        $url   = PWL_Listing::listing_url( $listing->id );
    ?>
    <article class="pwl-card" data-id="<?php echo (int) $listing->id; ?>">
        <a href="<?php echo esc_url( $url ); ?>" class="pwl-card__img-wrap">
            <?php if ( $photo ) : ?>
                <img src="<?php echo esc_url( $photo ); ?>" alt="<?php echo esc_attr( $listing->address ); ?>" class="pwl-card__img" loading="lazy">
            <?php else : ?>
                <div class="pwl-card__img pwl-card__img--placeholder"></div>
            <?php endif; ?>
            <span class="pwl-badge <?php echo esc_attr( PWL_Listing::status_class( $listing->status ) ); ?>">
                <?php echo esc_html( PWL_Listing::status_label( $listing->status ) ); ?>
            </span>
        </a>
        <div class="pwl-card__body">
            <div class="pwl-card__price"><?php echo esc_html( PWL_Listing::format_price( $listing->list_price ) ); ?></div>
            <div class="pwl-card__meta"><?php echo esc_html( PWL_Listing::beds_baths_label( $listing ) ); ?></div>
            <div class="pwl-card__address"><?php echo esc_html( $listing->address ); ?></div>
            <div class="pwl-card__city"><?php echo esc_html( $listing->city . ', ' . $listing->state . ' ' . $listing->zip_code ); ?></div>
            <?php if ( $listing->walk_score ) : ?>
            <div class="pwl-card__scores">
                <span class="pwl-score pwl-score--walk" title="Walk Score"><?php echo (int) $listing->walk_score; ?></span>
                <?php if ( $listing->crime_grade ) : ?>
                <span class="pwl-score pwl-score--crime" title="Crime Grade"><?php echo esc_html( $listing->crime_grade ); ?></span>
                <?php endif; ?>
                <?php if ( $listing->school_rating ) : ?>
                <span class="pwl-score pwl-score--school" title="School Rating"><?php echo esc_html( number_format( $listing->school_rating, 1 ) ); ?>/10</span>
                <?php endif; ?>
            </div>
            <?php endif; ?>
            <div class="pwl-card__footer">
                <span class="pwl-card__dom"><?php echo (int) $listing->days_on_market; ?> days on market</span>
                <?php if ( is_user_logged_in() ) : ?>
                <button class="pwl-save-btn" data-id="<?php echo (int) $listing->id; ?>" title="Save property">&#9825;</button>
                <?php endif; ?>
            </div>
        </div>
    </article>
    <?php endforeach; ?>
<?php endif; ?>
</div>
