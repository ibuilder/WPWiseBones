<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwl-detail" id="pwl-detail-<?php echo (int) $listing->id; ?>">

    <!-- Photo gallery -->
    <?php
    // Normalise photos to a flat list of URL strings, regardless of whether
    // the importer stored them as { MediaURL:... } objects or plain strings.
    $photo_urls = [];
    foreach ( $photos as $ph ) {
        $url = is_array( $ph ) ? ( $ph['MediaURL'] ?? $ph['url'] ?? '' ) : (string) $ph;
        if ( $url ) $photo_urls[] = $url;
    }
    ?>
    <?php if ( $photo_urls ) : ?>
    <div class="pwl-gallery">
        <img src="<?php echo esc_url( $photo_urls[0] ); ?>" alt="<?php echo esc_attr( $listing->address ); ?>" class="pwl-gallery__main" id="pwl-gallery-main">
        <?php if ( count( $photo_urls ) > 1 ) : ?>
        <div class="pwl-gallery__thumbs">
            <?php foreach ( array_slice( $photo_urls, 0, 8 ) as $i => $url ) : ?>
            <img src="<?php echo esc_url( $url ); ?>" alt="" class="pwl-gallery__thumb <?php echo $i === 0 ? 'pwl-gallery__thumb--active' : ''; ?>"
                 loading="lazy" onclick="document.getElementById('pwl-gallery-main').src=this.src">
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="pwl-detail__header">
        <div>
            <h1 class="pwl-detail__price"><?php echo esc_html( PWL_Listing::format_price( $listing->list_price ) ); ?></h1>
            <div class="pwl-detail__address"><?php echo esc_html( $listing->address . ', ' . $listing->city . ', ' . $listing->state . ' ' . $listing->zip_code ); ?></div>
            <div class="pwl-detail__meta"><?php echo esc_html( PWL_Listing::beds_baths_label( $listing ) ); ?>
                <?php if ( $listing->year_built ) echo ' · Built ' . esc_html( $listing->year_built ); ?>
                <?php if ( $listing->lot_sqft )   echo ' · ' . esc_html( number_format( $listing->lot_sqft ) ) . ' sqft lot'; ?>
            </div>
        </div>
        <div class="pwl-detail__header-right">
            <span class="pwl-badge <?php echo esc_attr( PWL_Listing::status_class( $listing->status ) ); ?>"><?php echo esc_html( PWL_Listing::status_label( $listing->status ) ); ?></span>
            <div class="pwl-detail__dom"><?php echo (int) $listing->days_on_market; ?> days on market</div>
            <?php if ( is_user_logged_in() ) : ?>
            <button class="pwl-save-btn pwl-btn" data-id="<?php echo (int) $listing->id; ?>">&#9825; Save</button>
            <?php endif; ?>
            <?php if ( $listing->virtual_tour ) : ?>
            <a href="<?php echo esc_url( $listing->virtual_tour ); ?>" target="_blank" rel="noopener" class="pwl-btn pwl-btn--outline">&#127909; Virtual Tour</a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Two-column layout: details + scores + mortgage | map + agent -->
    <div class="pwl-detail__body">
        <div class="pwl-detail__main">

            <!-- Neighborhood Scores -->
            <section class="pwl-section">
                <h2 class="pwl-section__title">Neighborhood</h2>
                <div class="pwl-scores-grid">
                    <div class="pwl-score-card">
                        <div class="pwl-score-card__value pwl-score-card__value--walk"><?php echo $walk['walk'] !== null ? (int) $walk['walk'] : '—'; ?></div>
                        <div class="pwl-score-card__label">Walk Score</div>
                        <div class="pwl-score-card__desc"><?php echo esc_html( $walk['walk_desc'] ?? '' ); ?></div>
                    </div>
                    <div class="pwl-score-card">
                        <div class="pwl-score-card__value pwl-score-card__value--transit"><?php echo $walk['transit'] !== null ? (int) $walk['transit'] : '—'; ?></div>
                        <div class="pwl-score-card__label">Transit Score</div>
                        <div class="pwl-score-card__desc"><?php echo esc_html( $walk['transit_desc'] ?? '' ); ?></div>
                    </div>
                    <div class="pwl-score-card">
                        <div class="pwl-score-card__value pwl-score-card__value--bike"><?php echo $walk['bike'] !== null ? (int) $walk['bike'] : '—'; ?></div>
                        <div class="pwl-score-card__label">Bike Score</div>
                        <div class="pwl-score-card__desc"><?php echo esc_html( $walk['bike_desc'] ?? '' ); ?></div>
                    </div>
                    <div class="pwl-score-card">
                        <div class="pwl-score-card__value pwl-score-card__value--crime"><?php echo esc_html( $crime['grade'] ?? '—' ); ?></div>
                        <div class="pwl-score-card__label">Crime Grade</div>
                        <div class="pwl-score-card__desc"><?php echo esc_html( $crime['description'] ?? '' ); ?></div>
                    </div>
                </div>
            </section>

            <!-- Schools -->
            <?php if ( ! empty( $schools['schools'] ) ) : ?>
            <section class="pwl-section">
                <h2 class="pwl-section__title">Nearby Schools
                    <?php if ( $schools['summary_rating'] ) : ?>
                    <span class="pwl-school-avg">Avg <?php echo esc_html( number_format( $schools['summary_rating'], 1 ) ); ?>/10</span>
                    <?php endif; ?>
                </h2>
                <table class="pwl-table">
                    <thead><tr><th>School</th><th>Level</th><th>Rating</th><th>Distance</th></tr></thead>
                    <tbody>
                    <?php foreach ( $schools['schools'] as $school ) : ?>
                    <tr>
                        <td><?php echo esc_html( $school['name'] ); ?></td>
                        <td><?php echo esc_html( ucfirst( $school['level'] ) ); ?></td>
                        <td>
                            <span class="pwl-rating-bar" style="--r:<?php echo (int) $school['rating']; ?>">
                                <?php echo (int) $school['rating']; ?>/10
                            </span>
                        </td>
                        <td><?php echo esc_html( $school['distance'] ); ?> mi</td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </section>
            <?php endif; ?>

            <!-- Property Details -->
            <section class="pwl-section">
                <h2 class="pwl-section__title">Property Details</h2>
                <dl class="pwl-dl">
                    <?php if ( $listing->asset_type )    : ?><dt>Type</dt><dd><?php echo esc_html( ucfirst( $listing->asset_type ) ); ?></dd><?php endif; ?>
                    <?php if ( $listing->year_built )    : ?><dt>Year Built</dt><dd><?php echo (int) $listing->year_built; ?></dd><?php endif; ?>
                    <?php if ( $listing->garage_spaces ) : ?><dt>Garage</dt><dd><?php echo (int) $listing->garage_spaces; ?> space(s)</dd><?php endif; ?>
                    <?php if ( $listing->pool )          : ?><dt>Pool</dt><dd>Yes</dd><?php endif; ?>
                    <?php if ( $listing->hoa_fee )       : ?><dt>HOA Fee</dt><dd><?php echo esc_html( PWL_Listing::format_price( $listing->hoa_fee ) ); ?>/mo</dd><?php endif; ?>
                    <?php if ( $listing->property_taxes ): ?><dt>Annual Taxes</dt><dd><?php echo esc_html( PWL_Listing::format_price( $listing->property_taxes ) ); ?></dd><?php endif; ?>
                    <?php if ( $listing->flood_zone )    : ?><dt>Flood Zone</dt><dd><?php echo esc_html( $listing->flood_zone ); ?></dd><?php endif; ?>
                    <?php if ( $listing->zoning )        : ?><dt>Zoning</dt><dd><?php echo esc_html( $listing->zoning ); ?></dd><?php endif; ?>
                    <?php if ( $listing->mls_id )        : ?><dt>MLS #</dt><dd><?php echo esc_html( $listing->mls_id ); ?></dd><?php endif; ?>
                </dl>
            </section>

            <!-- Description -->
            <?php if ( $listing->description ) : ?>
            <section class="pwl-section">
                <h2 class="pwl-section__title">Description</h2>
                <div class="pwl-detail__desc"><?php echo nl2br( esc_html( $listing->description ) ); ?></div>
            </section>
            <?php endif; ?>

            <!-- Price History Chart -->
            <?php if ( $price_history ) : ?>
            <section class="pwl-section">
                <h2 class="pwl-section__title">Price History</h2>
                <canvas id="pwl-price-chart" class="pwl-chart"
                        data-labels="<?php echo esc_attr( wp_json_encode( array_column( $price_history, 'event_date' ) ) ); ?>"
                        data-values="<?php echo esc_attr( wp_json_encode( array_column( $price_history, 'price' ) ) ); ?>"></canvas>
            </section>
            <?php endif; ?>

            <!-- Mortgage Calculator -->
            <section class="pwl-section" id="pwl-mortgage-section">
                <h2 class="pwl-section__title">Mortgage Estimate</h2>
                <?php
                // mortgage-calculator.php needs $atts['show_table']; provide default when included from detail page
                if ( ! isset( $atts ) ) $atts = [ 'show_table' => 'false' ];
                include __DIR__ . '/mortgage-calculator.php';
                ?>
            </section>

        </div><!-- .pwl-detail__main -->

        <div class="pwl-detail__sidebar">

            <!-- Map -->
            <?php if ( $listing->latitude && $listing->longitude ) : ?>
            <div class="pwl-section pwl-detail__map-wrap">
                <div id="pwl-detail-map" class="pwl-map pwl-map--detail"
                     data-lat="<?php echo esc_attr( $listing->latitude ); ?>"
                     data-lon="<?php echo esc_attr( $listing->longitude ); ?>"
                     data-addr="<?php echo esc_attr( $listing->address ); ?>"></div>
            </div>
            <?php endif; ?>

            <!-- Agent Contact -->
            <?php if ( $listing->agent_name ) : ?>
            <div class="pwl-section pwl-agent-card">
                <?php if ( $listing->agent_photo ) : ?>
                <img src="<?php echo esc_url( $listing->agent_photo ); ?>" alt="" class="pwl-agent-card__photo">
                <?php endif; ?>
                <div class="pwl-agent-card__name"><?php echo esc_html( $listing->agent_name ); ?></div>
                <div class="pwl-agent-card__brokerage"><?php echo esc_html( $listing->agent_brokerage ?? '' ); ?></div>
                <?php if ( $listing->agent_phone ) : ?>
                <a href="tel:<?php echo esc_attr( $listing->agent_phone ); ?>" class="pwl-btn pwl-btn--block"><?php echo esc_html( $listing->agent_phone ); ?></a>
                <?php endif; ?>
                <?php if ( is_user_logged_in() && $listing->agent_email ) : ?>
                <form class="pwl-contact-form" data-listing="<?php echo (int) $listing->id; ?>">
                    <textarea name="message" class="pwl-textarea" rows="3" placeholder="<?php esc_attr_e( 'Your message…', 'realwise' ); ?>"></textarea>
                    <button type="submit" class="pwl-btn pwl-btn--primary pwl-btn--block"><?php esc_html_e( 'Contact Agent', 'realwise' ); ?></button>
                    <div class="pwl-contact-form__msg"></div>
                </form>
                <?php endif; ?>
            </div>
            <?php endif; ?>

        </div><!-- .pwl-detail__sidebar -->
    </div><!-- .pwl-detail__body -->

    <!-- Nearby Listings -->
    <?php if ( $nearby ) : ?>
    <section class="pwl-section pwl-section--nearby">
        <h2 class="pwl-section__title">Similar Nearby Properties</h2>
        <?php $listings = $nearby; include __DIR__ . '/listing-grid.php'; ?>
    </section>
    <?php endif; ?>

</div>
