<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwl-mortgage" id="pwl-mortgage-calc"
     data-price="<?php echo esc_attr( $summary['purchase_price'] ); ?>"
     data-rate="<?php echo esc_attr( $summary['annual_rate_pct'] ); ?>"
     data-years="<?php echo esc_attr( $summary['years'] ); ?>">

    <div class="pwl-mortgage__inputs">
        <div class="pwl-mortgage__field">
            <label><?php esc_html_e( 'Purchase Price', 'realwise' ); ?></label>
            <input type="number" id="pwl-mort-price" class="pwl-input" value="<?php echo esc_attr( $summary['purchase_price'] ); ?>" step="1000">
        </div>
        <div class="pwl-mortgage__field">
            <label><?php esc_html_e( 'Down Payment', 'realwise' ); ?> (<span id="pwl-mort-down-pct"><?php echo esc_html( $summary['down_pct'] ); ?></span>%)</label>
            <input type="range" id="pwl-mort-down" min="3" max="60" value="<?php echo esc_attr( $summary['down_pct'] ); ?>" step="1" class="pwl-range">
        </div>
        <div class="pwl-mortgage__field">
            <label><?php esc_html_e( 'Interest Rate (%)', 'realwise' ); ?></label>
            <input type="number" id="pwl-mort-rate" class="pwl-input" value="<?php echo esc_attr( $summary['annual_rate_pct'] ); ?>" step="0.125" min="1" max="20">
        </div>
        <div class="pwl-mortgage__field">
            <label><?php esc_html_e( 'Loan Term', 'realwise' ); ?></label>
            <select id="pwl-mort-years" class="pwl-select">
                <option value="30" <?php selected( $summary['years'], 30 ); ?>><?php esc_html_e( '30 Years', 'realwise' ); ?></option>
                <option value="20" <?php selected( $summary['years'], 20 ); ?>><?php esc_html_e( '20 Years', 'realwise' ); ?></option>
                <option value="15" <?php selected( $summary['years'], 15 ); ?>><?php esc_html_e( '15 Years', 'realwise' ); ?></option>
                <option value="10" <?php selected( $summary['years'], 10 ); ?>><?php esc_html_e( '10 Years', 'realwise' ); ?></option>
            </select>
        </div>
    </div>

    <div class="pwl-mortgage__results" id="pwl-mort-results">
        <div class="pwl-mortgage__monthly">
            <span class="pwl-mortgage__monthly-label"><?php esc_html_e( 'Monthly Payment', 'realwise' ); ?></span>
            <span class="pwl-mortgage__monthly-value" id="pwl-mort-monthly">
                <?php echo esc_html( PWL_Listing::format_price( $summary['monthly_total'] ) ); ?></span>
            <?php if ( $summary['monthly_pmi'] ) : ?>
            <span class="pwl-mortgage__pmi"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( '(includes %s/mo PMI)', 'realwise' ), esc_html( PWL_Listing::format_price( $summary['monthly_pmi'] ) ) ); ?></span>
            <?php endif; ?>
        </div>
        <dl class="pwl-mortgage__breakdown">
            <dt><?php esc_html_e( 'Loan Amount',     'realwise' ); ?></dt> <dd id="pwl-mort-loan">    <?php echo esc_html( PWL_Listing::format_price( $summary['loan_amount']    ) ); ?></dd>
            <dt><?php esc_html_e( 'Down Payment',    'realwise' ); ?></dt> <dd id="pwl-mort-down-amt"><?php echo esc_html( PWL_Listing::format_price( $summary['down_payment']   ) ); ?></dd>
            <dt><?php esc_html_e( 'Total Interest',  'realwise' ); ?></dt> <dd id="pwl-mort-int">     <?php echo esc_html( PWL_Listing::format_price( $summary['total_interest'] ) ); ?></dd>
            <dt><?php esc_html_e( 'Total Cost',      'realwise' ); ?></dt> <dd id="pwl-mort-total">   <?php echo esc_html( PWL_Listing::format_price( $summary['total_paid']     ) ); ?></dd>
        </dl>
        <canvas id="pwl-amort-chart" class="pwl-chart pwl-chart--amort"></canvas>
    </div>

    <!-- Amortization schedule table — controlled by show_table shortcode attr -->
    <?php if ( isset( $atts['show_table'] ) && $atts['show_table'] === 'true' ) : ?>
    <details class="pwl-amort-table-wrap" id="pwl-amort-table-wrap">
        <summary class="pwl-amort-table-toggle"><?php esc_html_e( 'Full Amortization Schedule', 'realwise' ); ?></summary>
        <div class="pwl-amort-table-scroll">
            <table class="pwl-table pwl-table--amort" id="pwl-amort-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Month', 'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Payment', 'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Principal', 'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Interest', 'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Balance', 'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Cum. Interest', 'realwise' ); ?></th>
                    </tr>
                </thead>
                <tbody id="pwl-amort-tbody">
                    <?php
                    $loan     = $summary['loan_amount'];
                    $rate_dec = $summary['annual_rate_pct'] / 100;
                    $schedule = PWL_Mortgage::amortization( $loan, $rate_dec, $summary['years'] );
                    foreach ( $schedule as $row ) :
                    ?>
                    <tr>
                        <td><?php echo (int) $row['month']; ?></td>
                        <td><?php echo esc_html( PWL_Listing::format_price( $row['payment'] ) ); ?></td>
                        <td><?php echo esc_html( PWL_Listing::format_price( $row['principal'] ) ); ?></td>
                        <td><?php echo esc_html( PWL_Listing::format_price( $row['interest'] ) ); ?></td>
                        <td><?php echo esc_html( PWL_Listing::format_price( $row['balance'] ) ); ?></td>
                        <td><?php echo esc_html( PWL_Listing::format_price( $row['cumulative_interest'] ) ); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </details>
    <?php endif; ?>

    <!-- Closing Costs -->
    <details class="pwl-closing-details">
        <summary><?php esc_html_e( 'Estimated Closing Costs', 'realwise' ); ?></summary>
        <table class="pwl-table pwl-table--closing">
            <tbody>
            <?php foreach ( $closing_est as $label => $amount ) :
                $is_total = ( $label === 'Total Closing Costs' );
            ?>
            <tr class="<?php echo $is_total ? 'pwl-table__total' : ''; ?>">
                <td><?php echo esc_html( $label ); ?></td>
                <td><?php echo esc_html( PWL_Listing::format_price( $amount ) ); ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </details>

</div>
