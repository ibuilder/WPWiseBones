<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwl-search-wrap" id="pwl-search">

    <?php if ( $atts['show_filters'] === 'true' ) : ?>
    <form class="pwl-search-form" id="pwl-search-form" method="get">
        <div class="pwl-search-row pwl-search-row--top">
            <input type="text" name="q" class="pwl-search-input"
                   placeholder="<?php esc_attr_e( 'City, ZIP, address, or keyword', 'realwise' ); ?>"
                   value="<?php echo esc_attr( $args['q'] ); ?>">
            <select name="type" class="pwl-select">
                <?php foreach ( [ 'all' => 'All Types', 'residential' => 'Residential', 'commercial' => 'Commercial',
                                  'industrial' => 'Industrial', 'land' => 'Land', 'multifamily' => 'Multifamily',
                                  'aviation' => 'Aviation' ] as $val => $label ) : ?>
                    <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $args['asset_type'], $val ); ?>><?php echo esc_html( $label ); ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="pwl-btn pwl-btn--primary"><?php esc_html_e( 'Search', 'realwise' ); ?></button>
        </div>
        <div class="pwl-search-row pwl-search-row--filters">
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'Min Price', 'realwise' ); ?></label>
                <input type="number" name="min_price" class="pwl-input"
                       value="<?php echo esc_attr( $args['min_price'] ?: '' ); ?>" placeholder="$0" step="10000">
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'Max Price', 'realwise' ); ?></label>
                <input type="number" name="max_price" class="pwl-input"
                       value="<?php echo esc_attr( $args['max_price'] ?: '' ); ?>" placeholder="No max" step="10000">
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'Min Beds', 'realwise' ); ?></label>
                <select name="min_beds" class="pwl-select">
                    <?php foreach ( [ 0 => 'Any', 1 => '1+', 2 => '2+', 3 => '3+', 4 => '4+', 5 => '5+' ] as $v => $l ) : ?>
                        <option value="<?php echo (int) $v; ?>" <?php selected( (int) $args['min_beds'], $v ); ?>><?php echo esc_html( $l ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'Min Baths', 'realwise' ); ?></label>
                <select name="min_baths" class="pwl-select">
                    <?php foreach ( [ 0 => 'Any', 1 => '1+', 1.5 => '1.5+', 2 => '2+', 3 => '3+', 4 => '4+' ] as $v => $l ) : ?>
                        <option value="<?php echo esc_attr( $v ); ?>" <?php selected( (float) $args['min_baths'], (float) $v ); ?>><?php echo esc_html( $l ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'Status', 'realwise' ); ?></label>
                <select name="status" class="pwl-select">
                    <?php foreach ( [ 'active' => 'Active', 'pending' => 'Pending', 'closed' => 'Sold', 'all' => 'All' ] as $v => $l ) : ?>
                        <option value="<?php echo esc_attr( $v ); ?>" <?php selected( $args['status'] ?? 'active', $v ); ?>><?php echo esc_html( $l ); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'City', 'realwise' ); ?></label>
                <input type="text" name="city" class="pwl-input"
                       value="<?php echo esc_attr( $args['city'] ); ?>" placeholder="Any city">
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'ZIP', 'realwise' ); ?></label>
                <input type="text" name="zip" class="pwl-input"
                       value="<?php echo esc_attr( $args['zip'] ); ?>" placeholder="Any ZIP">
            </div>
            <div class="pwl-filter-group">
                <label><?php esc_html_e( 'Sort by', 'realwise' ); ?></label>
                <select name="order_by" class="pwl-select">
                    <option value="days_on_market" <?php selected( $args['order_by'], 'days_on_market' ); ?>><?php esc_html_e( 'Days on Market', 'realwise' ); ?></option>
                    <option value="list_price"     <?php selected( $args['order_by'], 'list_price' );     ?>><?php esc_html_e( 'Price: Low → High', 'realwise' ); ?></option>
                    <option value="list_price_d"   <?php selected( $args['order_by'], 'list_price_d' );   ?>><?php esc_html_e( 'Price: High → Low', 'realwise' ); ?></option>
                    <option value="created_at"     <?php selected( $args['order_by'], 'created_at' );     ?>><?php esc_html_e( 'Newest', 'realwise' ); ?></option>
                    <option value="sqft"           <?php selected( $args['order_by'], 'sqft' );           ?>><?php esc_html_e( 'Sq Ft', 'realwise' ); ?></option>
                </select>
            </div>
        </div>
    </form>
    <?php endif; ?>

    <div class="pwl-search-results-meta">
        <span class="pwl-results-count">
            <?php /* translators: %d / %s are runtime values. */ printf( esc_html( _n( '%s property found', '%s properties found', $total, 'realwise' ) ), number_format( $total ) ); ?>
        </span>
        <?php if ( $args['status'] !== 'active' ) : ?>
        <span class="pwl-results-status-note">&nbsp;&mdash; showing: <?php echo esc_html( ucfirst( $args['status'] ) ); ?></span>
        <?php endif; ?>
        <?php if ( is_user_logged_in() ) : ?>
        <button type="button" class="pwl-btn pwl-btn--outline pwl-btn--sm pwl-save-search-btn" id="pwl-save-search-btn">
            &#128276; <?php esc_html_e( 'Save this search', 'realwise' ); ?>
        </button>
        <?php else :
            $pwl_host = isset( $_SERVER['HTTP_HOST'] )   ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) )   : '';
            $pwl_uri  = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
            $pwl_here = ( is_ssl() ? 'https' : 'http' ) . '://' . $pwl_host . $pwl_uri;
        ?>
        <a href="<?php echo esc_url( wp_login_url( $pwl_here ) ); ?>"
           class="pwl-btn pwl-btn--outline pwl-btn--sm">&#128276; <?php esc_html_e( 'Log in to save & get alerts', 'realwise' ); ?></a>
        <?php endif; ?>
    </div>

    <?php if ( is_user_logged_in() ) : ?>
    <!-- Save search modal -->
    <div class="pwl-modal" id="pwl-save-search-modal" hidden>
        <div class="pwl-modal__backdrop" data-close></div>
        <div class="pwl-modal__box" role="dialog" aria-modal="true" aria-labelledby="pwl-ss-title">
            <h3 id="pwl-ss-title"><?php esc_html_e( 'Save Search & Get Alerts', 'realwise' ); ?></h3>
            <p class="pwl-modal__desc"><?php esc_html_e( 'We will email you when new homes match these filters.', 'realwise' ); ?></p>
            <label class="pwl-modal__label"><?php esc_html_e( 'Name this search', 'realwise' ); ?>
                <input type="text" id="pwl-ss-label" class="pwl-input" value="<?php echo esc_attr( $args['q'] ?: ( $args['city'] ?: __( 'My Search', 'realwise' ) ) ); ?>">
            </label>
            <label class="pwl-modal__label"><?php esc_html_e( 'Alert frequency', 'realwise' ); ?>
                <select id="pwl-ss-frequency" class="pwl-select">
                    <option value="instant"><?php esc_html_e( 'As soon as they hit the market', 'realwise' ); ?></option>
                    <option value="daily" selected><?php esc_html_e( 'Daily digest', 'realwise' ); ?></option>
                    <option value="weekly"><?php esc_html_e( 'Weekly digest', 'realwise' ); ?></option>
                </select>
            </label>
            <div class="pwl-modal__actions">
                <button class="pwl-btn pwl-btn--primary" id="pwl-ss-confirm"><?php esc_html_e( 'Save & Subscribe', 'realwise' ); ?></button>
                <button class="pwl-btn" data-close><?php esc_html_e( 'Cancel', 'realwise' ); ?></button>
            </div>
            <div class="pwl-modal__msg" id="pwl-ss-msg"></div>
        </div>
    </div>
    <?php endif; ?>

    <div class="pwl-search-layout">
        <?php if ( $atts['show_map'] === 'true' ) : ?>
        <div class="pwl-map-pane">
            <div id="pwl-map" class="pwl-map" data-load="true"></div>
        </div>
        <?php endif; ?>
        <div class="pwl-results-pane" id="pwl-results">
            <?php include __DIR__ . '/listing-grid.php'; ?>

            <?php if ( $pages > 1 ) : ?>
            <nav class="pwl-pagination" aria-label="<?php esc_attr_e( 'Listings pages', 'realwise' ); ?>">
                <?php if ( $args['page'] > 1 ) : ?>
                <a href="<?php echo esc_url( add_query_arg( 'pwl_page', $args['page'] - 1 ) ); ?>" class="pwl-page-link">&laquo;</a>
                <?php endif; ?>
                <?php for ( $i = 1; $i <= $pages; $i++ ) :
                    $dist = abs( $i - $args['page'] );
                    if ( $dist > 3 && $i !== 1 && $i !== $pages ) {
                        if ( $dist === 4 ) echo '<span class="pwl-page-ellipsis">&hellip;</span>';
                        continue;
                    }
                ?>
                <a href="<?php echo esc_url( add_query_arg( 'pwl_page', $i ) ); ?>"
                   class="pwl-page-link<?php echo $i === $args['page'] ? ' pwl-page-link--active' : ''; ?>"
                   aria-current="<?php echo $i === $args['page'] ? 'page' : 'false'; ?>"><?php echo (int) $i; ?></a>
                <?php endfor; ?>
                <?php if ( $args['page'] < $pages ) : ?>
                <a href="<?php echo esc_url( add_query_arg( 'pwl_page', $args['page'] + 1 ) ); ?>" class="pwl-page-link">&raquo;</a>
                <?php endif; ?>
            </nav>
            <?php endif; ?>
        </div>
    </div>
</div>
