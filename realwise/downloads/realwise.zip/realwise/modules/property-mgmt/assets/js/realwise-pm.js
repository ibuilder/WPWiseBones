/* RealWise Property Management — tenant portal */
(function ($) {
  'use strict';
  $(function () {

    // Pay rent
    $('.pwpm-pay-btn').on('click', function () {
      var $btn = $(this).prop('disabled', true);
      var $msg = $('#pwpm-pay-msg').text('');
      $.post(PWPM.ajax_url, { action: 'pwpm_pay_rent', nonce: PWPM.nonce, payment_id: $btn.data('payment') }, function (res) {
        $btn.prop('disabled', false);
        if (res.success && res.data.redirect) {
          window.location = res.data.redirect; // Stripe Checkout
        } else if (res.success) {
          $msg.css('color', '#0d9488').text(res.data.message || 'Recorded.');
        } else {
          $msg.css('color', '#dc2626').text((res.data && res.data.message) || 'Payment error.');
        }
      });
    });

    // Submit maintenance
    $('#pwpm-maint-form').on('submit', function (e) {
      e.preventDefault();
      var $form = $(this);
      var data = { action: 'pwpm_submit_maintenance', nonce: PWPM.nonce };
      $form.serializeArray().forEach(function (f) { data[f.name] = f.value; });
      var $msg = $('#pwpm-maint-msg').text('Submitting…');
      $.post(PWPM.ajax_url, data, function (res) {
        if (res.success) {
          $msg.css('color', '#0d9488').text(res.data.message);
          $form[0].reset();
          $('#pwpm-maint-list').prepend(
            '<li><span class="pwpm-maint-title">' + $('<div>').text(data.title).html() +
            '</span><span class="pwpm-pill pwpm-pill--open">Open</span><span class="pwpm-maint-date">now</span></li>'
          );
        } else {
          $msg.css('color', '#dc2626').text((res.data && res.data.message) || 'Error.');
        }
      });
    });
  });
}(jQuery));
