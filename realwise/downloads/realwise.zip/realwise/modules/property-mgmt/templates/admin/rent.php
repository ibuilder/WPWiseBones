<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwpm-admin">
    <h1><?php esc_html_e( 'Rent Roll', 'realwise' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) && $_GET['msg'] === 'paid' ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Marked paid.', 'realwise' ); ?></p></div><?php endif; ?>

    <form method="get" style="margin:12px 0">
        <input type="hidden" name="page" value="pwpm-rent">
        <label><?php esc_html_e( 'Period', 'realwise' ); ?> <input type="month" name="period" value="<?php echo esc_attr( $period ); ?>" onchange="this.form.submit()"></label>
    </form>

    <div class="pwpm-stats">
        <div class="pwpm-stat"><span class="pwpm-stat__num"><?php echo esc_html( PWPM_Rent::money( $collected ) ); ?></span><span class="pwpm-stat__label"><?php esc_html_e( 'Collected', 'realwise' ); ?></span></div>
        <div class="pwpm-stat"><span class="pwpm-stat__num"><?php echo esc_html( PWPM_Rent::money( $pending ) ); ?></span><span class="pwpm-stat__label"><?php esc_html_e( 'Outstanding', 'realwise' ); ?></span></div>
    </div>

    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'Property / Unit', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Tenant', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Amount', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Due', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Status', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Method', 'realwise' ); ?></th>
            <th></th>
        </tr></thead>
        <tbody>
        <?php if ( $rows ) : foreach ( $rows as $r ) : ?>
        <tr>
            <td><?php echo esc_html( $r->property_name . ' — ' . $r->unit_label ); ?></td>
            <td><?php echo esc_html( $r->tenant_name ?: '—' ); ?></td>
            <td><?php echo esc_html( PWPM_Rent::money( $r->amount ) ); ?></td>
            <td><?php echo $r->due_date ? esc_html( date_i18n( 'M j', strtotime( $r->due_date ) ) ) : '—'; ?></td>
            <td><span class="pwpm-pill pwpm-pill--<?php echo esc_attr( $r->status ); ?>"><?php echo esc_html( ucfirst( $r->status ) ); ?></span></td>
            <td><?php echo esc_html( $r->method ?: '—' ); ?></td>
            <td>
                <?php if ( $r->status !== 'paid' ) : ?>
                <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'pwpm_mark_paid', 'payment' => $r->id, 'period' => $period ], admin_url( 'admin-post.php' ) ), 'pwpm_mark_paid' ) ); ?>" class="button button-small"><?php esc_html_e( 'Mark Paid', 'realwise' ); ?></a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; else : ?>
        <tr><td colspan="7"><?php esc_html_e( 'No charges for this period yet. They are generated automatically each month.', 'realwise' ); ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
