<?php if ( ! defined( 'ABSPATH' ) ) exit;
$p = $editing;
?>
<div class="wrap pwpm-admin">
    <h1><?php esc_html_e( 'Properties', 'realwise' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved.', 'realwise' ); ?></p></div><?php endif; ?>

    <div class="pwpm-admin-grid">
        <div>
            <h2><?php echo $p ? esc_html__( 'Edit Property', 'realwise' ) : esc_html__( 'Add Property', 'realwise' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pwpm-box">
                <input type="hidden" name="action" value="pwpm_save_property">
                <input type="hidden" name="property_id" value="<?php echo (int) ( $p->id ?? 0 ); ?>">
                <?php wp_nonce_field( 'pwpm_save_property' ); ?>
                <p><label><?php esc_html_e( 'Name', 'realwise' ); ?><br><input type="text" name="name" value="<?php echo esc_attr( $p->name ?? '' ); ?>" class="regular-text" required></label></p>
                <p><label><?php esc_html_e( 'Address', 'realwise' ); ?><br><input type="text" name="address" value="<?php echo esc_attr( $p->address ?? '' ); ?>" class="regular-text"></label></p>
                <p>
                    <input type="text" name="city" value="<?php echo esc_attr( $p->city ?? '' ); ?>" placeholder="<?php esc_attr_e( 'City', 'realwise' ); ?>">
                    <input type="text" name="state" value="<?php echo esc_attr( $p->state ?? '' ); ?>" placeholder="<?php esc_attr_e( 'State', 'realwise' ); ?>" size="4" maxlength="4">
                    <input type="text" name="zip_code" value="<?php echo esc_attr( $p->zip_code ?? '' ); ?>" placeholder="<?php esc_attr_e( 'ZIP', 'realwise' ); ?>" size="8">
                </p>
                <p><label><?php esc_html_e( 'Owner (WP user ID)', 'realwise' ); ?><br><input type="number" name="owner_id" value="<?php echo esc_attr( $p->owner_id ?? '' ); ?>" class="small-text"></label></p>
                <button class="button button-primary"><?php esc_html_e( 'Save Property', 'realwise' ); ?></button>
            </form>

            <?php if ( $p ) : ?>
            <!-- Units for this property -->
            <h2><?php esc_html_e( 'Units', 'realwise' ); ?></h2>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e( 'Unit', 'realwise' ); ?></th><th><?php esc_html_e( 'Bed/Bath', 'realwise' ); ?></th><th><?php esc_html_e( 'Market Rent', 'realwise' ); ?></th><th><?php esc_html_e( 'Status', 'realwise' ); ?></th></tr></thead>
                <tbody>
                <?php if ( $units ) : foreach ( $units as $u ) : ?>
                <tr>
                    <td><?php echo esc_html( $u->label ); ?></td>
                    <td><?php echo esc_html( ( $u->bedrooms ?? '—' ) . ' / ' . ( $u->bathrooms ?? '—' ) ); ?></td>
                    <td><?php echo esc_html( PWPM_Rent::money( $u->market_rent ?? 0 ) ); ?></td>
                    <td><span class="pwpm-pill pwpm-pill--<?php echo esc_attr( $u->status ); ?>"><?php echo esc_html( ucfirst( $u->status ) ); ?></span></td>
                </tr>
                <?php endforeach; else : ?>
                <tr><td colspan="4"><?php esc_html_e( 'No units yet.', 'realwise' ); ?></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
            <h3><?php esc_html_e( 'Add Unit', 'realwise' ); ?></h3>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pwpm-box pwpm-unit-form">
                <input type="hidden" name="action" value="pwpm_save_unit">
                <input type="hidden" name="property_id" value="<?php echo (int) $p->id; ?>">
                <?php wp_nonce_field( 'pwpm_save_unit' ); ?>
                <input type="text" name="label" placeholder="<?php esc_attr_e( 'Unit label e.g. 2B', 'realwise' ); ?>" required>
                <input type="number" name="bedrooms" placeholder="<?php esc_attr_e( 'Beds', 'realwise' ); ?>" size="4">
                <input type="number" name="bathrooms" placeholder="<?php esc_attr_e( 'Baths', 'realwise' ); ?>" step="0.5" size="4">
                <input type="number" name="sqft" placeholder="<?php esc_attr_e( 'Sqft', 'realwise' ); ?>" size="6">
                <input type="number" name="market_rent" placeholder="<?php esc_attr_e( 'Market rent', 'realwise' ); ?>" step="50">
                <button class="button button-primary"><?php esc_html_e( 'Add Unit', 'realwise' ); ?></button>
            </form>
            <?php endif; ?>
        </div>

        <div>
            <h2><?php esc_html_e( 'All Properties', 'realwise' ); ?></h2>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e( 'Name', 'realwise' ); ?></th><th><?php esc_html_e( 'Location', 'realwise' ); ?></th><th><?php esc_html_e( 'Units', 'realwise' ); ?></th></tr></thead>
                <tbody>
                <?php foreach ( $properties as $row ) :
                    $ucount = count( PWPM_DB::units( (int) $row->id ) );
                ?>
                <tr>
                    <td><a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwpm-properties', 'property' => $row->id ], admin_url( 'admin.php' ) ) ); ?>"><strong><?php echo esc_html( $row->name ); ?></strong></a></td>
                    <td><?php echo esc_html( trim( $row->city . ', ' . $row->state, ', ' ) ); ?></td>
                    <td><?php echo (int) $ucount; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
