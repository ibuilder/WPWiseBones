<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwpm-admin">
    <h1><?php esc_html_e( 'Maintenance Requests', 'realwise' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Updated.', 'realwise' ); ?></p></div><?php endif; ?>

    <ul class="subsubsub">
        <?php
        $rw_tabs = [ '' => __( 'All', 'realwise' ), 'open' => __( 'Open', 'realwise' ), 'in_progress' => __( 'In Progress', 'realwise' ), 'resolved' => __( 'Resolved', 'realwise' ) ];
        $cur  = sanitize_key( wp_unslash( $_GET['status'] ?? '' ) );
        $links = [];
        foreach ( $rw_tabs as $k => $label ) {
            $url = add_query_arg( array_filter( [ 'page' => 'pwpm-maintenance', 'status' => $k ] ), admin_url( 'admin.php' ) );
            $links[] = '<a href="' . esc_url( $url ) . '" class="' . ( $cur === $k ? 'current' : '' ) . '">' . esc_html( $label ) . '</a>';
        }
        echo implode( ' | ', $links ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- items built with esc_url/esc_html.
        ?>
    </ul>

    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'Request', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Property / Unit', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Priority', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Status', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Date', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'realwise' ); ?></th>
        </tr></thead>
        <tbody>
        <?php if ( $reqs ) : foreach ( $reqs as $rw_item ) : ?>
        <tr>
            <td><strong><?php echo esc_html( $rw_item->title ); ?></strong><?php if ( $rw_item->description ) : ?><br><span class="description"><?php echo esc_html( wp_trim_words( $rw_item->description, 20 ) ); ?></span><?php endif; ?></td>
            <td><?php echo esc_html( $rw_item->property_name . ' — ' . $rw_item->unit_label ); ?></td>
            <td><span class="pwpm-pri pwpm-pri--<?php echo esc_attr( $rw_item->priority ); ?>"><?php echo esc_html( PWPM_Maintenance::priority_label( $rw_item->priority ) ); ?></span></td>
            <td><span class="pwpm-pill pwpm-pill--<?php echo esc_attr( $rw_item->status ); ?>"><?php echo esc_html( PWPM_Maintenance::status_label( $rw_item->status ) ); ?></span></td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $rw_item->created_at ) ) ); ?></td>
            <td>
                <?php foreach ( [ 'open' => __( 'Open', 'realwise' ), 'in_progress' => __( 'Start', 'realwise' ), 'resolved' => __( 'Resolve', 'realwise' ), 'closed' => __( 'Close', 'realwise' ) ] as $to => $label ) :
                    if ( $rw_item->status === $to ) continue; ?>
                <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'pwpm_maint_status', 'req' => $rw_item->id, 'to' => $to ], admin_url( 'admin-post.php' ) ), 'pwpm_maint_status' ) ); ?>" class="button button-small"><?php echo esc_html( $label ); ?></a>
                <?php endforeach; ?>
            </td>
        </tr>
        <?php endforeach; else : ?>
        <tr><td colspan="6"><?php esc_html_e( 'No maintenance requests.', 'realwise' ); ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
