<?php if ( ! defined( 'ABSPATH' ) ) exit;
$l = $editing;
?>
<div class="wrap pwpm-admin">
    <h1><?php esc_html_e( 'Leases', 'realwise' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Lease saved. A tenant login was created/linked.', 'realwise' ); ?></p></div><?php endif; ?>

    <div class="pwpm-admin-grid">
        <div>
            <h2><?php echo $l ? esc_html__( 'Edit Lease', 'realwise' ) : esc_html__( 'New Lease', 'realwise' ); ?></h2>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="pwpm-box">
                <input type="hidden" name="action" value="pwpm_save_lease">
                <input type="hidden" name="lease_id" value="<?php echo (int) ( $l->id ?? 0 ); ?>">
                <?php wp_nonce_field( 'pwpm_save_lease' ); ?>
                <p><label><?php esc_html_e( 'Unit', 'realwise' ); ?><br>
                    <select name="unit_id" required>
                        <option value=""><?php esc_html_e( '— Select unit —', 'realwise' ); ?></option>
                        <?php foreach ( $all_units as $u ) : ?>
                        <option value="<?php echo (int) $u->id; ?>" <?php selected( $l->unit_id ?? 0, $u->id ); ?>><?php echo esc_html( $u->property_name . ' — ' . $u->label ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label></p>
                <p><label><?php esc_html_e( 'Tenant name', 'realwise' ); ?><br><input type="text" name="tenant_name" value="<?php echo esc_attr( $l->tenant_name ?? '' ); ?>" class="regular-text"></label></p>
                <p><label><?php esc_html_e( 'Tenant email', 'realwise' ); ?><br><input type="email" name="tenant_email" value="<?php echo esc_attr( $l->tenant_email ?? '' ); ?>" class="regular-text">
                   <span class="description"><?php esc_html_e( 'A tenant portal login is auto-created from this email.', 'realwise' ); ?></span></label></p>
                <p><label><?php esc_html_e( 'Tenant phone', 'realwise' ); ?><br><input type="text" name="tenant_phone" value="<?php echo esc_attr( $l->tenant_phone ?? '' ); ?>"></label></p>
                <p>
                    <label><?php esc_html_e( 'Rent', 'realwise' ); ?> <input type="number" name="rent_amount" value="<?php echo esc_attr( $l->rent_amount ?? '' ); ?>" step="25" class="small-text"></label>
                    <label><?php esc_html_e( 'Deposit', 'realwise' ); ?> <input type="number" name="deposit" value="<?php echo esc_attr( $l->deposit ?? '' ); ?>" step="25" class="small-text"></label>
                    <label><?php esc_html_e( 'Due day', 'realwise' ); ?> <input type="number" name="due_day" value="<?php echo esc_attr( $l->due_day ?? 1 ); ?>" min="1" max="28" class="small-text"></label>
                </p>
                <p>
                    <label><?php esc_html_e( 'Start', 'realwise' ); ?> <input type="date" name="start_date" value="<?php echo esc_attr( $l->start_date ?? '' ); ?>"></label>
                    <label><?php esc_html_e( 'End', 'realwise' ); ?> <input type="date" name="end_date" value="<?php echo esc_attr( $l->end_date ?? '' ); ?>"></label>
                </p>
                <p><label><?php esc_html_e( 'Status', 'realwise' ); ?><br>
                    <select name="status">
                        <?php foreach ( [ 'active', 'ended', 'pending' ] as $rw_row ) : ?>
                        <option value="<?php echo esc_attr( $rw_row ); ?>" <?php selected( $l->status ?? 'active', $rw_row ); ?>><?php echo esc_html( ucfirst( $rw_row ) ); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label></p>
                <button class="button button-primary"><?php esc_html_e( 'Save Lease', 'realwise' ); ?></button>
            </form>
        </div>

        <div>
            <h2><?php esc_html_e( 'All Leases', 'realwise' ); ?></h2>
            <table class="widefat striped">
                <thead><tr><th><?php esc_html_e( 'Tenant', 'realwise' ); ?></th><th><?php esc_html_e( 'Property / Unit', 'realwise' ); ?></th><th><?php esc_html_e( 'Rent', 'realwise' ); ?></th><th><?php esc_html_e( 'Status', 'realwise' ); ?></th><th></th></tr></thead>
                <tbody>
                <?php if ( $leases ) : foreach ( $leases as $row ) : ?>
                <tr>
                    <td><strong><?php echo esc_html( $row->tenant_name ?: '—' ); ?></strong><br><span class="description"><?php echo esc_html( $row->tenant_email ); ?></span></td>
                    <td><?php echo esc_html( $row->property_name . ' — ' . $row->unit_label ); ?></td>
                    <td><?php echo esc_html( PWPM_Rent::money( $row->rent_amount ) ); ?></td>
                    <td><span class="pwpm-pill pwpm-pill--<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
                    <td><a href="<?php echo esc_url( add_query_arg( [ 'page' => 'pwpm-leases', 'lease' => $row->id ], admin_url( 'admin.php' ) ) ); ?>" class="button button-small"><?php esc_html_e( 'Edit', 'realwise' ); ?></a></td>
                </tr>
                <?php endforeach; else : ?>
                <tr><td colspan="5"><?php esc_html_e( 'No leases yet.', 'realwise' ); ?></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
