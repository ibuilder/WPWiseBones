<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwpm-admin">
    <h1><?php esc_html_e( 'Property Management Settings', 'realwise' ); ?></h1>

    <div class="notice notice-info inline"><p>
        <strong><?php esc_html_e( 'Online rent payments are optional.', 'realwise' ); ?></strong>
        <?php esc_html_e( 'Add your Stripe keys below to let tenants pay rent online. Without them, the system still works — managers mark payments paid manually from the Rent Roll.', 'realwise' ); ?>
    </p></div>

    <form method="post" action="options.php">
        <?php settings_fields( 'pwpm_settings_group' ); ?>
        <h2><?php esc_html_e( 'Stripe', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Publishable key', 'realwise' ); ?></th><td><input type="text" name="pwpm_stripe_pk" value="<?php echo esc_attr( get_option( 'pwpm_stripe_pk', '' ) ); ?>" class="regular-text" placeholder="pk_live_…"></td></tr>
            <tr><th><?php esc_html_e( 'Secret key', 'realwise' ); ?></th><td><input type="password" name="pwpm_stripe_sk" value="<?php echo esc_attr( get_option( 'pwpm_stripe_sk', '' ) ); ?>" class="regular-text" autocomplete="new-password" placeholder="sk_live_…"></td></tr>
            <tr><th><?php esc_html_e( 'Webhook signing secret', 'realwise' ); ?></th><td>
                <input type="password" name="pwpm_stripe_wh_secret" value="<?php echo esc_attr( get_option( 'pwpm_stripe_wh_secret', '' ) ); ?>" class="regular-text" autocomplete="new-password" placeholder="whsec_…">
                <p class="description"><?php esc_html_e( 'Point your Stripe webhook at:', 'realwise' ); ?> <code><?php echo esc_url( home_url( '/?pwpm_webhook=1' ) ); ?></code> <?php esc_html_e( '(event: checkout.session.completed)', 'realwise' ); ?></p>
            </td></tr>
            <tr><th><?php esc_html_e( 'Currency', 'realwise' ); ?></th><td><input type="text" name="pwpm_currency" value="<?php echo esc_attr( get_option( 'pwpm_currency', 'usd' ) ); ?>" class="small-text" maxlength="3"></td></tr>
        </table>

        <h2><?php esc_html_e( 'Late Fees', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Enable late fees', 'realwise' ); ?></th><td>
                <label><input type="checkbox" name="pwpm_late_fee_enabled" value="1" <?php checked( get_option( 'pwpm_late_fee_enabled', 0 ), 1 ); ?>> <?php esc_html_e( 'Automatically add a late fee to overdue rent', 'realwise' ); ?></label>
            </td></tr>
            <tr><th><?php esc_html_e( 'Grace period (days)', 'realwise' ); ?></th><td><input type="number" name="pwpm_late_grace_days" value="<?php echo esc_attr( get_option( 'pwpm_late_grace_days', 5 ) ); ?>" class="small-text" min="0" max="31"></td></tr>
            <tr><th><?php esc_html_e( 'Flat fee', 'realwise' ); ?></th><td><input type="number" name="pwpm_late_fee_flat" value="<?php echo esc_attr( get_option( 'pwpm_late_fee_flat', 0 ) ); ?>" class="small-text" step="5" min="0"></td></tr>
            <tr><th><?php esc_html_e( 'Percent of rent (%)', 'realwise' ); ?></th><td><input type="number" name="pwpm_late_fee_pct" value="<?php echo esc_attr( get_option( 'pwpm_late_fee_pct', 0 ) ); ?>" class="small-text" step="0.5" min="0" max="25">
                <p class="description"><?php esc_html_e( 'Total late fee = flat + percent of the rent amount. Applied once per overdue charge.', 'realwise' ); ?></p></td></tr>
        </table>

        <h2><?php esc_html_e( 'Notifications', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Manager email', 'realwise' ); ?></th><td><input type="email" name="pwpm_manager_email" value="<?php echo esc_attr( get_option( 'pwpm_manager_email', get_option( 'admin_email' ) ) ); ?>" class="regular-text">
                <p class="description"><?php esc_html_e( 'Where maintenance request notifications are sent.', 'realwise' ); ?></p></td></tr>
            <tr><th><?php esc_html_e( 'Tenant Portal page ID', 'realwise' ); ?></th><td><input type="number" name="pwpm_portal_page_id" value="<?php echo esc_attr( get_option( 'pwpm_portal_page_id', '' ) ); ?>" class="small-text">
                <p class="description"><?php esc_html_e( 'The page containing', 'realwise' ); ?> <code>[pwpm_tenant_portal]</code> <?php esc_html_e( '— linked in rent reminder emails.', 'realwise' ); ?></p></td></tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>
