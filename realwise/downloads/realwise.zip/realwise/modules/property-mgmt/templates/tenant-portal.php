<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwpm-portal" data-lease="<?php echo (int) $lease->id; ?>">
    <h2 class="pwpm-h2"><?php esc_html_e( 'Tenant Portal', 'realwise' ); ?></h2>

    <?php if ( isset( $_GET['pwpm_paid'] ) ) : ?>
    <div class="pwpm-notice pwpm-notice--ok"><?php esc_html_e( 'Payment received — thank you!', 'realwise' ); ?></div>
    <?php endif; ?>

    <div class="pwpm-portal-grid">
        <!-- Lease summary -->
        <div class="pwpm-card">
            <h3 class="pwpm-card__title"><?php esc_html_e( 'My Lease', 'realwise' ); ?></h3>
            <div class="pwpm-lease-prop"><?php echo esc_html( $lease->property_name ); ?> — <?php echo esc_html( $lease->unit_label ); ?></div>
            <div class="pwpm-lease-addr"><?php echo esc_html( $lease->property_address ); ?></div>
            <ul class="pwpm-kv">
                <li><span><?php esc_html_e( 'Monthly Rent', 'realwise' ); ?></span><strong><?php echo esc_html( PWPM_Rent::money( $lease->rent_amount ) ); ?></strong></li>
                <li><span><?php esc_html_e( 'Due Day', 'realwise' ); ?></span><strong><?php echo (int) $lease->due_day; ?></strong></li>
                <?php if ( $lease->end_date ) : ?>
                <li><span><?php esc_html_e( 'Lease Ends', 'realwise' ); ?></span><strong><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $lease->end_date ) ) ); ?></strong></li>
                <?php endif; ?>
            </ul>
        </div>

        <!-- Pay rent -->
        <div class="pwpm-card">
            <h3 class="pwpm-card__title"><?php esc_html_e( 'Pay Rent', 'realwise' ); ?></h3>
            <?php if ( $next_due ) : ?>
            <div class="pwpm-due">
                <div class="pwpm-due__amount"><?php echo esc_html( PWPM_Rent::money( $next_due->amount ) ); ?></div>
                <div class="pwpm-due__date"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'Due %s', 'realwise' ), esc_html( date_i18n( 'M j, Y', strtotime( $next_due->due_date ) ) ) ); ?></div>
            </div>
            <button class="pwpm-btn pwpm-btn--primary pwpm-pay-btn" data-payment="<?php echo (int) $next_due->id; ?>"><?php esc_html_e( 'Pay Now', 'realwise' ); ?></button>
            <div class="pwpm-pay-msg" id="pwpm-pay-msg"></div>
            <?php else : ?>
            <p class="pwpm-empty"><?php esc_html_e( 'You are all paid up. 🎉', 'realwise' ); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Payment history -->
    <div class="pwpm-card">
        <h3 class="pwpm-card__title"><?php esc_html_e( 'Payment History', 'realwise' ); ?></h3>
        <table class="pwpm-table">
            <thead><tr><th><?php esc_html_e( 'Period', 'realwise' ); ?></th><th><?php esc_html_e( 'Amount', 'realwise' ); ?></th><th><?php esc_html_e( 'Due', 'realwise' ); ?></th><th><?php esc_html_e( 'Status', 'realwise' ); ?></th></tr></thead>
            <tbody>
            <?php if ( $payments ) : foreach ( $payments as $p ) : ?>
            <tr>
                <td><?php echo esc_html( $p->period ?: '—' ); ?></td>
                <td><?php echo esc_html( PWPM_Rent::money( $p->amount ) ); ?></td>
                <td><?php echo $p->due_date ? esc_html( date_i18n( 'M j, Y', strtotime( $p->due_date ) ) ) : '—'; ?></td>
                <td><span class="pwpm-pill pwpm-pill--<?php echo esc_attr( $p->status ); ?>"><?php echo esc_html( ucfirst( $p->status ) ); ?></span></td>
            </tr>
            <?php endforeach; else : ?>
            <tr><td colspan="4" class="pwpm-empty"><?php esc_html_e( 'No payments recorded yet.', 'realwise' ); ?></td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Maintenance -->
    <div class="pwpm-card">
        <h3 class="pwpm-card__title"><?php esc_html_e( 'Maintenance Requests', 'realwise' ); ?></h3>
        <form class="pwpm-maint-form" id="pwpm-maint-form">
            <input type="text" name="title" placeholder="<?php esc_attr_e( 'What needs fixing?', 'realwise' ); ?>" required>
            <select name="priority">
                <option value="low"><?php esc_html_e( 'Low', 'realwise' ); ?></option>
                <option value="normal" selected><?php esc_html_e( 'Normal', 'realwise' ); ?></option>
                <option value="high"><?php esc_html_e( 'High', 'realwise' ); ?></option>
                <option value="urgent"><?php esc_html_e( 'Urgent', 'realwise' ); ?></option>
            </select>
            <textarea name="description" rows="2" placeholder="<?php esc_attr_e( 'Details (optional)', 'realwise' ); ?>"></textarea>
            <button type="submit" class="pwpm-btn pwpm-btn--primary"><?php esc_html_e( 'Submit Request', 'realwise' ); ?></button>
            <div class="pwpm-maint-msg" id="pwpm-maint-msg"></div>
        </form>
        <ul class="pwpm-maint-list" id="pwpm-maint-list">
            <?php foreach ( $maintenance as $rw_item ) : ?>
            <li>
                <span class="pwpm-maint-title"><?php echo esc_html( $rw_item->title ); ?></span>
                <span class="pwpm-pill pwpm-pill--<?php echo esc_attr( $rw_item->status ); ?>"><?php echo esc_html( PWPM_Maintenance::status_label( $rw_item->status ) ); ?></span>
                <span class="pwpm-maint-date"><?php echo esc_html( date_i18n( 'M j', strtotime( $rw_item->created_at ) ) ); ?></span>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
</div>
