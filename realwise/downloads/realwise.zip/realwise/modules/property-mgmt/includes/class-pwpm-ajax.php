<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWPM_Ajax — tenant payment + maintenance actions.
 */
class PWPM_Ajax {

    public static function init(): void {
        add_action( 'wp_ajax_pwpm_pay_rent',          [ __CLASS__, 'pay_rent' ] );
        add_action( 'wp_ajax_pwpm_submit_maintenance', [ __CLASS__, 'submit_maintenance' ] );
    }

    private static function guard(): \WP_User {
        if ( ! check_ajax_referer( 'pwpm_nonce', 'nonce', false ) || ! is_user_logged_in() ) {
            wp_send_json_error( [ 'message' => __( 'Access denied.', 'realwise' ) ], 403 );
        }
        return wp_get_current_user();
    }

    public static function pay_rent(): void {
        $user       = self::guard();
        $payment_id = (int) ( $_POST['payment_id'] ?? 0 );
        $payment    = PWPM_DB::get( PWPM_DB::payments_table(), $payment_id );
        if ( ! $payment ) wp_send_json_error( [ 'message' => __( 'Payment not found.', 'realwise' ) ] );

        $lease = PWPM_DB::get( PWPM_DB::leases_table(), (int) $payment->lease_id );
        // Ownership: the lease must belong to this tenant
        if ( ! $lease || (int) $lease->tenant_user_id !== $user->ID ) {
            wp_send_json_error( [ 'message' => __( 'This is not your payment.', 'realwise' ) ], 403 );
        }
        if ( $payment->status === 'paid' ) wp_send_json_error( [ 'message' => __( 'Already paid.', 'realwise' ) ] );

        if ( PWPM_Payments::stripe_enabled() ) {
            try {
                $checkout = PWPM_Payments::create_checkout( $payment, $lease );
                wp_send_json_success( [ 'redirect' => $checkout['url'] ] );
            } catch ( \Throwable $e ) {
                wp_send_json_error( [ 'message' => $e->getMessage() ] );
            }
        }
        // No Stripe: record intent to pay offline, manager confirms later
        wp_send_json_success( [ 'message' => __( 'Online payment is not enabled. Please pay your manager directly; they will mark this paid.', 'realwise' ), 'offline' => true ] );
    }

    public static function submit_maintenance(): void {
        $user  = self::guard();
        $lease = PWPM_DB::lease_for_tenant( $user->ID );
        if ( ! $lease ) wp_send_json_error( [ 'message' => __( 'No active lease.', 'realwise' ) ] );

        $title = sanitize_text_field( wp_unslash( $_POST['title'] ?? '' ) );
        if ( ! $title ) wp_send_json_error( [ 'message' => __( 'Please describe the issue.', 'realwise' ) ] );

        $id = PWPM_Maintenance::create( [
            'unit_id'        => (int) $lease->unit_id,
            'lease_id'       => (int) $lease->id,
            'tenant_user_id' => $user->ID,
            'title'          => $title,
            'description'    => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
            'priority'       => in_array( $_POST['priority'] ?? '', [ 'low', 'normal', 'high', 'urgent' ], true ) ? $_POST['priority'] : 'normal',
        ] );
        wp_send_json_success( [ 'request_id' => $id, 'message' => __( 'Request submitted. Your manager has been notified.', 'realwise' ) ] );
    }
}
