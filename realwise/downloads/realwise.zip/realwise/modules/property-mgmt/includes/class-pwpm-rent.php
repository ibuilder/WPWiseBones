<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWPM_Rent — recurring rent charge generation + reminders.
 *
 * A daily cron creates the current period's rent charge (status=pending) for
 * each active lease on/after its due day, and emails reminders.
 */
class PWPM_Rent {

    public static function init(): void {
        add_action( 'pwpm_generate_rent', [ __CLASS__, 'generate' ] );
    }

    public static function ensure_scheduled(): void {
        if ( ! wp_next_scheduled( 'pwpm_generate_rent' ) ) {
            wp_schedule_event( strtotime( 'tomorrow 6am' ), 'daily', 'pwpm_generate_rent' );
        }
    }

    public static function clear_scheduled(): void {
        wp_clear_scheduled_hook( 'pwpm_generate_rent' );
    }

    public static function generate(): void {
        global $wpdb;
        $period = current_time( 'Y-m' );
        $today  = (int) current_time( 'j' );

        $leases = $wpdb->get_results(
            "SELECT * FROM " . PWPM_DB::leases_table() . " WHERE status = 'active' AND rent_amount > 0"
        );
        foreach ( $leases as $lease ) {
            if ( (int) $lease->due_day > $today ) continue; // not due yet this month

            // Already charged this period?
            $exists = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM " . PWPM_DB::payments_table() . " WHERE lease_id = %d AND period = %s AND type = 'rent'",
                $lease->id, $period
            ) );
            if ( $exists ) continue;

            $due_date = sprintf( '%s-%02d', $period, min( 28, max( 1, (int) $lease->due_day ) ) );
            PWPM_DB::insert( PWPM_DB::payments_table(), [
                'lease_id' => $lease->id,
                'amount'   => $lease->rent_amount,
                'type'     => 'rent',
                'status'   => 'pending',
                'due_date' => $due_date,
                'period'   => $period,
            ] );
            self::send_reminder( $lease, $lease->rent_amount, $due_date );
        }

        self::apply_late_fees();
    }

    /**
     * Add a one-time late fee to rent charges that are past their grace period
     * and still unpaid. Configurable amount/percent and grace days.
     */
    public static function apply_late_fees(): void {
        if ( ! get_option( 'pwpm_late_fee_enabled', 0 ) ) return;
        global $wpdb;
        $grace   = (int) get_option( 'pwpm_late_grace_days', 5 );
        $flat    = (float) get_option( 'pwpm_late_fee_flat', 0 );
        $pct     = (float) get_option( 'pwpm_late_fee_pct', 0 );
        $cutoff  = gmdate( 'Y-m-d', strtotime( current_time( 'mysql', true ) . " -{$grace} days" ) );

        $overdue = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . PWPM_DB::payments_table() . "
             WHERE type = 'rent' AND status = 'pending' AND due_date IS NOT NULL AND due_date < %s",
            $cutoff
        ) );
        foreach ( $overdue as $charge ) {
            // Already has a late fee for this period?
            $has = $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM " . PWPM_DB::payments_table() . " WHERE lease_id = %d AND period = %s AND type = 'late_fee'",
                $charge->lease_id, $charge->period
            ) );
            if ( $has ) continue;
            $fee = round( $flat + ( (float) $charge->amount * $pct / 100 ), 2 );
            if ( $fee <= 0 ) continue;
            PWPM_DB::insert( PWPM_DB::payments_table(), [
                'lease_id' => $charge->lease_id,
                'amount'   => $fee,
                'type'     => 'late_fee',
                'status'   => 'pending',
                'due_date' => $charge->due_date,
                'period'   => $charge->period,
            ] );
        }
    }

    private static function send_reminder( object $lease, float $amount, string $due_date ): void {
        if ( ! $lease->tenant_email ) return;
        $portal = get_option( 'pwpm_portal_page_id' ) ? get_permalink( (int) get_option( 'pwpm_portal_page_id' ) ) : home_url();
        /* translators: %s and %d are dynamic values inserted at runtime. */
        $subject = sprintf( esc_html__( 'Rent due: %s', 'realwise' ), date_i18n( 'F Y', strtotime( $due_date ) ) );
        $body    = sprintf(
            __( "Hi %1\$s,\n\nYour rent of %2\$s is due on %3\$s.\n\nPay online: %4\$s\n\nThank you.", 'realwise' ),
            $lease->tenant_name ?: __( 'Tenant', 'realwise' ),
            self::money( $amount ),
            date_i18n( 'F j, Y', strtotime( $due_date ) ),
            $portal
        );
        wp_mail( $lease->tenant_email, $subject, $body );
    }

    public static function money( $amount ): string {
        $sym = function_exists( 'get_option' ) ? get_option( 'pwl_currency_symbol', '$' ) : '$';
        return $sym . number_format( (float) $amount, 2 );
    }

    /**
     * Owner statement: totals for a property over a period.
     */
    public static function owner_statement( int $property_id, string $period = '' ): array {
        global $wpdb;
        $period = $period ?: current_time( 'Y-m' );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT pay.* FROM " . PWPM_DB::payments_table() . " pay
             JOIN " . PWPM_DB::leases_table() . " l ON pay.lease_id = l.id
             JOIN " . PWPM_DB::units_table() . " u ON l.unit_id = u.id
             WHERE u.property_id = %d AND pay.period = %s",
            $property_id, $period
        ) );
        $collected = 0; $pending = 0;
        foreach ( $rows as $r ) {
            if ( $r->status === 'paid' ) $collected += (float) $r->amount;
            else                          $pending   += (float) $r->amount;
        }
        return [ 'period' => $period, 'collected' => $collected, 'pending' => $pending, 'payments' => $rows ];
    }
}
