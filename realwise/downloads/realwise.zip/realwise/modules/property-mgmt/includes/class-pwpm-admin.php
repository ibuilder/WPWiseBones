<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWPM_Admin — landlord/manager back office.
 */
class PWPM_Admin {

    public static function init(): void {
        add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
        // CRUD handlers
        add_action( 'admin_post_pwpm_save_property',  [ __CLASS__, 'save_property' ] );
        add_action( 'admin_post_pwpm_save_unit',      [ __CLASS__, 'save_unit' ] );
        add_action( 'admin_post_pwpm_save_lease',     [ __CLASS__, 'save_lease' ] );
        add_action( 'admin_post_pwpm_mark_paid',      [ __CLASS__, 'mark_paid' ] );
        add_action( 'admin_post_pwpm_maint_status',   [ __CLASS__, 'maint_status' ] );
    }

    public static function menu(): void {
        add_menu_page( 'Property Mgmt', __( 'Properties', 'realwise' ), 'manage_options', 'pwpm-properties', [ __CLASS__, 'page_properties' ], 'dashicons-admin-multisite', 58 );
        add_submenu_page( 'pwpm-properties', __( 'Properties', 'realwise' ),  __( 'Properties', 'realwise' ),  'manage_options', 'pwpm-properties',  [ __CLASS__, 'page_properties' ] );
        add_submenu_page( 'pwpm-properties', __( 'Leases', 'realwise' ),      __( 'Leases', 'realwise' ),      'manage_options', 'pwpm-leases',      [ __CLASS__, 'page_leases' ] );
        add_submenu_page( 'pwpm-properties', __( 'Rent Roll', 'realwise' ),   __( 'Rent Roll', 'realwise' ),   'manage_options', 'pwpm-rent',        [ __CLASS__, 'page_rent' ] );
        add_submenu_page( 'pwpm-properties', __( 'Maintenance', 'realwise' ), __( 'Maintenance', 'realwise' ), 'manage_options', 'pwpm-maintenance', [ __CLASS__, 'page_maintenance' ] );
        add_submenu_page( 'pwpm-properties', __( 'Settings', 'realwise' ),    __( 'Settings', 'realwise' ),    'manage_options', 'pwpm-settings',    [ __CLASS__, 'page_settings' ] );
    }

    public static function register_settings(): void {
        foreach ( [ 'pwpm_stripe_pk', 'pwpm_stripe_sk', 'pwpm_stripe_wh_secret', 'pwpm_currency', 'pwpm_manager_email', 'pwpm_portal_page_id',
                    'pwpm_late_fee_enabled', 'pwpm_late_grace_days', 'pwpm_late_fee_flat', 'pwpm_late_fee_pct' ] as $k ) {
            register_setting( 'pwpm_settings_group', $k, [ 'sanitize_callback' => 'sanitize_text_field' ] );
        }
    }

    public static function assets( string $hook ): void {
        if ( strpos( $hook, 'pwpm' ) === false ) return;
        wp_enqueue_style( 'pwpm-admin', PWPM_URL . 'assets/css/admin.css', [], PWPM_VERSION );
    }

    // ── Pages ────────────────────────────────────────────────────────────────
    public static function page_properties(): void {
        $edit_id    = isset( $_GET['property'] ) ? (int) $_GET['property'] : 0;
        $editing    = $edit_id ? PWPM_DB::get( PWPM_DB::properties_table(), $edit_id ) : null;
        $properties = PWPM_DB::properties();
        $units      = $edit_id ? PWPM_DB::units( $edit_id ) : [];
        include PWPM_DIR . 'templates/admin/properties.php';
    }

    public static function page_leases(): void {
        global $wpdb;
        $leases = $wpdb->get_results(
            "SELECT l.*, u.label AS unit_label, p.name AS property_name
             FROM " . PWPM_DB::leases_table() . " l
             JOIN " . PWPM_DB::units_table() . " u ON l.unit_id = u.id
             JOIN " . PWPM_DB::properties_table() . " p ON u.property_id = p.id
             ORDER BY l.status ASC, l.id DESC"
        );
        $edit_id = isset( $_GET['lease'] ) ? (int) $_GET['lease'] : 0;
        $editing = $edit_id ? PWPM_DB::get( PWPM_DB::leases_table(), $edit_id ) : null;
        // Units for the new-lease dropdown
        $all_units = $wpdb->get_results(
            "SELECT u.id, u.label, p.name AS property_name FROM " . PWPM_DB::units_table() . " u
             JOIN " . PWPM_DB::properties_table() . " p ON u.property_id = p.id ORDER BY p.name, u.label"
        );
        include PWPM_DIR . 'templates/admin/leases.php';
    }

    public static function page_rent(): void {
        global $wpdb;
        $period = sanitize_text_field( wp_unslash( $_GET['period'] ?? current_time( 'Y-m' ) ) );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT pay.*, l.tenant_name, u.label AS unit_label, p.name AS property_name
             FROM " . PWPM_DB::payments_table() . " pay
             JOIN " . PWPM_DB::leases_table() . " l ON pay.lease_id = l.id
             JOIN " . PWPM_DB::units_table() . " u ON l.unit_id = u.id
             JOIN " . PWPM_DB::properties_table() . " p ON u.property_id = p.id
             WHERE pay.period = %s ORDER BY pay.status ASC, p.name", $period
        ) );
        $collected = 0; $pending = 0;
        foreach ( $rows as $r ) { $r->status === 'paid' ? $collected += (float) $r->amount : $pending += (float) $r->amount; }
        include PWPM_DIR . 'templates/admin/rent.php';
    }

    public static function page_maintenance(): void {
        global $wpdb;
        $status = sanitize_key( wp_unslash( $_GET['status'] ?? '' ) );
        $reqs = $wpdb->get_results( $wpdb->prepare(
            "SELECT m.*, u.label AS unit_label, p.name AS property_name
             FROM " . PWPM_DB::maintenance_table() . " m
             JOIN " . PWPM_DB::units_table() . " u ON m.unit_id = u.id
             JOIN " . PWPM_DB::properties_table() . " p ON u.property_id = p.id
             " . ( $status ? 'WHERE m.status = %s' : '' ) . " ORDER BY m.created_at DESC LIMIT 200",
            $status ?: 'x'
        ) );
        include PWPM_DIR . 'templates/admin/maintenance.php';
    }

    public static function page_settings(): void {
        include PWPM_DIR . 'templates/admin/settings.php';
    }

    // ── Handlers ─────────────────────────────────────────────────────────────
    public static function save_property(): void {
        self::can();
        check_admin_referer( 'pwpm_save_property' );
        $id   = (int) ( $_POST['property_id'] ?? 0 );
        $data = [
            'name'     => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
            'address'  => sanitize_text_field( wp_unslash( $_POST['address'] ?? '' ) ),
            'city'     => sanitize_text_field( wp_unslash( $_POST['city'] ?? '' ) ),
            'state'    => strtoupper( sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ) ) ),
            'zip_code' => sanitize_text_field( wp_unslash( $_POST['zip_code'] ?? '' ) ),
            'owner_id' => (int) ( $_POST['owner_id'] ?? 0 ) ?: null,
        ];
        $id ? PWPM_DB::update( PWPM_DB::properties_table(), $id, $data ) : $id = PWPM_DB::insert( PWPM_DB::properties_table(), $data );
        self::redirect( 'pwpm-properties', [ 'property' => $id, 'msg' => 'saved' ] );
    }

    public static function save_unit(): void {
        self::can();
        check_admin_referer( 'pwpm_save_unit' );
        $id   = (int) ( $_POST['unit_id'] ?? 0 );
        $pid  = (int) ( $_POST['property_id'] ?? 0 );
        $data = [
            'property_id' => $pid,
            'label'       => sanitize_text_field( wp_unslash( $_POST['label'] ?? 'Unit' ) ),
            'bedrooms'    => ( $_POST['bedrooms'] ?? '' ) !== '' ? (int) $_POST['bedrooms'] : null,
            'bathrooms'   => ( $_POST['bathrooms'] ?? '' ) !== '' ? (float) $_POST['bathrooms'] : null,
            'sqft'        => ( $_POST['sqft'] ?? '' ) !== '' ? (int) $_POST['sqft'] : null,
            'market_rent' => ( $_POST['market_rent'] ?? '' ) !== '' ? (float) $_POST['market_rent'] : null,
        ];
        $id ? PWPM_DB::update( PWPM_DB::units_table(), $id, $data ) : PWPM_DB::insert( PWPM_DB::units_table(), $data );
        self::redirect( 'pwpm-properties', [ 'property' => $pid, 'msg' => 'unit_saved' ] );
    }

    public static function save_lease(): void {
        self::can();
        check_admin_referer( 'pwpm_save_lease' );
        $id    = (int) ( $_POST['lease_id'] ?? 0 );
        $email = sanitize_email( wp_unslash( $_POST['tenant_email'] ?? '' ) );
        $name  = sanitize_text_field( wp_unslash( $_POST['tenant_name'] ?? '' ) );
        // Create a tenant WP user so they can log into the portal
        $tenant_uid = $email ? PWPM_Roles::ensure_tenant_user( $email, $name ) : 0;

        $data = [
            'unit_id'        => (int) ( $_POST['unit_id'] ?? 0 ),
            'tenant_user_id' => $tenant_uid ?: null,
            'tenant_name'    => $name,
            'tenant_email'   => $email ?: null,
            'tenant_phone'   => sanitize_text_field( wp_unslash( $_POST['tenant_phone'] ?? '' ) ) ?: null,
            'rent_amount'    => (float) ( $_POST['rent_amount'] ?? 0 ),
            'deposit'        => (float) ( $_POST['deposit'] ?? 0 ),
            'due_day'        => max( 1, min( 28, (int) ( $_POST['due_day'] ?? 1 ) ) ),
            'start_date'     => $_POST['start_date'] ? sanitize_text_field( wp_unslash( $_POST['start_date'] ) ) : null,
            'end_date'       => $_POST['end_date'] ? sanitize_text_field( wp_unslash( $_POST['end_date'] ) ) : null,
            'status'         => sanitize_key( wp_unslash( $_POST['status'] ?? 'active' ) ),
        ];
        if ( $id ) {
            PWPM_DB::update( PWPM_DB::leases_table(), $id, $data );
        } else {
            $id = PWPM_DB::insert( PWPM_DB::leases_table(), $data );
        }
        // Mark the unit occupied
        if ( $data['status'] === 'active' && $data['unit_id'] ) {
            PWPM_DB::update( PWPM_DB::units_table(), $data['unit_id'], [ 'status' => 'occupied' ] );
        }
        self::redirect( 'pwpm-leases', [ 'msg' => 'saved' ] );
    }

    public static function mark_paid(): void {
        self::can();
        check_admin_referer( 'pwpm_mark_paid' );
        PWPM_Payments::mark_paid( (int) ( $_GET['payment'] ?? 0 ), 'manual' );
        self::redirect( 'pwpm-rent', [ 'period' => sanitize_text_field( wp_unslash( $_GET['period'] ?? current_time( 'Y-m' ) ) ), 'msg' => 'paid' ] );
    }

    public static function maint_status(): void {
        self::can();
        check_admin_referer( 'pwpm_maint_status' );
        PWPM_Maintenance::set_status( (int) ( $_GET['req'] ?? 0 ), sanitize_key( wp_unslash( $_GET['to'] ?? 'open' ) ) );
        self::redirect( 'pwpm-maintenance', [ 'msg' => 'updated' ] );
    }

    private static function can(): void { if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Denied' ); }
    private static function redirect( string $page, array $args = [] ): void {
        wp_safe_redirect( add_query_arg( array_merge( [ 'page' => $page ], $args ), admin_url( 'admin.php' ) ) );
        exit;
    }
}
