<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWPM_Roles — tenant role + helpers.
 */
class PWPM_Roles {

    const ROLE = 'realwise_tenant';

    public static function add_role(): void {
        add_role( self::ROLE, __( 'Tenant', 'realwise' ), [ 'read' => true, 'pwpm_tenant' => true ] );
    }

    public static function remove_role(): void {
        remove_role( self::ROLE );
    }

    public static function is_tenant( ?int $user_id = null ): bool {
        $user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
        return $user && in_array( self::ROLE, (array) $user->roles, true );
    }

    /**
     * Create or fetch a tenant WP user for a lease, by email.
     */
    public static function ensure_tenant_user( string $email, string $name ): int {
        if ( ! $email ) return 0;
        $user = get_user_by( 'email', $email );
        if ( $user ) {
            $u = new WP_User( $user->ID );
            if ( ! in_array( self::ROLE, (array) $u->roles, true ) ) $u->add_role( self::ROLE );
            return $user->ID;
        }
        $uid = wp_insert_user( [
            'user_login' => sanitize_user( current( explode( '@', $email ) ) . '_' . wp_rand( 100, 999 ) ),
            'user_email' => $email,
            'display_name' => $name ?: $email,
            'user_pass'  => wp_generate_password( 16 ),
            'role'       => self::ROLE,
        ] );
        if ( is_wp_error( $uid ) ) return 0;
        // Send the tenant a set-password / welcome email
        wp_new_user_notification( $uid, null, 'user' );
        return $uid;
    }
}
