<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWPM_Shortcodes
 *   [pwpm_tenant_portal]  — tenant dashboard: lease, rent payment, maintenance.
 */
class PWPM_Shortcodes {

    public static function init(): void {
        add_shortcode( 'pwpm_tenant_portal', [ __CLASS__, 'render_portal' ] );
    }

    public static function render_portal(): string {
        if ( ! is_user_logged_in() ) {
            return '<div class="pwpm-gate"><p>' . esc_html__( 'Please log in to access your tenant portal.', 'realwise' ) . '</p>'
                 . '<a class="pwpm-btn pwpm-btn--primary" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">' . esc_html__( 'Log in', 'realwise' ) . '</a></div>';
        }
        $user  = wp_get_current_user();
        $lease = PWPM_DB::lease_for_tenant( $user->ID );
        if ( ! $lease ) {
            return '<div class="pwpm-gate"><p>' . esc_html__( 'No active lease is linked to your account. Please contact your property manager.', 'realwise' ) . '</p></div>';
        }
        $payments    = PWPM_DB::payments_for_lease( (int) $lease->id );
        $maintenance = PWPM_DB::maintenance_for_unit( (int) $lease->unit_id );
        $next_due    = null;
        foreach ( $payments as $p ) { if ( $p->status === 'pending' ) { $next_due = $p; break; } }

        ob_start();
        include PWPM_DIR . 'templates/tenant-portal.php';
        return ob_get_clean();
    }
}
