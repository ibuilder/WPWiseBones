<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWPM_Maintenance — tenant maintenance requests.
 */
class PWPM_Maintenance {

    public static function create( array $data ): int {
        $id = PWPM_DB::insert( PWPM_DB::maintenance_table(), $data );
        self::notify_manager( $id );
        return $id;
    }

    public static function set_status( int $id, string $status ): void {
        PWPM_DB::update( PWPM_DB::maintenance_table(), $id, [ 'status' => $status ] );
    }

    public static function status_label( string $s ): string {
        return [
            'open'        => __( 'Open', 'realwise' ),
            'in_progress' => __( 'In Progress', 'realwise' ),
            'resolved'    => __( 'Resolved', 'realwise' ),
            'closed'      => __( 'Closed', 'realwise' ),
        ][ $s ] ?? ucfirst( $s );
    }

    public static function priority_label( string $p ): string {
        return [
            'low'    => __( 'Low', 'realwise' ),
            'normal' => __( 'Normal', 'realwise' ),
            'high'   => __( 'High', 'realwise' ),
            'urgent' => __( 'Urgent', 'realwise' ),
        ][ $p ] ?? ucfirst( $p );
    }

    private static function notify_manager( int $id ): void {
        $req = PWPM_DB::get( PWPM_DB::maintenance_table(), $id );
        if ( ! $req ) return;
        $to = get_option( 'pwpm_manager_email', get_option( 'admin_email' ) );
        /* translators: %s and %d are dynamic values inserted at runtime. */
        $subject = sprintf( esc_html__( 'New maintenance request: %s', 'realwise' ), $req->title );
        $body    = sprintf(
            __( "Priority: %1\$s\nUnit: #%2\$d\n\n%3\$s", 'realwise' ),
            self::priority_label( $req->priority ), $req->unit_id, $req->description
        );
        wp_mail( $to, $subject, $body );
    }
}
