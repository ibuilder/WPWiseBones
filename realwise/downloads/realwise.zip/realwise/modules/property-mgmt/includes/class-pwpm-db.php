<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWPM_DB — schema and helpers for Property Management.
 */
class PWPM_DB {

    public static function properties_table()  { global $wpdb; return $wpdb->prefix . 'pwpm_properties'; }
    public static function units_table()        { global $wpdb; return $wpdb->prefix . 'pwpm_units'; }
    public static function leases_table()       { global $wpdb; return $wpdb->prefix . 'pwpm_leases'; }
    public static function payments_table()     { global $wpdb; return $wpdb->prefix . 'pwpm_payments'; }
    public static function maintenance_table()  { global $wpdb; return $wpdb->prefix . 'pwpm_maintenance'; }

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::properties_table() . " (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            owner_id    BIGINT UNSIGNED DEFAULT NULL,
            listing_id  BIGINT UNSIGNED DEFAULT NULL,
            name        VARCHAR(190) NOT NULL,
            address     VARCHAR(255) DEFAULT NULL,
            city        VARCHAR(80)  DEFAULT NULL,
            state       VARCHAR(4)   DEFAULT NULL,
            zip_code    VARCHAR(12)  DEFAULT NULL,
            created_at  DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY owner_id (owner_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::units_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            property_id   BIGINT UNSIGNED NOT NULL,
            label         VARCHAR(80) NOT NULL DEFAULT 'Unit',
            bedrooms      TINYINT UNSIGNED DEFAULT NULL,
            bathrooms     DECIMAL(4,1) DEFAULT NULL,
            sqft          MEDIUMINT UNSIGNED DEFAULT NULL,
            market_rent   DECIMAL(10,2) DEFAULT NULL,
            status        VARCHAR(16) DEFAULT 'vacant',
            PRIMARY KEY (id),
            KEY property_id (property_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::leases_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            unit_id       BIGINT UNSIGNED NOT NULL,
            tenant_user_id BIGINT UNSIGNED DEFAULT NULL,
            tenant_name   VARCHAR(190) DEFAULT NULL,
            tenant_email  VARCHAR(190) DEFAULT NULL,
            tenant_phone  VARCHAR(40)  DEFAULT NULL,
            rent_amount   DECIMAL(10,2) NOT NULL DEFAULT 0,
            deposit       DECIMAL(10,2) DEFAULT 0,
            due_day       TINYINT       DEFAULT 1,
            start_date    DATE DEFAULT NULL,
            end_date      DATE DEFAULT NULL,
            status        VARCHAR(16) DEFAULT 'active',
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY unit_id (unit_id),
            KEY tenant_user_id (tenant_user_id),
            KEY status (status)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::payments_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            lease_id      BIGINT UNSIGNED NOT NULL,
            amount        DECIMAL(10,2) NOT NULL,
            type          VARCHAR(20) DEFAULT 'rent',
            status        VARCHAR(16) DEFAULT 'pending',
            method        VARCHAR(20) DEFAULT NULL,
            txn_id        VARCHAR(120) DEFAULT NULL,
            due_date      DATE DEFAULT NULL,
            paid_date     DATETIME DEFAULT NULL,
            period        VARCHAR(7) DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY lease_id (lease_id),
            KEY status (status),
            KEY period (period)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::maintenance_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            unit_id       BIGINT UNSIGNED NOT NULL,
            lease_id      BIGINT UNSIGNED DEFAULT NULL,
            tenant_user_id BIGINT UNSIGNED DEFAULT NULL,
            title         VARCHAR(190) NOT NULL,
            description   TEXT,
            priority      VARCHAR(12) DEFAULT 'normal',
            status        VARCHAR(16) DEFAULT 'open',
            photo_url     VARCHAR(255) DEFAULT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY unit_id (unit_id),
            KEY status (status)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) dbDelta( $q );
        update_option( 'pwpm_db_version', PWPM_VERSION );
    }

    // ── Generic CRUD helpers ─────────────────────────────────────────────────
    public static function insert( string $table, array $data ): int {
        global $wpdb;
        $wpdb->insert( $table, $data );
        return $wpdb->insert_id;
    }
    public static function update( string $table, int $id, array $data ): void {
        global $wpdb;
        $wpdb->update( $table, $data, [ 'id' => $id ] );
    }
    public static function get( string $table, int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ) );
    }
    public static function delete( string $table, int $id ): void {
        global $wpdb;
        $wpdb->delete( $table, [ 'id' => $id ] );
    }

    // ── Queries ──────────────────────────────────────────────────────────────
    public static function properties( int $owner_id = 0 ): array {
        global $wpdb;
        if ( $owner_id ) {
            return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::properties_table() . ' WHERE owner_id = %d ORDER BY name', $owner_id ) ) ?: [];
        }
        return $wpdb->get_results( 'SELECT * FROM ' . self::properties_table() . ' ORDER BY name' ) ?: [];
    }

    public static function units( int $property_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . self::units_table() . ' WHERE property_id = %d ORDER BY label', $property_id ) ) ?: [];
    }

    public static function active_lease_for_unit( int $unit_id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . self::leases_table() . " WHERE unit_id = %d AND status = 'active' ORDER BY id DESC LIMIT 1", $unit_id
        ) );
    }

    public static function lease_for_tenant( int $user_id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT l.*, u.label AS unit_label, p.name AS property_name, p.address AS property_address
             FROM " . self::leases_table() . " l
             JOIN " . self::units_table() . " u ON l.unit_id = u.id
             JOIN " . self::properties_table() . " p ON u.property_id = p.id
             WHERE l.tenant_user_id = %d AND l.status = 'active' ORDER BY l.id DESC LIMIT 1", $user_id
        ) );
    }

    public static function payments_for_lease( int $lease_id, int $limit = 24 ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::payments_table() . ' WHERE lease_id = %d ORDER BY COALESCE(due_date, created_at) DESC LIMIT %d',
            $lease_id, $limit
        ) ) ?: [];
    }

    public static function maintenance_for_unit( int $unit_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::maintenance_table() . ' WHERE unit_id = %d ORDER BY created_at DESC', $unit_id
        ) ) ?: [];
    }

    public static function all_maintenance( string $status = '' ): array {
        global $wpdb;
        if ( $status ) {
            return $wpdb->get_results( $wpdb->prepare(
                'SELECT * FROM ' . self::maintenance_table() . ' WHERE status = %s ORDER BY created_at DESC', $status
            ) ) ?: [];
        }
        return $wpdb->get_results( 'SELECT * FROM ' . self::maintenance_table() . ' ORDER BY created_at DESC LIMIT 200' ) ?: [];
    }
}
