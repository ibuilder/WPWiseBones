<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWPM_Payments — Stripe Checkout integration for online rent payment.
 *
 * Flow:
 *   1. Tenant clicks "Pay" → AJAX creates a Stripe Checkout Session.
 *   2. Tenant completes payment on Stripe-hosted page.
 *   3. Stripe webhook (checkout.session.completed) marks the payment paid.
 *
 * If no Stripe secret key is configured, the plugin falls back to a
 * "mark as paid manually" flow (offline / check / bank transfer) so the system
 * is fully usable without Stripe.
 */
class PWPM_Payments {

    public static function init(): void {
        // Stripe webhook endpoint: /?pwpm_webhook=1
        add_action( 'init', [ __CLASS__, 'maybe_handle_webhook' ] );
    }

    public static function stripe_enabled(): bool {
        return (bool) get_option( 'pwpm_stripe_sk' );
    }

    /**
     * Create a Stripe Checkout Session for a pending payment.
     * Returns [ 'url' => checkout_url ] or throws on error.
     */
    public static function create_checkout( object $payment, object $lease ): array {
        $sk = get_option( 'pwpm_stripe_sk' );
        if ( ! $sk ) throw new \RuntimeException( esc_html(  __( 'Stripe is not configured.', 'realwise' )  ) );

        $success = add_query_arg( 'pwpm_paid', $payment->id, home_url( '/' ) );
        $cancel  = add_query_arg( 'pwpm_cancel', 1, home_url( '/' ) );

        // Stripe expects amounts in the smallest currency unit (cents)
        $amount_cents = (int) round( (float) $payment->amount * 100 );

        $body = [
            'mode'                                 => 'payment',
            'success_url'                          => $success,
            'cancel_url'                           => $cancel,
            'client_reference_id'                  => (string) $payment->id,
            'line_items[0][quantity]'              => 1,
            'line_items[0][price_data][currency]'  => strtolower( get_option( 'pwpm_currency', 'usd' ) ),
            'line_items[0][price_data][unit_amount]' => $amount_cents,
            'line_items[0][price_data][product_data][name]' => sprintf(
                /* translators: %s and %d are dynamic values inserted at runtime. */
                __( 'Rent payment — %s', 'realwise' ), $payment->period ?: current_time( 'Y-m' )
            ),
            'metadata[payment_id]'                 => (string) $payment->id,
            'metadata[lease_id]'                   => (string) $lease->id,
        ];
        if ( $lease->tenant_email ) $body['customer_email'] = $lease->tenant_email;

        $resp = wp_remote_post( 'https://api.stripe.com/v1/checkout/sessions', [
            'headers' => [ 'Authorization' => 'Bearer ' . $sk ],
            'body'    => $body,
            'timeout' => 20,
        ] );
        if ( is_wp_error( $resp ) ) throw new \RuntimeException( esc_html(  $resp->get_error_message()  ) );
        $data = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( empty( $data['url'] ) ) {
            throw new \RuntimeException( esc_html(  $data['error']['message'] ?? __( 'Stripe error.', 'realwise' )  ) );
        }
        // Stash the session id so the webhook can correlate
        PWPM_DB::update( PWPM_DB::payments_table(), (int) $payment->id, [ 'txn_id' => $data['id'], 'method' => 'stripe' ] );
        return [ 'url' => $data['url'] ];
    }

    public static function mark_paid( int $payment_id, string $method = 'manual', ?string $txn = null ): void {
        PWPM_DB::update( PWPM_DB::payments_table(), $payment_id, [
            'status'    => 'paid',
            'method'    => $method,
            'txn_id'    => $txn,
            'paid_date' => current_time( 'mysql' ),
        ] );
    }

    /**
     * Handle Stripe webhook. Signature verification is performed if a webhook
     * secret is configured.
     */
    public static function maybe_handle_webhook(): void {
        if ( ! isset( $_GET['pwpm_webhook'] ) ) return;
        // Read the raw request body for Stripe signature verification (not a file).
        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $payload = file_get_contents( 'php://input' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents -- Raw request body for Stripe webhook signature verification.
        $secret  = get_option( 'pwpm_stripe_wh_secret' );

        // SECURITY: never trust an unsigned webhook. Without a configured signing
        // secret we cannot verify the request came from Stripe, so we refuse to
        // act on it — otherwise anyone could POST a fake "paid" event and clear
        // a rent charge for free.
        if ( ! $secret ) {
            status_header( 400 );
            echo 'webhook signing secret not configured';
            exit;
        }
        $sig = isset( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_STRIPE_SIGNATURE'] ) ) : '';
        if ( ! self::verify_signature( $payload, $sig, $secret ) ) {
            status_header( 400 ); echo 'bad signature'; exit;
        }

        $event = json_decode( $payload, true );
        if ( ( $event['type'] ?? '' ) === 'checkout.session.completed' ) {
            $session    = $event['data']['object'] ?? [];
            $payment_id = (int) ( $session['metadata']['payment_id'] ?? $session['client_reference_id'] ?? 0 );
            if ( $payment_id ) {
                self::mark_paid( $payment_id, 'stripe', $session['payment_intent'] ?? ( $session['id'] ?? null ) );
            }
        }
        status_header( 200 ); echo 'ok'; exit;
    }

    private static function verify_signature( string $payload, string $header, string $secret ): bool {
        // Minimal Stripe signature check (t=,v1=)
        $parts = [];
        foreach ( explode( ',', $header ) as $kv ) {
            [ $k, $v ] = array_pad( explode( '=', $kv, 2 ), 2, '' );
            $parts[ $k ] = $v;
        }
        if ( empty( $parts['t'] ) || empty( $parts['v1'] ) ) return false;
        // Replay protection: reject events whose timestamp is more than 5 minutes old.
        if ( abs( time() - (int) $parts['t'] ) > 5 * MINUTE_IN_SECONDS ) return false;
        $expected = hash_hmac( 'sha256', $parts['t'] . '.' . $payload, $secret );
        return hash_equals( $expected, $parts['v1'] );
    }
}
