<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWAP_Portal — data layer for the agent portal (scoped to the current agent).
 */
class PWAP_Portal {

    public static function my_listings( int $agent_id, array $args = [] ): array {
        if ( ! class_exists( 'PWL_DB' ) ) return [];
        global $wpdb;
        $args = wp_parse_args( $args, [ 'per_page' => 100, 'page' => 1 ] );
        $offset = ( max( 1, $args['page'] ) - 1 ) * $args['per_page'];
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . PWL_DB::listings_table() . ' WHERE agent_id = %d ORDER BY updated_at DESC LIMIT %d OFFSET %d',
            $agent_id, (int) $args['per_page'], $offset
        ) ) ?: [];
    }

    public static function listing_count( int $agent_id ): int {
        if ( ! class_exists( 'PWL_DB' ) ) return 0;
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare(
            'SELECT COUNT(*) FROM ' . PWL_DB::listings_table() . ' WHERE agent_id = %d', $agent_id
        ) );
    }

    public static function my_leads( int $agent_id ): array {
        if ( ! class_exists( 'PWC_DB' ) ) return [];
        return PWC_DB::get_leads( [ 'agent_id' => $agent_id, 'per_page' => 100 ] )['leads'];
    }

    public static function my_tasks( int $agent_id ): array {
        if ( ! class_exists( 'PWC_DB' ) ) return [];
        return PWC_DB::get_tasks( 0, $agent_id, true );
    }

    /**
     * Performance metrics for the dashboard tiles.
     */
    public static function stats( int $agent_id ): array {
        global $wpdb;
        $stats = [
            'listings'   => self::listing_count( $agent_id ),
            'active'     => 0,
            'leads'      => 0,
            'open_leads' => 0,
            'won'        => 0,
            'tasks'      => 0,
        ];
        if ( class_exists( 'PWL_DB' ) ) {
            $stats['active'] = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM " . PWL_DB::listings_table() . " WHERE agent_id = %d AND status = 'active'", $agent_id
            ) );
        }
        if ( class_exists( 'PWC_DB' ) ) {
            $stats['leads']      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . PWC_DB::leads_table() . " WHERE agent_id = %d", $agent_id ) );
            $stats['open_leads'] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . PWC_DB::leads_table() . " WHERE agent_id = %d AND stage NOT IN ('closed','lost')", $agent_id ) );
            $stats['won']        = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM " . PWC_DB::leads_table() . " WHERE agent_id = %d AND stage = 'closed'", $agent_id ) );
            $stats['tasks']      = count( PWC_DB::get_tasks( 0, $agent_id, true ) );
        }
        return $stats;
    }

    public static function agent_profile( int $agent_id ): ?object {
        if ( ! class_exists( 'PWL_DB' ) ) return null;
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM ' . PWL_DB::agents_table() . ' WHERE id = %d', $agent_id
        ) );
    }

    /** Verify an agent owns a given listing (security boundary for edits). */
    public static function owns_listing( int $agent_id, int $listing_id ): bool {
        if ( current_user_can( 'manage_options' ) ) return true;
        if ( ! class_exists( 'PWL_DB' ) ) return false;
        $listing = PWL_DB::get_listing( $listing_id );
        return $listing && (int) $listing->agent_id === $agent_id;
    }

    public static function owns_lead( int $agent_id, int $lead_id ): bool {
        if ( current_user_can( 'manage_options' ) ) return true;
        if ( ! class_exists( 'PWC_DB' ) ) return false;
        $lead = PWC_DB::get_lead( $lead_id );
        return $lead && (int) $lead->agent_id === $agent_id;
    }
}
