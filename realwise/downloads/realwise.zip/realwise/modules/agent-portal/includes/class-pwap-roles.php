<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWAP_Roles — the realwise_agent role and the user↔agent link.
 *
 * A WP user with role `realwise_agent` is linked to a RealWise Listings agent
 * row via user meta `pwap_agent_id`. That link is how the portal scopes
 * listings and leads to "this agent only".
 */
class PWAP_Roles {

    const ROLE = 'realwise_agent';

    public static function add_role(): void {
        add_role( self::ROLE, __( 'Real Estate Agent', 'realwise' ), [
            'read'              => true,
            'upload_files'      => true,
            'pwap_access'       => true,
            'pwap_edit_own'     => true,
        ] );
        // Let admins do everything an agent can
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->add_cap( 'pwap_access' );
            $admin->add_cap( 'pwap_edit_own' );
        }
    }

    public static function remove_role(): void {
        remove_role( self::ROLE );
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $admin->remove_cap( 'pwap_access' );
            $admin->remove_cap( 'pwap_edit_own' );
        }
    }

    public static function is_agent( ?int $user_id = null ): bool {
        $user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
        return $user && ( in_array( self::ROLE, (array) $user->roles, true ) || user_can( $user, 'manage_options' ) );
    }

    /**
     * The RealWise Listings agent_id linked to a WP user.
     * Admins editing the portal can pass ?agent_id=X.
     */
    public static function linked_agent_id( ?int $user_id = null ): int {
        $user_id = $user_id ?: get_current_user_id();
        $aid = (int) get_user_meta( $user_id, 'pwap_agent_id', true );
        if ( ! $aid && current_user_can( 'manage_options' ) && isset( $_GET['agent_id'] ) ) {
            $aid = (int) $_GET['agent_id'];
        }
        return $aid;
    }

    public static function set_linked_agent( int $user_id, int $agent_id ): void {
        update_user_meta( $user_id, 'pwap_agent_id', $agent_id );
    }
}
