<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWAP_Ajax — agent self-service actions, all scoped to the logged-in agent.
 */
class PWAP_Ajax {

    public static function init(): void {
        add_action( 'wp_ajax_pwap_save_listing',  [ __CLASS__, 'save_listing'  ] );
        add_action( 'wp_ajax_pwap_save_profile',  [ __CLASS__, 'save_profile'  ] );
        add_action( 'wp_ajax_pwap_lead_stage',    [ __CLASS__, 'lead_stage'    ] );
        add_action( 'wp_ajax_pwap_lead_note',     [ __CLASS__, 'lead_note'     ] );
    }

    private static function guard(): int {
        if ( ! check_ajax_referer( 'pwap_nonce', 'nonce', false ) || ! PWAP_Roles::is_agent() ) {
            wp_send_json_error( [ 'message' => __( 'Access denied.', 'realwise' ) ], 403 );
        }
        return PWAP_Roles::linked_agent_id();
    }

    public static function save_listing(): void {
        $agent_id   = self::guard();
        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );

        if ( $listing_id && ! PWAP_Portal::owns_listing( $agent_id, $listing_id ) ) {
            wp_send_json_error( [ 'message' => __( 'You do not own this listing.', 'realwise' ) ], 403 );
        }
        if ( ! class_exists( 'PWL_DB' ) ) wp_send_json_error( [ 'message' => 'RealWise Listings required.' ] );

        $data = [
            'list_price'  => (float) ( $_POST['list_price'] ?? 0 ),
            'status'      => sanitize_key( wp_unslash( $_POST['status'] ?? 'active' ) ),
            'address'     => sanitize_text_field( wp_unslash( $_POST['address'] ?? '' ) ),
            'city'        => sanitize_text_field( wp_unslash( $_POST['city'] ?? '' ) ),
            'state'       => strtoupper( sanitize_text_field( wp_unslash( $_POST['state'] ?? '' ) ) ),
            'zip_code'    => sanitize_text_field( wp_unslash( $_POST['zip_code'] ?? '' ) ),
            'bedrooms'    => ( $_POST['bedrooms'] ?? '' ) !== '' ? (int) $_POST['bedrooms'] : null,
            'bathrooms'   => ( $_POST['bathrooms'] ?? '' ) !== '' ? (float) $_POST['bathrooms'] : null,
            'sqft'        => ( $_POST['sqft'] ?? '' ) !== '' ? (int) $_POST['sqft'] : null,
            'description' => sanitize_textarea_field( wp_unslash( $_POST['description'] ?? '' ) ),
            'agent_id'    => $agent_id, // always pin to the editing agent
        ];
        $data = array_filter( $data, fn( $v ) => $v !== null );

        global $wpdb;
        if ( $listing_id ) {
            $wpdb->update( PWL_DB::listings_table(), $data, [ 'id' => $listing_id ] );
        } else {
            $data['mls_id'] = 'AGENT-' . $agent_id . '-' . uniqid();
            $wpdb->insert( PWL_DB::listings_table(), $data );
            $listing_id = $wpdb->insert_id;
        }
        if ( class_exists( 'PWL_Cache' ) ) PWL_Cache::flush();
        wp_send_json_success( [ 'listing_id' => $listing_id ] );
    }

    public static function save_profile(): void {
        $agent_id = self::guard();
        if ( ! $agent_id || ! class_exists( 'PWL_DB' ) ) wp_send_json_error( [ 'message' => __( 'No linked agent profile.', 'realwise' ) ] );
        global $wpdb;
        $wpdb->update( PWL_DB::agents_table(), [
            'name'        => sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) ),
            'email'       => sanitize_email( wp_unslash( $_POST['email'] ?? '' ) ) ?: null,
            'phone'       => sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) ) ?: null,
            'brokerage'   => sanitize_text_field( wp_unslash( $_POST['brokerage'] ?? '' ) ) ?: null,
            'license_num' => sanitize_text_field( wp_unslash( $_POST['license_num'] ?? '' ) ) ?: null,
            'photo_url'   => esc_url_raw( wp_unslash( $_POST['photo_url'] ?? '' ) ) ?: null,
            'bio'         => sanitize_textarea_field( wp_unslash( $_POST['bio'] ?? '' ) ) ?: null,
        ], [ 'id' => $agent_id ] );
        wp_send_json_success();
    }

    public static function lead_stage(): void {
        $agent_id = self::guard();
        $lead_id  = (int) ( $_POST['lead_id'] ?? 0 );
        if ( ! PWAP_Portal::owns_lead( $agent_id, $lead_id ) ) wp_send_json_error( [ 'message' => 'Denied' ], 403 );
        if ( class_exists( 'PWC_Leads' ) ) PWC_Leads::change_stage( $lead_id, sanitize_key( wp_unslash( $_POST['stage'] ?? '' ) ) );
        wp_send_json_success();
    }

    public static function lead_note(): void {
        $agent_id = self::guard();
        $lead_id  = (int) ( $_POST['lead_id'] ?? 0 );
        $note     = sanitize_textarea_field( wp_unslash( $_POST['note'] ?? '' ) );
        if ( ! PWAP_Portal::owns_lead( $agent_id, $lead_id ) || ! $note ) wp_send_json_error( [ 'message' => 'Denied' ], 403 );
        if ( class_exists( 'PWC_DB' ) ) PWC_DB::log_activity( $lead_id, 'note', $note );
        wp_send_json_success( [ 'when' => current_time( 'M j, g:i a' ) ] );
    }
}
