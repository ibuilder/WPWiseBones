<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWAP_Shortcodes
 *   [pwap_dashboard]  — the full agent portal (tabbed: overview, listings, leads, profile).
 */
class PWAP_Shortcodes {

    public static function init(): void {
        add_shortcode( 'pwap_dashboard', [ __CLASS__, 'render_dashboard' ] );
    }

    public static function render_dashboard( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<div class="pwap-gate"><p>' . esc_html__( 'Please log in to access the agent portal.', 'realwise' ) . '</p>'
                 . '<a class="pwap-btn pwap-btn--primary" href="' . esc_url( wp_login_url( get_permalink() ) ) . '">' . esc_html__( 'Log in', 'realwise' ) . '</a></div>';
        }
        if ( ! PWAP_Roles::is_agent() ) {
            return '<div class="pwap-gate"><p>' . esc_html__( 'This area is for agents only.', 'realwise' ) . '</p></div>';
        }

        $agent_id = PWAP_Roles::linked_agent_id();
        $tab      = sanitize_key( wp_unslash( $_GET['pwap_tab'] ?? 'overview' ) );
        $stats    = PWAP_Portal::stats( $agent_id );
        $profile  = PWAP_Portal::agent_profile( $agent_id );

        ob_start();
        include PWAP_DIR . 'templates/dashboard.php';
        return ob_get_clean();
    }
}
