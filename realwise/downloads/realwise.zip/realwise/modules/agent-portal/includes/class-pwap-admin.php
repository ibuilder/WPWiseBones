<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWAP_Admin — adds an "Agent Profile" link field to the WP user edit screen,
 * so admins can connect a WP user account to a RealWise Listings agent row.
 */
class PWAP_Admin {

    public static function init(): void {
        add_action( 'show_user_profile', [ __CLASS__, 'field' ] );
        add_action( 'edit_user_profile', [ __CLASS__, 'field' ] );
        add_action( 'personal_options_update',  [ __CLASS__, 'save' ] );
        add_action( 'edit_user_profile_update',  [ __CLASS__, 'save' ] );
    }

    public static function field( $user ): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( ! class_exists( 'PWL_DB' ) ) return;
        global $wpdb;
        $agents  = $wpdb->get_results( 'SELECT id, name FROM ' . PWL_DB::agents_table() . ' ORDER BY name ASC' );
        $current = (int) get_user_meta( $user->ID, 'pwap_agent_id', true );
        ?>
        <h2><?php esc_html_e( 'RealWise Agent Link', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr>
                <th><label for="pwap_agent_id"><?php esc_html_e( 'Linked agent profile', 'realwise' ); ?></label></th>
                <td>
                    <select name="pwap_agent_id" id="pwap_agent_id">
                        <option value="0"><?php esc_html_e( '— None —', 'realwise' ); ?></option>
                        <?php foreach ( $agents as $a ) : ?>
                        <option value="<?php echo (int) $a->id; ?>" <?php selected( $current, $a->id ); ?>><?php echo esc_html( $a->name ); ?> (#<?php echo (int) $a->id; ?>)</option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'Connect this user to a RealWise agent so the front-end Agent Portal shows their listings and leads. Give the user the "Real Estate Agent" role too.', 'realwise' ); ?></p>
                </td>
            </tr>
        </table>
        <?php
    }

    public static function save( int $user_id ): void {
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( isset( $_POST['pwap_agent_id'] ) ) {
            update_user_meta( $user_id, 'pwap_agent_id', (int) $_POST['pwap_agent_id'] );
        }
    }
}
