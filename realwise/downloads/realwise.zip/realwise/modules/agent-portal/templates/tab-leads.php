<?php if ( ! defined( 'ABSPATH' ) ) exit;
$lead_id = isset( $_GET['lead'] ) ? (int) $_GET['lead'] : 0;
if ( $lead_id && ! PWAP_Portal::owns_lead( $agent_id, $lead_id ) ) $lead_id = 0;

if ( $lead_id && class_exists( 'PWC_DB' ) ) :
    $lead     = PWC_DB::get_lead( $lead_id );
    $activity = PWC_DB::get_activity( $lead_id );
?>
<a href="<?php echo esc_url( add_query_arg( 'pwap_tab', 'leads', remove_query_arg( 'lead' ) ) ); ?>" class="pwap-back">&larr; <?php esc_html_e( 'Back to leads', 'realwise' ); ?></a>
<div class="pwap-lead-detail" data-lead="<?php echo (int) $lead_id; ?>">
    <h3 class="pwap-h3"><?php echo esc_html( $lead->name ?: $lead->email ?: __( 'Lead', 'realwise' ) ); ?></h3>
    <div class="pwap-lead-contact">
        <?php if ( $lead->email ) : ?><a href="mailto:<?php echo esc_attr( $lead->email ); ?>"><?php echo esc_html( $lead->email ); ?></a><?php endif; ?>
        <?php if ( $lead->phone ) : ?> · <a href="tel:<?php echo esc_attr( $lead->phone ); ?>"><?php echo esc_html( $lead->phone ); ?></a><?php endif; ?>
    </div>

    <label class="pwap-stage-select"><?php esc_html_e( 'Stage', 'realwise' ); ?>
        <select id="pwap-lead-stage">
            <?php foreach ( PWC_DB::STAGES as $st ) : ?>
            <option value="<?php echo esc_attr( $st ); ?>" <?php selected( $lead->stage, $st ); ?>><?php echo esc_html( PWC_Leads::stage_label( $st ) ); ?></option>
            <?php endforeach; ?>
        </select>
    </label>

    <?php if ( $lead->message ) : ?>
    <blockquote class="pwap-message"><?php echo nl2br( esc_html( $lead->message ) ); ?></blockquote>
    <?php endif; ?>

    <div class="pwap-note-add">
        <textarea id="pwap-note-input" rows="2" placeholder="<?php esc_attr_e( 'Log a note or call…', 'realwise' ); ?>"></textarea>
        <button class="pwap-btn pwap-btn--primary" id="pwap-note-btn"><?php esc_html_e( 'Add', 'realwise' ); ?></button>
    </div>
    <ul class="pwap-timeline" id="pwap-timeline">
        <?php foreach ( $activity as $a ) : ?>
        <li><span class="pwap-timeline__when"><?php echo esc_html( date_i18n( 'M j, g:i a', strtotime( $a->created_at ) ) ); ?></span> <?php echo esc_html( $a->content ); ?></li>
        <?php endforeach; ?>
    </ul>
</div>

<?php else :
    $leads = PWAP_Portal::my_leads( $agent_id );
?>
<h3 class="pwap-h3"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'My Leads (%d)', 'realwise' ), count( $leads ) ); ?></h3>
<?php if ( ! class_exists( 'PWC_DB' ) ) : ?>
<p class="pwap-notice pwap-notice--warn"><?php esc_html_e( 'Install RealWise CRM to manage leads here.', 'realwise' ); ?></p>
<?php else : ?>
<table class="pwap-table">
    <thead><tr>
        <th><?php esc_html_e( 'Name', 'realwise' ); ?></th>
        <th><?php esc_html_e( 'Stage', 'realwise' ); ?></th>
        <th><?php esc_html_e( 'Source', 'realwise' ); ?></th>
        <th><?php esc_html_e( 'Score', 'realwise' ); ?></th>
        <th></th>
    </tr></thead>
    <tbody>
    <?php if ( $leads ) : foreach ( $leads as $lead ) : ?>
    <tr>
        <td><strong><?php echo esc_html( $lead->name ?: $lead->email ?: '—' ); ?></strong></td>
        <td><span class="pwap-pill" style="background:<?php echo esc_attr( PWC_Leads::stage_color( $lead->stage ) ); ?>;color:#fff"><?php echo esc_html( PWC_Leads::stage_label( $lead->stage ) ); ?></span></td>
        <td><?php echo esc_html( PWC_Leads::source_label( $lead->source ) ); ?></td>
        <td><?php echo (int) $lead->score; ?></td>
        <td><a href="<?php echo esc_url( add_query_arg( [ 'pwap_tab' => 'leads', 'lead' => $lead->id ] ) ); ?>" class="pwap-btn pwap-btn--sm"><?php esc_html_e( 'Open', 'realwise' ); ?></a></td>
    </tr>
    <?php endforeach; else : ?>
    <tr><td colspan="5" class="pwap-empty"><?php esc_html_e( 'No leads assigned to you yet.', 'realwise' ); ?></td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>
<?php endif; ?>
