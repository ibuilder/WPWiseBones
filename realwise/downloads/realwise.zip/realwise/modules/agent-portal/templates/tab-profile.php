<?php if ( ! defined( 'ABSPATH' ) ) exit;
$p = $profile;
?>
<?php if ( ! $p ) : ?>
<p class="pwap-notice pwap-notice--warn"><?php esc_html_e( 'No agent profile is linked to your account yet.', 'realwise' ); ?></p>
<?php else : ?>
<form class="pwap-profile-form" id="pwap-profile-form">
    <h3 class="pwap-h3"><?php esc_html_e( 'My Profile', 'realwise' ); ?></h3>
    <div class="pwap-form-grid">
        <label class="pwap-col-2"><?php esc_html_e( 'Name', 'realwise' ); ?><input type="text" name="name" value="<?php echo esc_attr( $p->name ?? '' ); ?>" required></label>
        <label><?php esc_html_e( 'Email', 'realwise' ); ?><input type="email" name="email" value="<?php echo esc_attr( $p->email ?? '' ); ?>"></label>
        <label><?php esc_html_e( 'Phone', 'realwise' ); ?><input type="text" name="phone" value="<?php echo esc_attr( $p->phone ?? '' ); ?>"></label>
        <label><?php esc_html_e( 'Brokerage', 'realwise' ); ?><input type="text" name="brokerage" value="<?php echo esc_attr( $p->brokerage ?? '' ); ?>"></label>
        <label><?php esc_html_e( 'License #', 'realwise' ); ?><input type="text" name="license_num" value="<?php echo esc_attr( $p->license_num ?? '' ); ?>"></label>
        <label class="pwap-col-2"><?php esc_html_e( 'Photo URL', 'realwise' ); ?><input type="url" name="photo_url" value="<?php echo esc_attr( $p->photo_url ?? '' ); ?>"></label>
        <label class="pwap-col-2"><?php esc_html_e( 'Bio', 'realwise' ); ?><textarea name="bio" rows="5"><?php echo esc_textarea( $p->bio ?? '' ); ?></textarea></label>
    </div>
    <div class="pwap-form-actions">
        <button type="submit" class="pwap-btn pwap-btn--primary"><?php esc_html_e( 'Save Profile', 'realwise' ); ?></button>
        <span class="pwap-form-msg" id="pwap-profile-msg"></span>
    </div>
</form>
<?php endif; ?>
