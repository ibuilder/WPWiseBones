<?php if ( ! defined( 'ABSPATH' ) ) exit;
$editing_id = isset( $_GET['edit'] ) ? (int) $_GET['edit'] : null;
$editing    = ( $editing_id && class_exists( 'PWL_DB' ) ) ? PWL_DB::get_listing( $editing_id ) : null;
// security: only edit own listing
if ( $editing && ! PWAP_Portal::owns_listing( $agent_id, $editing_id ) ) { $editing = null; $editing_id = null; }
$show_form  = isset( $_GET['edit'] );
$listings   = PWAP_Portal::my_listings( $agent_id );
$l = $editing;
?>
<?php if ( $show_form ) : ?>
<form class="pwap-listing-form" id="pwap-listing-form" data-id="<?php echo (int) ( $l->id ?? 0 ); ?>">
    <h3 class="pwap-h3"><?php echo $l ? esc_html__( 'Edit Listing', 'realwise' ) : esc_html__( 'New Listing', 'realwise' ); ?></h3>
    <div class="pwap-form-grid">
        <label><?php esc_html_e( 'Status', 'realwise' ); ?>
            <select name="status">
                <?php foreach ( [ 'active', 'pending', 'closed' ] as $rw_row ) : ?>
                <option value="<?php echo esc_attr( $rw_row ); ?>" <?php selected( $l->status ?? 'active', $rw_row ); ?>><?php echo esc_html( ucfirst( $rw_row ) ); ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <label><?php esc_html_e( 'List Price', 'realwise' ); ?><input type="number" name="list_price" value="<?php echo esc_attr( $l->list_price ?? '' ); ?>" step="1000"></label>
        <label class="pwap-col-2"><?php esc_html_e( 'Address', 'realwise' ); ?><input type="text" name="address" value="<?php echo esc_attr( $l->address ?? '' ); ?>" required></label>
        <label><?php esc_html_e( 'City', 'realwise' ); ?><input type="text" name="city" value="<?php echo esc_attr( $l->city ?? '' ); ?>"></label>
        <label><?php esc_html_e( 'State', 'realwise' ); ?><input type="text" name="state" maxlength="4" value="<?php echo esc_attr( $l->state ?? '' ); ?>"></label>
        <label><?php esc_html_e( 'ZIP', 'realwise' ); ?><input type="text" name="zip_code" value="<?php echo esc_attr( $l->zip_code ?? '' ); ?>"></label>
        <label><?php esc_html_e( 'Beds', 'realwise' ); ?><input type="number" name="bedrooms" value="<?php echo esc_attr( $l->bedrooms ?? '' ); ?>" min="0"></label>
        <label><?php esc_html_e( 'Baths', 'realwise' ); ?><input type="number" name="bathrooms" value="<?php echo esc_attr( $l->bathrooms ?? '' ); ?>" min="0" step="0.5"></label>
        <label><?php esc_html_e( 'Sqft', 'realwise' ); ?><input type="number" name="sqft" value="<?php echo esc_attr( $l->sqft ?? '' ); ?>" min="0"></label>
        <label class="pwap-col-2"><?php esc_html_e( 'Description', 'realwise' ); ?><textarea name="description" rows="4"><?php echo esc_textarea( $l->description ?? '' ); ?></textarea></label>
    </div>
    <div class="pwap-form-actions">
        <button type="submit" class="pwap-btn pwap-btn--primary"><?php esc_html_e( 'Save Listing', 'realwise' ); ?></button>
        <a href="<?php echo esc_url( add_query_arg( 'pwap_tab', 'listings', remove_query_arg( 'edit' ) ) ); ?>" class="pwap-btn"><?php esc_html_e( 'Cancel', 'realwise' ); ?></a>
        <span class="pwap-form-msg" id="pwap-listing-msg"></span>
    </div>
</form>
<?php else : ?>
<div class="pwap-listings-head">
    <h3 class="pwap-h3"><?php /* translators: %d / %s are runtime values. */ printf( esc_html__( 'My Listings (%d)', 'realwise' ), count( $listings ) ); ?></h3>
    <a href="<?php echo esc_url( add_query_arg( [ 'pwap_tab' => 'listings', 'edit' => 'new' ] ) ); ?>" class="pwap-btn pwap-btn--primary"><?php esc_html_e( '+ New Listing', 'realwise' ); ?></a>
</div>
<table class="pwap-table">
    <thead><tr>
        <th><?php esc_html_e( 'Address', 'realwise' ); ?></th>
        <th><?php esc_html_e( 'Price', 'realwise' ); ?></th>
        <th><?php esc_html_e( 'Bed/Bath', 'realwise' ); ?></th>
        <th><?php esc_html_e( 'Status', 'realwise' ); ?></th>
        <th></th>
    </tr></thead>
    <tbody>
    <?php if ( $listings ) : foreach ( $listings as $row ) : ?>
    <tr>
        <td><?php echo esc_html( $row->address . ', ' . $row->city ); ?></td>
        <td><?php echo class_exists( 'PWL_Listing' ) ? esc_html( PWL_Listing::format_price( $row->list_price ) ) : '$' . number_format( $row->list_price ); ?></td>
        <td><?php echo esc_html( ( $row->bedrooms ?? '—' ) . ' / ' . ( $row->bathrooms ?? '—' ) ); ?></td>
        <td><span class="pwap-pill pwap-pill--<?php echo esc_attr( $row->status ); ?>"><?php echo esc_html( ucfirst( $row->status ) ); ?></span></td>
        <td><a href="<?php echo esc_url( add_query_arg( [ 'pwap_tab' => 'listings', 'edit' => $row->id ] ) ); ?>" class="pwap-btn pwap-btn--sm"><?php esc_html_e( 'Edit', 'realwise' ); ?></a></td>
    </tr>
    <?php endforeach; else : ?>
    <tr><td colspan="5" class="pwap-empty"><?php esc_html_e( 'No listings yet. Click "New Listing" to add one.', 'realwise' ); ?></td></tr>
    <?php endif; ?>
    </tbody>
</table>
<?php endif; ?>
