<?php if ( ! defined( 'ABSPATH' ) ) exit;
$base   = remove_query_arg( [ 'pwap_tab', 'edit', 'lead' ] );
$tab_url = fn( $t ) => esc_url( add_query_arg( 'pwap_tab', $t, $base ) );
$rw_tabs = [
    'overview' => __( 'Overview', 'realwise' ),
    'listings' => __( 'My Listings', 'realwise' ),
    'leads'    => __( 'My Leads', 'realwise' ),
    'profile'  => __( 'Profile', 'realwise' ),
];
?>
<div class="pwap-portal" data-agent="<?php echo (int) $agent_id; ?>">

    <div class="pwap-header">
        <div class="pwap-header__id">
            <?php if ( $profile && $profile->photo_url ) : ?>
            <img src="<?php echo esc_url( $profile->photo_url ); ?>" class="pwap-avatar" alt="">
            <?php endif; ?>
            <div>
                <h2 class="pwap-header__name"><?php echo esc_html( $profile->name ?? wp_get_current_user()->display_name ); ?></h2>
                <div class="pwap-header__brokerage"><?php echo esc_html( $profile->brokerage ?? '' ); ?></div>
            </div>
        </div>
    </div>

    <?php if ( ! $agent_id ) : ?>
    <div class="pwap-notice pwap-notice--warn">
        <?php esc_html_e( 'Your account is not yet linked to an agent profile. Ask an administrator to set your agent link, or contact support.', 'realwise' ); ?>
    </div>
    <?php endif; ?>

    <nav class="pwap-tabs">
        <?php foreach ( $rw_tabs as $key => $label ) : ?>
        <a href="<?php echo esc_url( $tab_url( $key ) ); ?>" class="pwap-tab <?php echo $tab === $key ? 'pwap-tab--active' : ''; ?>"><?php echo esc_html( $label ); ?></a>
        <?php endforeach; ?>
    </nav>

    <div class="pwap-panel">
        <?php
        switch ( $tab ) {
            case 'listings': include PWAP_DIR . 'templates/tab-listings.php'; break;
            case 'leads':    include PWAP_DIR . 'templates/tab-leads.php';    break;
            case 'profile':  include PWAP_DIR . 'templates/tab-profile.php';  break;
            default:         include PWAP_DIR . 'templates/tab-overview.php';
        }
        ?>
    </div>
</div>
