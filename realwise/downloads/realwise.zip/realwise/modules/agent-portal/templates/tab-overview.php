<?php if ( ! defined( 'ABSPATH' ) ) exit;
$tasks = PWAP_Portal::my_tasks( $agent_id );
?>
<div class="pwap-stats">
    <div class="pwap-stat"><span class="pwap-stat__num"><?php echo (int) $stats['active']; ?></span><span class="pwap-stat__label"><?php esc_html_e( 'Active Listings', 'realwise' ); ?></span></div>
    <div class="pwap-stat"><span class="pwap-stat__num"><?php echo (int) $stats['open_leads']; ?></span><span class="pwap-stat__label"><?php esc_html_e( 'Open Leads', 'realwise' ); ?></span></div>
    <div class="pwap-stat"><span class="pwap-stat__num"><?php echo (int) $stats['won']; ?></span><span class="pwap-stat__label"><?php esc_html_e( 'Closed Won', 'realwise' ); ?></span></div>
    <div class="pwap-stat"><span class="pwap-stat__num"><?php echo (int) $stats['tasks']; ?></span><span class="pwap-stat__label"><?php esc_html_e( 'Open Tasks', 'realwise' ); ?></span></div>
</div>

<?php if ( $tasks ) : ?>
<h3 class="pwap-h3"><?php esc_html_e( 'Your Follow-up Tasks', 'realwise' ); ?></h3>
<ul class="pwap-tasklist">
    <?php foreach ( $tasks as $t ) :
        $lead = class_exists( 'PWC_DB' ) ? PWC_DB::get_lead( (int) $t->lead_id ) : null;
        $overdue = $t->due_date && strtotime( $t->due_date ) < time();
    ?>
    <li class="<?php echo $overdue ? 'pwap-overdue' : ''; ?>">
        <span class="pwap-task-title"><?php echo esc_html( $t->title ); ?></span>
        <?php if ( $lead ) : ?>
        <a class="pwap-task-lead" href="<?php echo esc_url( add_query_arg( [ 'pwap_tab' => 'leads', 'lead' => $t->lead_id ] ) ); ?>"><?php echo esc_html( $lead->name ?: $lead->email ); ?></a>
        <?php endif; ?>
        <?php if ( $t->due_date ) : ?><span class="pwap-task-due"><?php echo esc_html( date_i18n( 'M j', strtotime( $t->due_date ) ) ); ?></span><?php endif; ?>
    </li>
    <?php endforeach; ?>
</ul>
<?php else : ?>
<p class="pwap-empty"><?php esc_html_e( 'No open tasks. Nice and clear!', 'realwise' ); ?></p>
<?php endif; ?>
