/* RealWise Agent Portal */
(function ($) {
  'use strict';

  function post(data, cb) {
    data.nonce = PWAP.nonce;
    $.post(PWAP.ajax_url, data, cb);
  }

  $(function () {
    // Save listing
    $('#pwap-listing-form').on('submit', function (e) {
      e.preventDefault();
      var $form = $(this);
      var data = { action: 'pwap_save_listing', listing_id: $form.data('id') || 0 };
      $form.serializeArray().forEach(function (f) { data[f.name] = f.value; });
      var $msg = $('#pwap-listing-msg').text('Saving…');
      post(data, function (res) {
        if (res.success) {
          $msg.text('Saved!').css('color', '#16a34a');
          setTimeout(function () {
            window.location = window.location.pathname + '?pwap_tab=listings';
          }, 700);
        } else {
          $msg.text((res.data && res.data.message) || 'Error').css('color', '#dc2626');
        }
      });
    });

    // Save profile
    $('#pwap-profile-form').on('submit', function (e) {
      e.preventDefault();
      var data = { action: 'pwap_save_profile' };
      $(this).serializeArray().forEach(function (f) { data[f.name] = f.value; });
      var $msg = $('#pwap-profile-msg').text('Saving…');
      post(data, function (res) {
        $msg.text(res.success ? 'Saved!' : 'Error').css('color', res.success ? '#16a34a' : '#dc2626');
      });
    });

    // Lead stage change
    $('#pwap-lead-stage').on('change', function () {
      var leadId = $('.pwap-lead-detail').data('lead');
      post({ action: 'pwap_lead_stage', lead_id: leadId, stage: $(this).val() }, function () {});
    });

    // Lead note
    $('#pwap-note-btn').on('click', function () {
      var leadId = $('.pwap-lead-detail').data('lead');
      var note = $('#pwap-note-input').val().trim();
      if (!note) return;
      post({ action: 'pwap_lead_note', lead_id: leadId, note: note }, function (res) {
        if (res.success) {
          $('#pwap-timeline').prepend('<li><span class="pwap-timeline__when">' + res.data.when + '</span> ' + $('<div>').text(note).html() + '</li>');
          $('#pwap-note-input').val('');
        }
      });
    });
  });
}(jQuery));
