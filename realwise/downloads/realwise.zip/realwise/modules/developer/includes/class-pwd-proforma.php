<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWD_Proforma — full investment proforma engine (NPV, IRR, CoC, DSCR, GRM).
 * IRR solved via Newton-Raphson — no external PHP libs required.
 */
class PWD_Proforma {

    public static function monthly_payment( float $principal, float $annual_rate, int $years ): float {
        if ( $principal <= 0 ) return 0.0;
        if ( $annual_rate <= 0 ) return round( $principal / ( $years * 12 ), 2 );
        $r = $annual_rate / 12;
        $n = $years * 12;
        return $principal * ( $r * pow( 1 + $r, $n ) ) / ( pow( 1 + $r, $n ) - 1 );
    }

    public static function loan_balance_at( float $principal, float $annual_rate, int $years, int $at_month ): float {
        if ( $annual_rate <= 0 ) {
            return max( 0, $principal - ( $principal / ( $years * 12 ) ) * $at_month );
        }
        $r   = $annual_rate / 12;
        $n   = $years * 12;
        $pmt = self::monthly_payment( $principal, $annual_rate, $years );
        return max( 0, $principal * pow( 1 + $r, $at_month ) - $pmt * ( pow( 1 + $r, $at_month ) - 1 ) / $r );
    }

    /**
     * Run a multi-year proforma.
     *
     * @param array $p  See parameter list in class-pwd-db.php column names.
     * @return array    Full metrics + annual rows + cash flows.
     */
    public static function run( array $p ): array {
        $p = array_merge( [
            'purchase_price'       => 0,
            'down_pct'             => 0.20,
            'interest_rate'        => 0.07,
            'loan_years'           => 30,
            'gross_monthly_rent'   => 0,
            'other_monthly_income' => 0,
            'vacancy_rate'         => 0.05,
            'opex_pct'             => 0.35,
            'mgmt_pct'             => 0.10,
            'renovation_cost'      => 0,
            'closing_cost_pct'     => 0.03,
            'appreciation_pct'     => 0.03,
            'rent_growth_pct'      => 0.02,
            'expense_growth_pct'   => 0.025,
            'hold_years'           => 10,
            'discount_rate'        => 0.08,
            'selling_cost_pct'     => 0.06,
        ], $p );

        // Normalise pct fields: DB stores whole numbers (20.00 = 20%), run() needs decimals (0.20).
        // Safe to call on already-decimal values because none of these would legitimately be > 1
        // (no one sets a 100%+ cap rate or 100%+ vacancy rate).
        $pct_fields = [
            'down_pct', 'vacancy_rate', 'opex_pct', 'mgmt_pct', 'closing_cost_pct',
            'appreciation_pct', 'rent_growth_pct', 'expense_growth_pct', 'discount_rate',
            'selling_cost_pct',
        ];
        foreach ( $pct_fields as $f ) {
            if ( isset( $p[$f] ) && (float) $p[$f] > 1 ) {
                $p[$f] = (float) $p[$f] / 100;
            }
        }
        // interest_rate: stored as 7.000 in DB but run() needs 0.07
        if ( isset( $p['interest_rate'] ) && (float) $p['interest_rate'] > 1 ) {
            $p['interest_rate'] = (float) $p['interest_rate'] / 100;
        }

        $purchase        = (float) $p['purchase_price'];
        $down            = $purchase * (float) $p['down_pct'];
        $loan            = $purchase - $down;
        $closing         = $purchase * (float) $p['closing_cost_pct'];
        $reno            = (float) $p['renovation_cost'];
        $total_equity_in = $down + $closing + $reno;

        $monthly_pmt = self::monthly_payment( $loan, (float) $p['interest_rate'], (int) $p['loan_years'] );
        $annual_ds   = $monthly_pmt * 12;

        $annual_rows   = [];
        $cash_flows    = [ -$total_equity_in ];
        $gross_monthly = (float) $p['gross_monthly_rent'] + (float) $p['other_monthly_income'];

        for ( $yr = 1; $yr <= (int) $p['hold_years']; $yr++ ) {
            $rent_mult    = pow( 1 + (float) $p['rent_growth_pct'],    $yr - 1 );
            $expense_mult = pow( 1 + (float) $p['expense_growth_pct'], $yr - 1 );
            $gross_annual = $gross_monthly * 12 * $rent_mult;
            $egi          = $gross_annual * ( 1 - (float) $p['vacancy_rate'] );
            $opex         = $egi * ( (float) $p['opex_pct'] + (float) $p['mgmt_pct'] ) * $expense_mult;
            $noi          = $egi - $opex;
            $cash_flow    = $noi - $annual_ds;
            $annual_rows[] = [
                'year'         => $yr,
                'gross_income' => round( $gross_annual, 2 ),
                'egi'          => round( $egi, 2 ),
                'opex'         => round( $opex, 2 ),
                'noi'          => round( $noi, 2 ),
                'debt_service' => round( $annual_ds, 2 ),
                'cash_flow'    => round( $cash_flow, 2 ),
            ];
            $cash_flows[] = $cash_flow;
        }

        $sale_price    = $purchase * pow( 1 + (float) $p['appreciation_pct'], (int) $p['hold_years'] );
        $selling_costs = $sale_price * (float) $p['selling_cost_pct'];
        $loan_bal      = self::loan_balance_at( $loan, (float) $p['interest_rate'], (int) $p['loan_years'], (int) $p['hold_years'] * 12 );
        $net_proceeds  = $sale_price - $selling_costs - $loan_bal;
        $cash_flows[ (int) $p['hold_years'] ] += $net_proceeds;

        $year1_noi = $annual_rows[0]['noi']       ?? 0;
        $year1_egi = $annual_rows[0]['egi']        ?? 0;
        $year1_opx = $annual_rows[0]['opex']       ?? 0;
        $year1_cf  = $annual_rows[0]['cash_flow']  ?? 0;

        $cap_rate = $purchase > 0 ? $year1_noi / $purchase : 0;
        $coc      = $total_equity_in > 0 ? $year1_cf / $total_equity_in : 0;
        $dscr     = $annual_ds > 0 ? $year1_noi / $annual_ds : null;
        $grm      = ( $gross_monthly * 12 ) > 0 ? $purchase / ( $gross_monthly * 12 ) : null;
        $be_occ   = ( $year1_egi + $year1_opx ) > 0 ? $annual_ds / ( $year1_egi + $year1_opx ) : null;
        $irr      = self::irr( $cash_flows );
        $npv      = self::npv( (float) $p['discount_rate'], $cash_flows );
        $eq_mult  = $total_equity_in > 0 ? ( $total_equity_in + $npv ) / $total_equity_in : null;

        return [
            'purchase_price'    => $purchase,
            'total_equity_in'   => round( $total_equity_in, 2 ),
            'down_payment'      => round( $down, 2 ),
            'loan_amount'       => round( $loan, 2 ),
            'closing_costs'     => round( $closing, 2 ),
            'renovation_cost'   => $reno,
            'monthly_payment'   => round( $monthly_pmt, 2 ),
            'cap_rate_pct'      => round( $cap_rate * 100, 2 ),
            'cash_on_cash_pct'  => round( $coc * 100, 2 ),
            'irr_pct'           => $irr !== null ? round( $irr * 100, 2 ) : null,
            'npv'               => round( $npv, 2 ),
            'dscr'              => $dscr !== null ? round( $dscr, 2 ) : null,
            'grm'               => $grm  !== null ? round( $grm, 2 )  : null,
            'equity_multiple'   => $eq_mult !== null ? round( $eq_mult, 2 ) : null,
            'breakeven_occ_pct' => $be_occ !== null ? round( $be_occ * 100, 1 ) : null,
            'sale_price'        => round( $sale_price, 2 ),
            'net_sale_proceeds' => round( $net_proceeds, 2 ),
            'annual_rows'       => $annual_rows,
            'cash_flows'        => $cash_flows,
        ];
    }

    public static function npv( float $rate, array $cash_flows ): float {
        $npv = 0.0;
        foreach ( $cash_flows as $t => $cf ) {
            $npv += $cf / pow( 1 + $rate, $t );
        }
        return $npv;
    }

    public static function irr( array $cash_flows, int $max_iter = 1000, float $tol = 1e-7 ): ?float {
        if ( count( $cash_flows ) < 2 ) return null;
        $has_neg = $has_pos = false;
        foreach ( $cash_flows as $cf ) {
            if ( $cf < 0 ) $has_neg = true;
            if ( $cf > 0 ) $has_pos = true;
        }
        if ( ! $has_neg || ! $has_pos ) return null;

        $rate = 0.1;
        for ( $i = 0; $i < $max_iter; $i++ ) {
            $f = $df = 0.0;
            foreach ( $cash_flows as $t => $cf ) {
                $denom = pow( 1 + $rate, $t );
                $f    += $cf / $denom;
                if ( $t > 0 ) $df -= $t * $cf / ( $denom * ( 1 + $rate ) );
            }
            if ( abs( $df ) < 1e-12 ) break;
            $new = $rate - $f / $df;
            if ( abs( $new - $rate ) < $tol ) return $new;
            $rate = $new;
            if ( $rate < -1 ) return null;
        }
        return $rate;
    }

    public static function arv_analysis( float $purchase, float $reno, float $arv, float $hold_months = 6, float $annual_rate = 0.07 ): array {
        $acq_costs = $purchase * 0.015;
        $carry     = ( $purchase * 0.70 ) * ( $annual_rate / 12 ) * $hold_months;
        $sell_costs = $arv * 0.08;
        $total_inv  = $purchase + $reno + $acq_costs + $carry;
        $profit     = $arv - $total_inv - $sell_costs;
        $mao        = $arv * 0.70 - $reno;
        return [
            'purchase_price'    => $purchase,
            'renovation_cost'   => $reno,
            'acquisition_costs' => round( $acq_costs, 2 ),
            'carry_cost'        => round( $carry, 2 ),
            'selling_costs'     => round( $sell_costs, 2 ),
            'total_investment'  => round( $total_inv, 2 ),
            'arv'               => $arv,
            'gross_profit'      => round( $profit, 2 ),
            'roi_pct'           => $total_inv > 0 ? round( $profit / $total_inv * 100, 2 ) : 0,
            'mao_70_rule'       => round( $mao, 2 ),
            'deal_flag'         => $profit > 0 ? 'positive' : 'negative',
        ];
    }
}
