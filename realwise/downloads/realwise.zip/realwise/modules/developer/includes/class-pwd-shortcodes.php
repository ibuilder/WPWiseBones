<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWD_Shortcodes
 *
 * [pwd_proforma]       — full rental proforma calculator
 * [pwd_flip]           — fix-and-flip ARV analyzer
 * [pwd_renovation]     — renovation cost estimator
 * [pwd_deal_score id="X"] — deal score for an existing proforma
 * [pwd_my_proformas]   — saved proformas list for logged-in user
 */
class PWD_Shortcodes {

    public static function init(): void {
        $codes = [
            'pwd_proforma'      => 'render_proforma',
            'pwd_flip'          => 'render_flip',
            'pwd_renovation'    => 'render_renovation',
            'pwd_deal_score'    => 'render_deal_score',
            'pwd_my_proformas'  => 'render_my_proformas',
        ];
        foreach ( $codes as $tag => $method ) {
            add_shortcode( $tag, [ __CLASS__, $method ] );
        }
    }

    public static function render_proforma( array $atts ): string {
        $atts = shortcode_atts( [
            'listing_id' => 0,
            'proforma_id' => 0,
        ], $atts );

        $listing  = null;
        $proforma = null;
        $results  = null;

        if ( $atts['proforma_id'] ) {
            $proforma = PWD_DB::get_proforma( (int) $atts['proforma_id'] );
        }
        if ( $atts['listing_id'] && class_exists( 'PWL_DB' ) ) {
            $listing = PWL_DB::get_listing( (int) $atts['listing_id'] );
        }

        ob_start();
        include PWD_DIR . 'templates/proforma.php';
        return ob_get_clean();
    }

    public static function render_flip( array $atts ): string {
        $atts = shortcode_atts( [ 'listing_id' => 0 ], $atts );
        $listing = null;
        if ( $atts['listing_id'] && class_exists( 'PWL_DB' ) ) {
            $listing = PWL_DB::get_listing( (int) $atts['listing_id'] );
        }
        ob_start();
        include PWD_DIR . 'templates/flip-analyzer.php';
        return ob_get_clean();
    }

    public static function render_renovation( array $atts ): string {
        $catalogue = PWD_Renovation::catalogue();
        ob_start();
        include PWD_DIR . 'templates/renovation-estimator.php';
        return ob_get_clean();
    }

    public static function render_deal_score( array $atts ): string {
        $atts     = shortcode_atts( [ 'proforma_id' => 0 ], $atts );
        $proforma = PWD_DB::get_proforma( (int) $atts['proforma_id'] );
        if ( ! $proforma ) return '<p class="pwd-error">Proforma not found.</p>';
        $p       = array_map( fn($v) => is_numeric($v) ? (float) $v : $v, (array) $proforma );
        $results = PWD_Proforma::run( $p );
        $listing = null;
        if ( ! empty( $proforma->listing_id ) && class_exists( 'PWL_DB' ) ) {
            $listing = PWL_DB::get_listing( (int) $proforma->listing_id );
        }
        $score = PWD_Deal_Score::score( $results, $listing );
        ob_start();
        include PWD_DIR . 'templates/deal-score.php';
        return ob_get_clean();
    }

    public static function render_my_proformas( array $atts ): string {
        if ( ! is_user_logged_in() ) {
            return '<p class="pwd-notice">' . esc_html__( 'Please log in to view your proformas.', 'realwise' ) . '</p>';
        }
        $proformas = PWD_DB::get_user_proformas( get_current_user_id() );
        ob_start();
        include PWD_DIR . 'templates/my-proformas.php';
        return ob_get_clean();
    }
}
