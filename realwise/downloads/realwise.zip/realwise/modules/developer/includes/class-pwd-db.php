<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWD_DB — schema and helpers for RealWise Developer.
 */
class PWD_DB {

    public static function proformas_table() { global $wpdb; return $wpdb->prefix . 'pwd_proformas'; }
    public static function reno_table()      { global $wpdb; return $wpdb->prefix . 'pwd_renovation_scenarios'; }
    public static function scenarios_table() { global $wpdb; return $wpdb->prefix . 'pwd_scenarios'; }

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::proformas_table() . " (
            id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id             BIGINT UNSIGNED NOT NULL,
            listing_id          BIGINT UNSIGNED DEFAULT NULL,
            label               VARCHAR(120) NOT NULL DEFAULT 'My Proforma',
            purchase_price      DECIMAL(14,2) NOT NULL,
            down_pct            DECIMAL(5,4)  NOT NULL DEFAULT 0.2000,
            interest_rate       DECIMAL(6,4)  NOT NULL DEFAULT 0.0700,
            loan_years          TINYINT       NOT NULL DEFAULT 30,
            gross_monthly_rent  DECIMAL(10,2) DEFAULT 0,
            vacancy_rate        DECIMAL(5,4)  DEFAULT 0.0500,
            opex_pct            DECIMAL(5,4)  DEFAULT 0.3500,
            mgmt_pct            DECIMAL(5,4)  DEFAULT 0.1000,
            hold_years          TINYINT       DEFAULT 10,
            appreciation_pct    DECIMAL(5,4)  DEFAULT 0.0300,
            rent_growth_pct     DECIMAL(5,4)  DEFAULT 0.0200,
            expense_growth_pct  DECIMAL(5,4)  DEFAULT 0.0250,
            discount_rate       DECIMAL(5,4)  DEFAULT 0.0800,
            renovation_cost     DECIMAL(12,2) DEFAULT 0,
            other_monthly_income DECIMAL(10,2) DEFAULT 0,
            closing_cost_pct    DECIMAL(5,4)  DEFAULT 0.0300,
            selling_cost_pct    DECIMAL(5,4)  DEFAULT 0.0600,
            notes               TEXT,
            results_json        LONGTEXT,
            created_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            updated_at          DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY listing_id (listing_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::reno_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            proforma_id   BIGINT UNSIGNED NOT NULL,
            label         VARCHAR(120) NOT NULL,
            scope         VARCHAR(32)  NOT NULL DEFAULT 'light',
            sqft          INT UNSIGNED DEFAULT NULL,
            qty           DECIMAL(8,2) DEFAULT 1,
            unit          VARCHAR(20)  DEFAULT 'lump',
            cost_low      DECIMAL(12,2) DEFAULT 0,
            cost_mid      DECIMAL(12,2) DEFAULT 0,
            cost_high     DECIMAL(12,2) DEFAULT 0,
            cost_override DECIMAL(12,2) DEFAULT NULL,
            notes         VARCHAR(255) DEFAULT NULL,
            sort_order    TINYINT DEFAULT 0,
            PRIMARY KEY (id),
            KEY proforma_id (proforma_id)
        ) $charset;";

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::scenarios_table() . " (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            proforma_id  BIGINT UNSIGNED NOT NULL,
            label        VARCHAR(80)  NOT NULL DEFAULT 'Scenario',
            params_json  LONGTEXT,
            results_json LONGTEXT,
            created_at   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY proforma_id (proforma_id)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) dbDelta( $q );
    }

    public static function save_proforma( array $data ): int {
        global $wpdb;
        if ( ! empty( $data['id'] ) ) {
            $id = (int) $data['id']; unset( $data['id'] );
            $wpdb->update( self::proformas_table(), $data, [ 'id' => $id ] );
            return $id;
        }
        $wpdb->insert( self::proformas_table(), $data );
        return $wpdb->insert_id;
    }

    public static function get_proforma( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::proformas_table() . ' WHERE id = %d', $id ) );
    }

    public static function get_user_proformas( int $user_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::proformas_table() . ' WHERE user_id = %d ORDER BY updated_at DESC', $user_id
        ) ) ?: [];
    }

    public static function delete_proforma( int $id ): void {
        global $wpdb;
        $wpdb->delete( self::proformas_table(), [ 'id' => $id ] );
        $wpdb->delete( self::reno_table(),      [ 'proforma_id' => $id ] );
        $wpdb->delete( self::scenarios_table(), [ 'proforma_id' => $id ] );
    }

    public static function get_renovation_items( int $proforma_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::reno_table() . ' WHERE proforma_id = %d ORDER BY sort_order ASC', $proforma_id
        ) ) ?: [];
    }

    public static function save_renovation_item( array $data ): int {
        global $wpdb;
        if ( ! empty( $data['id'] ) ) {
            $id = (int) $data['id']; unset( $data['id'] );
            $wpdb->update( self::reno_table(), $data, [ 'id' => $id ] );
            return $id;
        }
        $wpdb->insert( self::reno_table(), $data );
        return $wpdb->insert_id;
    }

    public static function delete_renovation_item( int $id ): void {
        global $wpdb;
        $wpdb->delete( self::reno_table(), [ 'id' => $id ] );
    }

    public static function get_scenarios( int $proforma_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::scenarios_table() . ' WHERE proforma_id = %d ORDER BY created_at ASC', $proforma_id
        ) ) ?: [];
    }

    public static function save_scenario( array $data ): int {
        global $wpdb;
        $wpdb->insert( self::scenarios_table(), $data );
        return $wpdb->insert_id;
    }
}
