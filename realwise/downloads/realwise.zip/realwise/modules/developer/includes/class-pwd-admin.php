<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWD_Admin — admin menu, proformas table, renovation cost editor, deal score settings.
 */
class PWD_Admin {

    public static function init(): void {
        add_action( 'admin_menu',            [ __CLASS__, 'menu'              ] );
        add_action( 'admin_init',            [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets'            ] );
    }

    public static function menu(): void {
        $parent = class_exists( 'PWL_Admin' ) ? 'pwl-dashboard' : 'options-general.php';
        add_submenu_page( $parent, __( 'Investor Tools', 'realwise' ), __( 'Investor Tools', 'realwise' ), 'manage_options', 'pwd-dashboard',  [ __CLASS__, 'page_dashboard'  ], 60 );
        add_submenu_page( $parent, __( 'Proformas', 'realwise' ),      __( 'Proformas', 'realwise' ),      'manage_options', 'pwd-proformas',  [ __CLASS__, 'page_proformas'  ], 70 );
        add_submenu_page( $parent, __( 'Reno Costs', 'realwise' ),     __( 'Reno Costs', 'realwise' ),     'manage_options', 'pwd-reno-costs', [ __CLASS__, 'page_reno_costs' ], 80 );
        add_submenu_page( $parent, __( 'Deal Score', 'realwise' ),     __( 'Deal Score', 'realwise' ),     'manage_options', 'pwd-deal-score', [ __CLASS__, 'page_deal_score' ], 90 );
    }

    public static function register_settings(): void {
        // Deal score weights
        foreach ( [ 'pwd_w_cap_rate','pwd_w_coc','pwd_w_irr','pwd_w_dscr','pwd_w_neighbor','pwd_w_dom',
                    'pwd_bench_cap_min','pwd_bench_cap_max','pwd_bench_coc','pwd_bench_irr' ] as $key ) {
            register_setting( 'pwd_settings_group', $key, [ 'sanitize_callback' => 'floatval' ] );
        }
        // Page containing [pwd_proforma] — used by CRM cross-links
        register_setting( 'pwd_settings_group', 'pwd_proforma_page_id', [ 'sanitize_callback' => 'absint' ] );
        // Renovation cost overrides — auto-registered for all catalogue keys
        $catalogue = PWD_Renovation::catalogue();
        foreach ( $catalogue as $scope => $items ) {
            foreach ( array_keys( $items ) as $key ) {
                foreach ( ['low','mid','high'] as $tier ) {
                    register_setting( 'pwd_reno_costs_group', "pwd_reno_{$key}_{$tier}", [ 'sanitize_callback' => 'floatval' ] );
                }
            }
        }
    }

    public static function assets( string $hook ): void {
        if ( strpos( $hook, 'pwd' ) === false ) return;
        wp_enqueue_style(  'pwd-admin', PWD_URL . 'assets/css/admin.css',  [], PWD_VERSION );
    }

    public static function page_dashboard(): void {
        global $wpdb;
        $total_proformas = $wpdb->get_var( 'SELECT COUNT(*) FROM ' . PWD_DB::proformas_table() );
        $recent          = $wpdb->get_results( 'SELECT p.*, u.display_name FROM ' . PWD_DB::proformas_table() . ' p
            LEFT JOIN ' . $wpdb->users . ' u ON p.user_id = u.ID ORDER BY p.updated_at DESC LIMIT 10' );
        include PWD_DIR . 'templates/admin/dashboard.php';
    }

    public static function page_proformas(): void {
        global $wpdb;
        $proformas = $wpdb->get_results( 'SELECT p.*, u.display_name FROM ' . PWD_DB::proformas_table() . ' p
            LEFT JOIN ' . $wpdb->users . ' u ON p.user_id = u.ID ORDER BY p.updated_at DESC LIMIT 200' );
        include PWD_DIR . 'templates/admin/proformas.php';
    }

    public static function page_reno_costs(): void {
        $catalogue = PWD_Renovation::catalogue();
        include PWD_DIR . 'templates/admin/reno-costs.php';
    }

    public static function page_deal_score(): void {
        include PWD_DIR . 'templates/admin/deal-score-settings.php';
    }
}
