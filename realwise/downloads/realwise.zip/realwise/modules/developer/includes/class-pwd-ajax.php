<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWD_Ajax — AJAX endpoints for proforma calculations.
 */
class PWD_Ajax {

    public static function init(): void {
        $actions = [
            'pwd_run_proforma'      => [ 'run_proforma',      true  ],
            'pwd_save_proforma'     => [ 'save_proforma',     false ],
            'pwd_delete_proforma'   => [ 'delete_proforma',   false ],
            'pwd_run_flip'          => [ 'run_flip',          true  ],
            'pwd_get_reno_catalogue'=> [ 'reno_catalogue',    true  ],
            'pwd_estimate_reno'     => [ 'estimate_reno',     true  ],
            'pwd_get_comps'         => [ 'get_comps',         true  ],
        ];
        foreach ( $actions as $action => [ $cb, $nopriv ] ) {
            add_action( 'wp_ajax_' . $action, [ __CLASS__, $cb ] );
            if ( $nopriv ) add_action( 'wp_ajax_nopriv_' . $action, [ __CLASS__, $cb ] );
        }
    }

    private static function verify(): void {
        if ( ! check_ajax_referer( 'pwd_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => 'Security check failed.' ], 403 );
        }
    }

    public static function run_proforma(): void {
        self::verify();
        // Allow loading a saved proforma by ID (for "Load" button in my-proformas)
        $proforma_id = (int) ( $_POST['proforma_id'] ?? 0 );
        if ( $proforma_id ) {
            $pf = PWD_DB::get_proforma( $proforma_id );
            if ( $pf ) {
                $p = array_map( fn($v) => is_numeric($v) ? (float) $v : $v, (array) $pf );
            } else {
                wp_send_json_error( 'Proforma not found.' );
            }
        } else {
            $p = self::proforma_params_from_post();
        }
        $results = PWD_Proforma::run( $p );
        // Add deal score if we have a listing (from POST or from loaded proforma)
        $listing    = null;
        $listing_id = (int) ( $_POST['listing_id'] ?? $p['listing_id'] ?? 0 );
        if ( $listing_id && class_exists( 'PWL_DB' ) ) {
            $listing = PWL_DB::get_listing( $listing_id );
        }
        $deal_score = PWD_Deal_Score::score( $results, $listing );
        wp_send_json_success( [ 'results' => $results, 'deal_score' => $deal_score ] );
    }

    public static function save_proforma(): void {
        self::verify();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'Login required.' );
        $p = self::proforma_params_from_post();
        $p['user_id']      = get_current_user_id();
        $p['label']        = sanitize_text_field( wp_unslash( $_POST['label'] ?? 'My Proforma' ) );
        $p['notes']        = sanitize_textarea_field( wp_unslash( $_POST['notes'] ?? '' ) );
        $p['listing_id']   = ! empty( $_POST['listing_id'] ) ? (int) $_POST['listing_id'] : null;
        $p['results_json'] = wp_json_encode( PWD_Proforma::run( $p ) );
        if ( ! empty( $_POST['proforma_id'] ) ) $p['id'] = (int) $_POST['proforma_id'];
        // Remove null listing_id so DB insert doesn't fail NOT NULL constraint
        if ( $p['listing_id'] === null ) unset( $p['listing_id'] );
        $id = PWD_DB::save_proforma( $p );
        wp_send_json_success( [ 'proforma_id' => $id ] );
    }

    public static function delete_proforma(): void {
        self::verify();
        if ( ! is_user_logged_in() ) wp_send_json_error( 'Login required.' );
        $id = (int) ( $_POST['proforma_id'] ?? 0 );
        if ( ! $id ) wp_send_json_error( 'Invalid ID.' );
        $p = PWD_DB::get_proforma( $id );
        if ( ! $p || (int) $p->user_id !== get_current_user_id() ) wp_send_json_error( 'Not found.' );
        PWD_DB::delete_proforma( $id );
        wp_send_json_success();
    }

    public static function run_flip(): void {
        self::verify();
        $purchase = (float) ( $_POST['purchase_price']  ?? 0 );
        $reno     = (float) ( $_POST['renovation_cost'] ?? 0 );
        $arv      = (float) ( $_POST['arv']             ?? 0 );
        $months   = (float) ( $_POST['hold_months']     ?? 6 );
        $rate     = (float) ( $_POST['annual_rate']     ?? 7 ) / 100;
        $result   = PWD_Proforma::arv_analysis( $purchase, $reno, $arv, $months, $rate );
        wp_send_json_success( $result );
    }

    public static function reno_catalogue(): void {
        wp_send_json_success( PWD_Renovation::catalogue() );
    }

    /**
     * Return comparable sales + a suggested ARV for a listing.
     * Powers the "Auto-fill ARV from comps" button in the flip analyzer.
     */
    public static function get_comps(): void {
        self::verify();
        if ( ! class_exists( 'PWL_Comps' ) ) {
            wp_send_json_error( 'Comps require RealWise Listings to be active.' );
        }
        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );
        if ( ! $listing_id ) wp_send_json_error( 'A listing is required to pull comps.' );
        $listing = PWL_DB::get_listing( $listing_id );
        if ( ! $listing ) wp_send_json_error( 'Listing not found.' );
        wp_send_json_success( PWL_Comps::find( $listing ) );
    }

    public static function estimate_reno(): void {
        self::verify();
        $items = json_decode( stripslashes( $_POST['items'] ?? '[]' ), true );
        if ( ! is_array( $items ) ) wp_send_json_error( 'Invalid items.' );
        $budget = PWD_Renovation::build_budget( $items );
        $range  = PWD_Renovation::range_estimate( $items );
        wp_send_json_success( [ 'budget' => $budget, 'range' => $range ] );
    }

    private static function proforma_params_from_post(): array {
        $floats = [ 'purchase_price','down_pct','interest_rate','gross_monthly_rent','other_monthly_income',
                    'vacancy_rate','opex_pct','mgmt_pct','renovation_cost','closing_cost_pct',
                    'appreciation_pct','rent_growth_pct','expense_growth_pct','discount_rate','selling_cost_pct' ];
        $ints   = [ 'loan_years', 'hold_years' ];
        $p = [];
        foreach ( $floats as $k ) { if ( isset( $_POST[$k] ) ) $p[$k] = (float) $_POST[$k]; }
        foreach ( $ints   as $k ) { if ( isset( $_POST[$k] ) ) $p[$k] = (int)   $_POST[$k]; }
        if ( ! empty( $p['down_pct'] ) && $p['down_pct'] > 1 ) $p['down_pct'] /= 100;
        foreach ( ['vacancy_rate','opex_pct','mgmt_pct','closing_cost_pct','appreciation_pct',
                   'rent_growth_pct','expense_growth_pct','discount_rate','selling_cost_pct'] as $k ) {
            if ( isset( $p[$k] ) && $p[$k] > 1 ) $p[$k] /= 100;
        }
        if ( ! empty( $p['interest_rate'] ) && $p['interest_rate'] > 1 ) $p['interest_rate'] /= 100;
        return $p;
    }
}
