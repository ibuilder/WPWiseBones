<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWD_Renovation — cost catalogue and budget builder.
 *
 * 28 line-item categories across 7 scopes.
 * All unit costs are admin-configurable; these are national-average defaults.
 */
class PWD_Renovation {

    const CONTINGENCY_PCT = 0.15;

    /**
     * Full catalogue: scope → items → [ label, unit, low, mid, high ]
     * Units: sqft | each | lf (linear foot) | lump
     */
    public static function catalogue(): array {
        return [
            'cosmetic' => [
                'interior_paint'     => [ 'label' => 'Interior Paint',          'unit' => 'sqft', 'low' => 1.50,   'mid' => 2.50,   'high' => 4.00   ],
                'exterior_paint'     => [ 'label' => 'Exterior Paint',          'unit' => 'sqft', 'low' => 1.00,   'mid' => 1.75,   'high' => 3.00   ],
                'carpet'             => [ 'label' => 'Carpet (install)',         'unit' => 'sqft', 'low' => 2.00,   'mid' => 3.50,   'high' => 6.00   ],
                'hardwood_refinish'  => [ 'label' => 'Hardwood Refinish',       'unit' => 'sqft', 'low' => 1.50,   'mid' => 3.00,   'high' => 5.00   ],
                'landscaping_basic'  => [ 'label' => 'Basic Landscaping',       'unit' => 'lump', 'low' => 500,    'mid' => 2000,   'high' => 6000   ],
            ],
            'flooring' => [
                'lvp'                => [ 'label' => 'LVP / Vinyl Plank',       'unit' => 'sqft', 'low' => 3.00,   'mid' => 5.00,   'high' => 9.00   ],
                'tile'               => [ 'label' => 'Tile (ceramic/porcelain)','unit' => 'sqft', 'low' => 4.00,   'mid' => 8.00,   'high' => 15.00  ],
                'hardwood_new'       => [ 'label' => 'New Hardwood',            'unit' => 'sqft', 'low' => 6.00,   'mid' => 10.00,  'high' => 20.00  ],
            ],
            'kitchen' => [
                'kitchen_light'      => [ 'label' => 'Kitchen Refresh (cabinet paint + hardware)', 'unit' => 'lump', 'low' => 1500, 'mid' => 4000, 'high' => 8000 ],
                'kitchen_mid'        => [ 'label' => 'Kitchen Remodel (new cabinets, counters)',   'unit' => 'lump', 'low' => 8000, 'mid' => 18000,'high' => 35000 ],
                'kitchen_full'       => [ 'label' => 'Full Kitchen (layout change, high-end)',     'unit' => 'lump', 'low' => 25000,'mid' => 45000,'high' => 80000 ],
                'appliances'         => [ 'label' => 'Appliance Package',                          'unit' => 'lump', 'low' => 1500, 'mid' => 4000, 'high' => 10000 ],
            ],
            'bathrooms' => [
                'bath_cosmetic'      => [ 'label' => 'Bath Refresh (fixture swap, paint)',         'unit' => 'each', 'low' => 500,  'mid' => 2000, 'high' => 5000 ],
                'bath_remodel'       => [ 'label' => 'Full Bath Remodel',                          'unit' => 'each', 'low' => 5000, 'mid' => 12000,'high' => 25000 ],
                'bath_add'           => [ 'label' => 'Add Bathroom (new)',                         'unit' => 'each', 'low' => 8000, 'mid' => 18000,'high' => 35000 ],
            ],
            'systems' => [
                'hvac_replace'       => [ 'label' => 'HVAC Replacement',        'unit' => 'lump', 'low' => 5000,   'mid' => 10000,  'high' => 18000  ],
                'water_heater'       => [ 'label' => 'Water Heater',            'unit' => 'each', 'low' => 800,    'mid' => 1500,   'high' => 3500   ],
                'electrical_panel'   => [ 'label' => 'Electrical Panel Upgrade','unit' => 'lump', 'low' => 1500,   'mid' => 3500,   'high' => 7000   ],
                'plumbing_repiping'  => [ 'label' => 'Full Repipe',             'unit' => 'lump', 'low' => 4000,   'mid' => 9000,   'high' => 18000  ],
                'roof_replace'       => [ 'label' => 'Roof Replacement',        'unit' => 'sqft', 'low' => 3.50,   'mid' => 5.50,   'high' => 10.00  ],
                'windows'            => [ 'label' => 'Window Replacement',      'unit' => 'each', 'low' => 300,    'mid' => 700,    'high' => 1500   ],
            ],
            'structural' => [
                'foundation_repair'  => [ 'label' => 'Foundation Repair',       'unit' => 'lump', 'low' => 3000,   'mid' => 12000,  'high' => 40000  ],
                'framing'            => [ 'label' => 'Framing / Structural',    'unit' => 'sqft', 'low' => 8.00,   'mid' => 20.00,  'high' => 45.00  ],
            ],
            'addition' => [
                'room_addition'      => [ 'label' => 'Room Addition',           'unit' => 'sqft', 'low' => 100,    'mid' => 200,    'high' => 350    ],
                'adu'                => [ 'label' => 'ADU / Guest House',       'unit' => 'sqft', 'low' => 150,    'mid' => 280,    'high' => 450    ],
                'garage_add'         => [ 'label' => 'Garage Addition',         'unit' => 'lump', 'low' => 20000,  'mid' => 45000,  'high' => 80000  ],
                'deck_patio'         => [ 'label' => 'Deck / Patio',            'unit' => 'sqft', 'low' => 10,     'mid' => 25,     'high' => 60     ],
            ],
        ];
    }

    /**
     * Build a renovation budget from a list of line items.
     * Each item: [ 'key' => 'interior_paint', 'qty' => 1200, 'tier' => 'mid', 'override' => null ]
     *
     * @param array $items  Line items to price.
     * @param bool  $use_admin_overrides  Apply wp_options cost overrides.
     * @return array { items, subtotal, contingency, total, by_scope }
     */
    public static function build_budget( array $items, bool $use_admin_overrides = true ): array {
        $catalogue = self::catalogue();
        $flat      = [];
        foreach ( $catalogue as $scope => $entries ) {
            foreach ( $entries as $key => $spec ) {
                $flat[$key] = array_merge( $spec, [ 'scope' => $scope ] );
            }
        }

        $line_items = [];
        $subtotal   = 0.0;
        $by_scope   = [];

        foreach ( $items as $item ) {
            $key  = $item['key']      ?? '';
            $qty  = (float) ( $item['qty']  ?? 1 );
            $tier = $item['tier']     ?? 'mid';
            $override = isset( $item['override'] ) && $item['override'] !== null ? (float) $item['override'] : null;

            if ( ! isset( $flat[$key] ) ) continue;
            $spec = $flat[$key];

            // Admin-configurable unit cost
            $unit_cost = $override;
            if ( $unit_cost === null && $use_admin_overrides ) {
                $unit_cost = (float) get_option( 'pwd_reno_' . $key . '_' . $tier, 0 ) ?: null;
            }
            if ( $unit_cost === null ) {
                // Catalogue keys are low|mid|high
                $unit_cost = (float) ( $spec[ $tier ] ?? $spec['mid'] ?? 0 );
            }

            $line_total = $unit_cost * $qty;
            $subtotal  += $line_total;

            $scope = $spec['scope'];
            $by_scope[$scope] = ( $by_scope[$scope] ?? 0 ) + $line_total;

            $line_items[] = [
                'key'        => $key,
                'label'      => $spec['label'],
                'scope'      => $scope,
                'unit'       => $spec['unit'],
                'qty'        => $qty,
                'unit_cost'  => $unit_cost,
                'line_total' => round( $line_total, 2 ),
            ];
        }

        $contingency = $subtotal * self::CONTINGENCY_PCT;
        $total       = $subtotal + $contingency;

        return [
            'items'       => $line_items,
            'subtotal'    => round( $subtotal, 2 ),
            'contingency' => round( $contingency, 2 ),
            'total'       => round( $total, 2 ),
            'by_scope'    => array_map( fn($v) => round($v, 2), $by_scope ),
        ];
    }

    /**
     * Return low/mid/high range totals for a set of items.
     */
    public static function range_estimate( array $items ): array {
        return [
            'low'  => self::build_budget( array_map( fn($i) => array_merge( $i, ['tier' => 'low'] ),  $items ), false )['total'],
            'mid'  => self::build_budget( array_map( fn($i) => array_merge( $i, ['tier' => 'mid'] ),  $items ), false )['total'],
            'high' => self::build_budget( array_map( fn($i) => array_merge( $i, ['tier' => 'high'] ), $items ), false )['total'],
        ];
    }
}
