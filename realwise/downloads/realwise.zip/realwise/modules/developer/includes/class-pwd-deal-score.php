<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWD_Deal_Score — 0–100 weighted deal quality score.
 *
 * Six components, each 0–100, weighted and configurable via admin settings.
 */
class PWD_Deal_Score {

    /**
     * Compute overall deal score from proforma results + optional listing data.
     *
     * @param array       $results  Output of PWD_Proforma::run().
     * @param object|null $listing  PWL_DB listing row (optional, for DOM/neighborhood).
     * @return array { score, grade, components, recommendation }
     */
    public static function score( array $results, ?object $listing = null ): array {
        $weights = self::weights();

        $components = [
            'cap_rate'    => self::score_cap_rate(    $results['cap_rate_pct']     ?? 0 ),
            'coc'         => self::score_coc(         $results['cash_on_cash_pct'] ?? 0 ),
            'irr'         => self::score_irr(         $results['irr_pct']          ?? 0 ),
            'dscr'        => self::score_dscr(        $results['dscr']             ?? 0 ),
            'neighborhood'=> self::score_neighborhood( $listing ),
            'dom'         => self::score_dom(          $listing ),
        ];

        $weighted = 0;
        $total_w  = array_sum( $weights );
        foreach ( $components as $key => $val ) {
            $weighted += $val * ( $weights[$key] ?? 0 );
        }
        $score = $total_w > 0 ? (int) round( $weighted / $total_w ) : 0;
        $score = (int) max( 0, min( 100, $score ) );

        return [
            'score'          => $score,
            'grade'          => self::grade( $score ),
            'components'     => $components,
            'weights'        => $weights,
            'recommendation' => self::recommendation( $score, $results ),
        ];
    }

    private static function weights(): array {
        return [
            'cap_rate'     => (int) get_option( 'pwd_w_cap_rate',  25 ),
            'coc'          => (int) get_option( 'pwd_w_coc',       25 ),
            'irr'          => (int) get_option( 'pwd_w_irr',       20 ),
            'dscr'         => (int) get_option( 'pwd_w_dscr',      15 ),
            'neighborhood' => (int) get_option( 'pwd_w_neighbor',  10 ),
            'dom'          => (int) get_option( 'pwd_w_dom',        5 ),
        ];
    }

    // Cap rate scoring — benchmark 6% = 60, 8% = 80, 10% = 100
    private static function score_cap_rate( float $cap_pct ): int {
        $bench_min = (float) get_option( 'pwd_bench_cap_min', 4 );
        $bench_max = (float) get_option( 'pwd_bench_cap_max', 10 );
        if ( $cap_pct <= 0 ) return 0;
        return (int) min( 100, round( ( $cap_pct - $bench_min ) / ( $bench_max - $bench_min ) * 100 ) );
    }

    // Cash-on-cash: 6% = 60, 12% = 100
    private static function score_coc( float $coc_pct ): int {
        $bench = (float) get_option( 'pwd_bench_coc', 8 );
        if ( $coc_pct <= 0 ) return 0;
        return (int) min( 100, round( $coc_pct / $bench * 80 ) );
    }

    // IRR: 10% = 50, 20% = 100
    private static function score_irr( $irr_pct ): int {
        if ( $irr_pct === null || $irr_pct <= 0 ) return 0;
        $bench = (float) get_option( 'pwd_bench_irr', 15 );
        return (int) min( 100, round( $irr_pct / $bench * 75 ) );
    }

    // DSCR: 1.0 = 50, 1.25 = 80, 1.5 = 100
    private static function score_dscr( $dscr ): int {
        if ( ! $dscr || $dscr <= 0 ) return 0;
        if ( $dscr < 1.0 ) return (int) round( $dscr * 40 );
        return (int) min( 100, round( ( $dscr - 1.0 ) / 0.5 * 60 + 40 ) );
    }

    // Neighborhood: average of walk + school + crime (normalized 0-100)
    private static function score_neighborhood( ?object $listing ): int {
        if ( ! $listing ) return 50;
        $scores = [];
        if ( $listing->walk_score  ) $scores[] = (int) $listing->walk_score;
        if ( $listing->school_rating ) $scores[] = (int) ( $listing->school_rating * 10 );
        if ( $listing->crime_score ) $scores[] = (int) $listing->crime_score;
        return $scores ? (int) round( array_sum( $scores ) / count( $scores ) ) : 50;
    }

    // Days on market: <30 = 90, >180 = 30 (price-reduced/stale)
    private static function score_dom( ?object $listing ): int {
        if ( ! $listing || ! $listing->days_on_market ) return 60;
        $dom = (int) $listing->days_on_market;
        if ( $dom <= 30  ) return 90;
        if ( $dom <= 60  ) return 75;
        if ( $dom <= 90  ) return 60;
        if ( $dom <= 180 ) return 45;
        return 30;
    }

    private static function grade( int $score ): string {
        if ( $score >= 85 ) return 'A';
        if ( $score >= 75 ) return 'B';
        if ( $score >= 60 ) return 'C';
        if ( $score >= 45 ) return 'D';
        return 'F';
    }

    private static function recommendation( int $score, array $results ): string {
        $npv  = (float) ( $results['npv']  ?? 0 );
        $dscr = isset( $results['dscr'] ) && $results['dscr'] !== null ? (float) $results['dscr'] : null;
        if ( $score >= 80 && $npv > 0 )          return 'Strong Buy — deal metrics exceed benchmarks with positive NPV.';
        if ( $score >= 65 && $npv > 0 )          return 'Buy — solid fundamentals. Verify rent assumptions before committing.';
        if ( $score >= 50 )                       return 'Proceed with Caution — marginal returns. Negotiate price or improve NOI.';
        if ( $dscr !== null && $dscr < 1.0 )     return 'Do Not Proceed — property is cash-flow negative at current price/rent.';
        return 'Pass — metrics fall below acceptable thresholds.';
    }
}
