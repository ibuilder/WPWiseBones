<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwd-admin">
    <h1>Deal Score Settings</h1>
    <div class="notice notice-info inline" style="margin:12px 0"><p>
        <strong>How the deal score works:</strong> each deal gets a 0–100 score from six weighted components.
        <strong>Weights</strong> control how much each factor matters (they should sum to 100).
        <strong>Benchmarks</strong> define what counts as a "good" number — e.g. a deal hits a perfect cap-rate sub-score at your <em>Max Cap Rate</em>.
        Tune these to match your investment strategy: cash-flow investors might weight CoC and DSCR higher, while appreciation plays weight IRR.
    </p></div>
    <form method="post" action="options.php">
        <?php settings_fields( 'pwd_settings_group' ); ?>
        <h2>Component Weights (must total 100)</h2>
        <table class="form-table">
            <?php
            $weights = [ 'pwd_w_cap_rate' => 'Cap Rate', 'pwd_w_coc' => 'Cash-on-Cash', 'pwd_w_irr' => 'IRR',
                         'pwd_w_dscr' => 'DSCR', 'pwd_w_neighbor' => 'Neighborhood', 'pwd_w_dom' => 'Days on Market' ];
            foreach ( $weights as $key => $label ) : ?>
            <tr>
                <th><label for="<?php echo esc_attr($key); ?>"><?php echo esc_html( $label ); ?> weight</label></th>
                <td><input type="number" id="<?php echo esc_attr($key); ?>" name="<?php echo esc_attr($key); ?>"
                           value="<?php echo esc_attr( get_option( $key, '' ) ); ?>" class="small-text" min="0" max="100" step="1"> %</td>
            </tr>
            <?php endforeach; ?>
        </table>
        <h2>Benchmarks</h2>
        <table class="form-table">
            <tr><th>Min Cap Rate (%)</th><td><input type="number" name="pwd_bench_cap_min" value="<?php echo esc_attr( get_option('pwd_bench_cap_min', 4) ); ?>" class="small-text" step="0.5"></td></tr>
            <tr><th>Max Cap Rate (%)</th><td><input type="number" name="pwd_bench_cap_max" value="<?php echo esc_attr( get_option('pwd_bench_cap_max', 10) ); ?>" class="small-text" step="0.5"></td></tr>
            <tr><th>Target CoC (%)</th><td><input type="number" name="pwd_bench_coc" value="<?php echo esc_attr( get_option('pwd_bench_coc', 8) ); ?>" class="small-text" step="0.5"></td></tr>
            <tr><th>Target IRR (%)</th><td><input type="number" name="pwd_bench_irr" value="<?php echo esc_attr( get_option('pwd_bench_irr', 15) ); ?>" class="small-text" step="0.5"></td></tr>
        </table>
        <h2><?php esc_html_e( 'Pages', 'realwise' ); ?></h2>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Proforma Page ID', 'realwise' ); ?></th>
                <td><input type="number" name="pwd_proforma_page_id" value="<?php echo esc_attr( get_option( 'pwd_proforma_page_id', '' ) ); ?>" class="small-text">
                    <p class="description"><?php esc_html_e( 'The page containing [pwd_proforma]. Used by CRM "Underwrite this property" links.', 'realwise' ); ?></p></td></tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>
