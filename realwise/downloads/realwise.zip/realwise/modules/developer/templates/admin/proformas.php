<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwd-admin">
    <h1>All Proformas</h1>
    <table class="widefat striped">
        <thead><tr><th>ID</th><th>Label</th><th>User</th><th>Purchase</th><th>Rent/mo</th><th>Reno</th><th>Hold</th><th>Updated</th></tr></thead>
        <tbody>
        <?php foreach ( $proformas as $p ) : ?>
        <tr>
            <td><?php echo (int) $p->id; ?></td>
            <td><?php echo esc_html( $p->label ); ?></td>
            <td><?php echo esc_html( $p->display_name ?? '—' ); ?></td>
            <td>$<?php echo number_format( $p->purchase_price ); ?></td>
            <td>$<?php echo number_format( $p->gross_monthly_rent ); ?></td>
            <td>$<?php echo number_format( $p->renovation_cost ); ?></td>
            <td><?php echo (int) $p->hold_years; ?> yr</td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $p->updated_at ) ) ); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
