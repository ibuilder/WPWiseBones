<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwd-admin">
    <h1>Renovation Unit Costs</h1>
    <div class="notice notice-info inline" style="margin:12px 0"><p>
        <strong>Tip:</strong> these are the per-unit prices the <code>[pwd_renovation]</code> estimator uses.
        Leave a field <em>blank</em> to keep the national-average default shown as the placeholder.
        Enter your <strong>local</strong> low/mid/high costs to make estimates accurate for your market.
        Units: <code>sqft</code> = per square foot, <code>each</code> = per item, <code>lf</code> = per linear foot, <code>lump</code> = flat project cost.
        A <strong>15% contingency</strong> is added automatically on top of the line-item subtotal.
    </p></div>
    <form method="post" action="options.php">
        <?php settings_fields( 'pwd_reno_costs_group' ); ?>
        <?php foreach ( $catalogue as $scope => $items ) : ?>
        <h2><?php echo esc_html( ucfirst( $scope ) ); ?></h2>
        <table class="widefat">
            <thead><tr><th>Item</th><th>Unit</th><th>Low ($)</th><th>Mid ($)</th><th>High ($)</th></tr></thead>
            <tbody>
            <?php foreach ( $items as $key => $item ) : ?>
            <tr>
                <td><?php echo esc_html( $item['label'] ); ?></td>
                <td><?php echo esc_html( $item['unit'] ); ?></td>
                <?php foreach ( ['low','mid','high'] as $tier ) :
                    $opt_key = "pwd_reno_{$key}_{$tier}";
                    $default = $item[ $tier ] ?? 0;
                ?>
                <td><input type="number" name="<?php echo esc_attr( $opt_key ); ?>"
                           value="<?php echo esc_attr( get_option( $opt_key, '' ) ); ?>"
                           placeholder="<?php echo esc_attr( $default ); ?>"
                           class="small-text" step="0.01" min="0"></td>
                <?php endforeach; ?>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endforeach; ?>
        <?php submit_button(); ?>
    </form>
</div>
