<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwd-admin">
    <h1>RealWise Developer — Dashboard</h1>

    <script>
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('.pwl-help-toggle');
        if (!btn) return;
        btn.setAttribute('aria-expanded', btn.getAttribute('aria-expanded') === 'true' ? 'false' : 'true');
    });
    </script>
    <div class="pwl-help-panel">
        <button type="button" class="pwl-help-toggle" aria-expanded="true">
            <span class="dashicons dashicons-lightbulb"></span> Getting Started &amp; Tips
            <span class="pwl-help-chevron">▾</span>
        </button>
        <div class="pwl-help-body">
            <div class="pwl-help-cols">
                <div class="pwl-help-col">
                    <h3>What this plugin does</h3>
                    <p>RealWise Developer turns any property into an underwriting model. Build a multi-year rental proforma, estimate renovation costs, analyze a fix-and-flip, and get an automated 0–100 deal score with a buy/pass recommendation.</p>
                    <h3>Quick start</h3>
                    <ol>
                        <li>Create a WordPress page and add the <code>[pwd_proforma]</code> shortcode.</li>
                        <li>Tune your benchmarks under <strong>Deal Score</strong> (cap rate, CoC, IRR targets).</li>
                        <li>Adjust local renovation unit costs under <strong>Reno Costs</strong>.</li>
                        <li>Visit the page, enter deal numbers, click <em>Run Proforma</em>, then <em>Save</em> or <em>Print/PDF</em>.</li>
                    </ol>
                </div>
                <div class="pwl-help-col">
                    <h3>Tips</h3>
                    <ul class="pwl-help-tips">
                        <li><strong>Percent fields</strong> are entered as whole numbers (enter <code>20</code> for 20% down, not 0.20).</li>
                        <li><strong>Link a listing</strong> by passing <code>[pwd_proforma listing_id="123"]</code> — purchase price and neighborhood scores auto-fill the deal score.</li>
                        <li><strong>IRR &amp; NPV</strong> include the projected sale (reversion) in the final hold year, using your appreciation and selling-cost assumptions.</li>
                        <li><strong>DSCR below 1.0</strong> means the property is cash-flow negative — the deal score will flag it as "Do Not Proceed."</li>
                        <li>The <strong>70% Rule MAO</strong> in the flip analyzer = (ARV × 0.70) − renovation cost. Offer at or below this for a safety margin.</li>
                        <li>Requires <strong>RealWise Listings</strong> to be active (shared database and Chart.js).</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <div class="pwd-admin-stats">
        <div class="pwd-stat-card"><span class="pwd-stat-num"><?php echo number_format( $total_proformas ); ?></span><span class="pwd-stat-label">Saved Proformas</span></div>
    </div>
    <h2>Recent Proformas</h2>
    <table class="widefat striped">
        <thead><tr><th>Label</th><th>User</th><th>Purchase Price</th><th>Reno Cost</th><th>Updated</th></tr></thead>
        <tbody>
        <?php foreach ( $recent as $p ) : ?>
        <tr>
            <td><?php echo esc_html( $p->label ); ?></td>
            <td><?php echo esc_html( $p->display_name ?? '—' ); ?></td>
            <td>$<?php echo number_format( $p->purchase_price ); ?></td>
            <td>$<?php echo number_format( $p->renovation_cost ); ?></td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $p->updated_at ) ) ); ?></td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <div style="margin-top:24px">
        <h2>Shortcodes</h2>
        <table class="widefat">
            <thead><tr><th>Shortcode</th><th>Description</th><th>Attributes</th></tr></thead>
            <tbody>
                <tr><td><code>[pwd_proforma]</code></td><td>Full rental proforma calculator with NPV, IRR, DSCR, CoC</td><td><code>listing_id</code>, <code>proforma_id</code></td></tr>
                <tr><td><code>[pwd_flip]</code></td><td>Fix-and-flip ARV analyzer with 70% MAO rule</td><td><code>listing_id</code></td></tr>
                <tr><td><code>[pwd_renovation]</code></td><td>28-item renovation cost estimator with low/mid/high ranges</td><td>—</td></tr>
                <tr><td><code>[pwd_deal_score proforma_id="X"]</code></td><td>Deal score dial + full metrics for a saved proforma</td><td><code>proforma_id</code> (required)</td></tr>
                <tr><td><code>[pwd_my_proformas]</code></td><td>Logged-in user's saved proformas list (load/delete)</td><td>—</td></tr>
            </tbody>
        </table>
    </div>
</div>
