<?php if ( ! defined( 'ABSPATH' ) ) exit;
$arc_color = $score['score'] >= 75 ? '#16a34a' : ( $score['score'] >= 50 ? '#ca8a04' : '#dc2626' );
$arc_len   = round( $score['score'] * 1.57 );

$metric_labels = [
    'cap_rate'     => __( 'Cap Rate',       'realwise' ),
    'coc'          => __( 'Cash-on-Cash',   'realwise' ),
    'irr'          => __( 'IRR',            'realwise' ),
    'dscr'         => __( 'DSCR',           'realwise' ),
    'neighborhood' => __( 'Neighborhood',   'realwise' ),
    'dom'          => __( 'Market Days',    'realwise' ),
];
?>
<div class="pwd-deal-score-shortcode">

    <!-- Score dial + recommendation -->
    <div class="pwd-deal-score">
        <div class="pwd-deal-score__main">
            <div class="pwd-deal-score__dial">
                <svg viewBox="0 0 120 70" class="pwd-score-arc" aria-hidden="true">
                    <path d="M 10 65 A 50 50 0 0 1 110 65" stroke="#e5e7eb" stroke-width="10" fill="none"/>
                    <path d="M 10 65 A 50 50 0 0 1 110 65"
                          stroke="<?php echo esc_attr( $arc_color ); ?>"
                          stroke-width="10" fill="none"
                          stroke-dasharray="<?php echo (int) $arc_len; ?> 157"
                          stroke-linecap="round"/>
                </svg>
                <div class="pwd-deal-score__num" style="color:<?php echo esc_attr( $arc_color ); ?>"><?php echo (int) $score['score']; ?></div>
                <div class="pwd-deal-score__grade"><?php echo esc_html( $score['grade'] ); ?></div>
            </div>
            <div class="pwd-deal-score__reco"><?php echo esc_html( $score['recommendation'] ); ?></div>
        </div>

        <!-- Component bars -->
        <div class="pwd-deal-score__components">
            <?php foreach ( $score['components'] as $key => $val ) : ?>
            <div class="pwd-score-comp">
                <div class="pwd-score-comp__label"><?php echo esc_html( $metric_labels[ $key ] ?? ucwords( str_replace( '_', ' ', $key ) ) ); ?></div>
                <div class="pwd-score-comp__bar" role="progressbar" aria-valuenow="<?php echo (int) $val; ?>" aria-valuemin="0" aria-valuemax="100">
                    <div class="pwd-score-comp__fill" style="width:<?php echo (int) $val; ?>%"></div>
                </div>
                <div class="pwd-score-comp__val"><?php echo (int) $val; ?></div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Key financial metrics grid -->
    <div class="pwd-metrics-grid" style="margin-top:20px">
        <?php
        $fmt_pct    = fn($v) => $v !== null ? esc_html( number_format( (float) $v, 2 ) ) . '%' : '—';
        $fmt_dollar = function( $v ) {
            if ( $v === null ) return '—';
            $sym = get_option( 'pwl_currency_symbol', '$' );
            $v   = (float) $v;
            if ( abs($v) >= 1_000_000 ) return esc_html( $sym . number_format( $v / 1_000_000, 2 ) . 'M' );
            if ( abs($v) >= 1_000 )     return esc_html( $sym . number_format( $v ) );
            return esc_html( $sym . $v );
        };

        // phpcs:disable WordPress.Security.EscapeOutput.OutputNotEscaped -- All dynamic values below are escaped at source: the $fmt_pct/$fmt_dollar closures return esc_html() output, and $card receives already-escaped values.
        $card = function( string $label, string $value, string $cls = 'neutral' ) {
            echo '<div class="pwd-metric-card pwd-metric--' . esc_attr( $cls ) . '">'
               . '<div class="pwd-metric-card__value">' . $value . '</div>'
               . '<div class="pwd-metric-card__label">' . esc_html( $label ) . '</div>'
               . '</div>';
        };

        $r = $results;
        $card( __( 'Cap Rate',       'realwise' ), $fmt_pct( $r['cap_rate_pct'] ?? null ),     ( ($r['cap_rate_pct'] ?? 0) >= 6 ? 'positive' : 'negative' ) );
        $card( __( 'Cash-on-Cash',   'realwise' ), $fmt_pct( $r['cash_on_cash_pct'] ?? null ), ( ($r['cash_on_cash_pct'] ?? 0) >= 6 ? 'positive' : 'negative' ) );
        $card( __( 'IRR',            'realwise' ), $fmt_pct( $r['irr_pct'] ?? null ),          ( ($r['irr_pct'] ?? 0) >= 12 ? 'positive' : 'neutral' ) );
        $card( __( 'NPV',            'realwise' ), $fmt_dollar( $r['npv'] ?? null ),            ( ($r['npv'] ?? 0) >= 0 ? 'positive' : 'negative' ) );
        $card( __( 'DSCR',           'realwise' ), $r['dscr'] !== null ? esc_html( number_format( (float) $r['dscr'], 2 ) ) : '—', ( ($r['dscr'] ?? 0) >= 1.25 ? 'positive' : 'negative' ) );
        $card( __( 'Equity Multiple','realwise' ), $r['equity_multiple'] !== null ? esc_html( number_format( (float) $r['equity_multiple'], 2 ) ) . 'x' : '—', 'neutral' );
        $card( __( 'Monthly P&I',    'realwise' ), $fmt_dollar( $r['monthly_payment'] ?? null ), 'neutral' );
        $card( __( 'Sale Price',     'realwise' ), $fmt_dollar( $r['sale_price'] ?? null ),       'neutral' );
        ?>
    </div>

    <!-- Annual cash flow table -->
    <?php if ( ! empty( $results['annual_rows'] ) ) : ?>
    <details class="pwd-annual-details" style="margin-top:20px">
        <summary style="cursor:pointer;font-weight:600;padding:8px 0;color:var(--pwd-primary)"><?php esc_html_e( 'Annual Cash Flows', 'realwise' ); ?></summary>
        <div style="overflow-x:auto;margin-top:8px">
            <table class="pwd-table">
                <thead><tr>
                    <th><?php esc_html_e( 'Year',         'realwise' ); ?></th>
                    <th><?php esc_html_e( 'Gross Income',  'realwise' ); ?></th>
                    <th><?php esc_html_e( 'EGI',           'realwise' ); ?></th>
                    <th><?php esc_html_e( 'OpEx',          'realwise' ); ?></th>
                    <th><?php esc_html_e( 'NOI',           'realwise' ); ?></th>
                    <th><?php esc_html_e( 'Debt Service',  'realwise' ); ?></th>
                    <th><?php esc_html_e( 'Cash Flow',     'realwise' ); ?></th>
                </tr></thead>
                <tbody>
                <?php foreach ( $results['annual_rows'] as $row ) : ?>
                <tr class="<?php echo (float) $row['cash_flow'] < 0 ? 'negative' : ''; ?>">
                    <td><?php echo (int) $row['year']; ?></td>
                    <td><?php echo $fmt_dollar( $row['gross_income'] ); ?></td>
                    <td><?php echo $fmt_dollar( $row['egi'] ); ?></td>
                    <td><?php echo $fmt_dollar( $row['opex'] ); ?></td>
                    <td><?php echo $fmt_dollar( $row['noi'] ); ?></td>
                    <td><?php echo $fmt_dollar( $row['debt_service'] ); ?></td>
                    <td style="font-weight:600"><?php echo $fmt_dollar( $row['cash_flow'] ); ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </details>
    <?php endif; ?>
<?php // phpcs:enable WordPress.Security.EscapeOutput.OutputNotEscaped ?>

</div>
