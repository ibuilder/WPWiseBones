<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwd-reno" id="pwd-reno-app">
    <h2 class="pwd-section-title">Renovation Cost Estimator</h2>
    <div class="pwd-reno-layout">
        <div class="pwd-reno-catalogue">
            <h3>Select Scope Items</h3>
            <?php foreach ( $catalogue as $scope => $items ) : ?>
            <div class="pwd-reno-scope">
                <div class="pwd-reno-scope__header"><?php echo esc_html( ucfirst( $scope ) ); ?></div>
                <?php foreach ( $items as $key => $item ) : ?>
                <label class="pwd-reno-item">
                    <input type="checkbox" class="pwd-reno-check" data-key="<?php echo esc_attr( $key ); ?>" data-unit="<?php echo esc_attr( $item['unit'] ); ?>">
                    <span class="pwd-reno-item__name"><?php echo esc_html( $item['label'] ); ?></span>
                    <span class="pwd-reno-item__range">
                        $<?php echo number_format( $item['low'] ); ?>–$<?php echo number_format( $item['high'] ); ?>/<?php echo esc_html( $item['unit'] ); ?>
                    </span>
                    <span class="pwd-reno-item__qty-wrap" style="display:none">
                        <input type="number" class="pwd-reno-qty pwd-input" placeholder="Qty (<?php echo esc_attr( $item['unit'] ); ?>)" min="1" step="1">
                        <select class="pwd-reno-tier pwd-select">
                            <option value="low">Low</option>
                            <option value="mid" selected>Mid</option>
                            <option value="high">High</option>
                        </select>
                    </span>
                </label>
                <?php endforeach; ?>
            </div>
            <?php endforeach; ?>
            <button id="pwd-reno-estimate-btn" class="pwd-btn pwd-btn--primary">Estimate Budget</button>
        </div>
        <div class="pwd-reno-results" id="pwd-reno-results" style="display:none">
            <h3>Budget Summary</h3>
            <div id="pwd-reno-range-cards" class="pwd-metrics-grid"></div>
            <table class="pwd-table" id="pwd-reno-table"></table>
            <div class="pwd-reno-totals" id="pwd-reno-totals"></div>
        </div>
    </div>
</div>
