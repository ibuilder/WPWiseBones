<?php if ( ! defined( 'ABSPATH' ) ) exit;
// All $proforma accesses use nullsafe ?-> so this template works when $proforma is null (new proforma)
$pf = $proforma; // shorthand
// DB stores pct fields as whole-number percentages (e.g. 20.00 = 20%).
// Display them as-is; JS sends them as whole numbers; AJAX handler normalises to decimals.
$def_price = $pf?->purchase_price ?? ( $listing?->list_price ?? 350000 );
// DB stores pct as decimals (0.20); form fields expect whole numbers (20).
// Multiply only when loading a saved proforma (pf is set and values are < 1).
function pwdpf_pct( $val, $default ) {
    if ( $val === null ) return $default;
    $v = (float) $val;
    return ( $v > 0 && $v < 1 ) ? round( $v * 100, 3 ) : $v;
}
?>
<div class="pwd-proforma" id="pwd-proforma-app"
     data-listing="<?php echo esc_attr( $listing?->id ?? 0 ); ?>"
     data-proforma="<?php echo esc_attr( $pf?->id ?? 0 ); ?>">

    <h2 class="pwd-section-title">Investment Proforma</h2>

    <div class="pwd-proforma-layout">
        <div class="pwd-inputs-panel">
            <fieldset class="pwd-fieldset">
                <legend>Purchase</legend>
                <div class="pwd-field-row">
                    <div class="pwd-field">
                        <label>Purchase Price</label>
                        <input type="number" id="pwd-purchase-price" name="purchase_price" class="pwd-input"
                               value="<?php echo esc_attr( $def_price ); ?>" step="1000">
                    </div>
                    <div class="pwd-field">
                        <label>Down Payment (%)</label>
                        <input type="number" id="pwd-down-pct" name="down_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->down_pct, 20 ) ); ?>" step="1" min="0" max="100">
                    </div>
                    <div class="pwd-field">
                        <label>Interest Rate (%)</label>
                        <input type="number" id="pwd-rate" name="interest_rate" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->interest_rate, 7.0 ) ); ?>" step="0.125" min="1" max="20">
                    </div>
                    <div class="pwd-field">
                        <label>Loan Term (yrs)</label>
                        <select id="pwd-loan-years" name="loan_years" class="pwd-select">
                            <?php foreach ( [ 30, 25, 20, 15, 10 ] as $y ) : ?>
                            <option value="<?php echo esc_attr( $y ); ?>" <?php selected( $pf?->loan_years ?? 30, $y ); ?>><?php echo esc_html( $y ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
            </fieldset>

            <fieldset class="pwd-fieldset">
                <legend>Income</legend>
                <div class="pwd-field-row">
                    <div class="pwd-field">
                        <label>Gross Monthly Rent</label>
                        <input type="number" id="pwd-rent" name="gross_monthly_rent" class="pwd-input"
                               value="<?php echo esc_attr( $pf?->gross_monthly_rent ?? 2500 ); ?>" step="50">
                    </div>
                    <div class="pwd-field">
                        <label>Other Income/mo</label>
                        <input type="number" id="pwd-other-income" name="other_monthly_income" class="pwd-input"
                               value="<?php echo esc_attr( $pf?->other_monthly_income ?? 0 ); ?>" step="25">
                    </div>
                    <div class="pwd-field">
                        <label>Vacancy Rate (%)</label>
                        <input type="number" id="pwd-vacancy" name="vacancy_rate" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->vacancy_rate, 5 ) ); ?>" step="0.5" min="0" max="50">
                    </div>
                    <div class="pwd-field">
                        <label>Rent Growth (%/yr)</label>
                        <input type="number" id="pwd-rent-growth" name="rent_growth_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->rent_growth_pct, 2 ) ); ?>" step="0.5">
                    </div>
                </div>
            </fieldset>

            <fieldset class="pwd-fieldset">
                <legend>Expenses</legend>
                <div class="pwd-field-row">
                    <div class="pwd-field">
                        <label>OpEx (% EGI)</label>
                        <input type="number" id="pwd-opex" name="opex_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->opex_pct, 35 ) ); ?>" step="1" min="0" max="80">
                    </div>
                    <div class="pwd-field">
                        <label>Mgmt (% EGI)</label>
                        <input type="number" id="pwd-mgmt" name="mgmt_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->mgmt_pct, 10 ) ); ?>" step="1" min="0" max="30">
                    </div>
                    <div class="pwd-field">
                        <label>Expense Growth (%/yr)</label>
                        <input type="number" id="pwd-exp-growth" name="expense_growth_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->expense_growth_pct, 2.5 ) ); ?>" step="0.5">
                    </div>
                    <div class="pwd-field">
                        <label>Renovation Cost ($)</label>
                        <input type="number" id="pwd-reno-cost" name="renovation_cost" class="pwd-input"
                               value="<?php echo esc_attr( $pf?->renovation_cost ?? 0 ); ?>" step="500">
                    </div>
                </div>
            </fieldset>

            <fieldset class="pwd-fieldset">
                <legend>Hold &amp; Exit</legend>
                <div class="pwd-field-row">
                    <div class="pwd-field">
                        <label>Hold Period (yrs)</label>
                        <input type="number" id="pwd-hold" name="hold_years" class="pwd-input"
                               value="<?php echo esc_attr( $pf?->hold_years ?? 10 ); ?>" step="1" min="1" max="30">
                    </div>
                    <div class="pwd-field">
                        <label>Appreciation (%/yr)</label>
                        <input type="number" id="pwd-appreciation" name="appreciation_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->appreciation_pct, 3 ) ); ?>" step="0.5">
                    </div>
                    <div class="pwd-field">
                        <label>Discount Rate (%)</label>
                        <input type="number" id="pwd-discount" name="discount_rate" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->discount_rate, 8 ) ); ?>" step="0.5">
                    </div>
                    <div class="pwd-field">
                        <label>Selling Costs (%)</label>
                        <input type="number" id="pwd-selling-costs" name="selling_cost_pct" class="pwd-input"
                               value="<?php echo esc_attr( pwdpf_pct( $pf?->selling_cost_pct, 6 ) ); ?>" step="0.5">
                    </div>
                </div>
            </fieldset>

            <div class="pwd-proforma-actions">
                <button id="pwd-run-btn" class="pwd-btn pwd-btn--primary">&#128200; Run Proforma</button>
                <?php if ( is_user_logged_in() ) : ?>
                <button id="pwd-save-btn" class="pwd-btn pwd-btn--outline">&#128190; Save</button>
                <?php endif; ?>
                <button id="pwd-print-btn" class="pwd-btn pwd-btn--outline" title="<?php esc_attr_e( 'Print / Save as PDF', 'realwise' ); ?>" style="display:none">&#128438; Print / PDF</button>
            </div>
        </div>

        <div class="pwd-results-panel" id="pwd-results" style="display:none">
            <div class="pwd-metrics-grid" id="pwd-metrics"></div>
            <div class="pwd-deal-score-wrap" id="pwd-deal-score-wrap"></div>
            <h3 class="pwd-sub-title">Annual Cash Flows</h3>
            <canvas id="pwd-cf-chart" class="pwd-chart"></canvas>
            <div class="pwd-table-wrap" id="pwd-annual-table"></div>
        </div>
    </div>
</div>
