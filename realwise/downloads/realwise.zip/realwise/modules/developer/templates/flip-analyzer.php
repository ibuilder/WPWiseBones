<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwd-flip" id="pwd-flip-app" data-listing="<?php echo esc_attr( $listing->id ?? 0 ); ?>">
    <h2 class="pwd-section-title">Fix &amp; Flip Analyzer</h2>
    <div class="pwd-flip-layout">
        <div class="pwd-inputs-panel">
            <div class="pwd-field-row">
                <div class="pwd-field">
                    <label>Purchase Price</label>
                    <input type="number" id="pwd-flip-purchase" class="pwd-input"
                           value="<?php echo esc_attr( $listing->list_price ?? 200000 ); ?>" step="1000">
                </div>
                <div class="pwd-field">
                    <label>Renovation Cost</label>
                    <input type="number" id="pwd-flip-reno" class="pwd-input" value="40000" step="1000">
                </div>
                <div class="pwd-field">
                    <label>After-Repair Value (ARV)</label>
                    <input type="number" id="pwd-flip-arv" class="pwd-input" value="320000" step="1000">
                    <?php if ( ! empty( $listing->id ) ) : ?>
                    <button type="button" id="pwd-comps-btn" class="pwd-comps-link" title="<?php esc_attr_e( 'Pull comparable sales and suggest an ARV', 'realwise' ); ?>">
                        &#128202; <?php esc_html_e( 'Auto-fill from comps', 'realwise' ); ?>
                    </button>
                    <?php endif; ?>
                </div>
                <div class="pwd-field">
                    <label>Hold Period (months)</label>
                    <input type="number" id="pwd-flip-months" class="pwd-input" value="6" step="1" min="1" max="36">
                </div>
                <div class="pwd-field">
                    <label>Carry Rate (% annual)</label>
                    <input type="number" id="pwd-flip-rate" class="pwd-input" value="10" step="0.5" min="1" max="30">
                </div>
            </div>
            <button id="pwd-flip-run-btn" class="pwd-btn pwd-btn--primary">Analyze Deal</button>
        </div>
        <div class="pwd-results-panel" id="pwd-flip-results" style="display:none">
            <div class="pwd-metrics-grid" id="pwd-flip-metrics"></div>
        </div>
    </div>

    <!-- Comps panel -->
    <div class="pwd-comps" id="pwd-comps-panel" style="display:none">
        <h3 class="pwd-sub-title"><?php esc_html_e( 'Comparable Sales', 'realwise' ); ?>
            <span class="pwd-comps-source" id="pwd-comps-source"></span>
        </h3>
        <div class="pwd-comps-summary" id="pwd-comps-summary"></div>
        <div class="pwd-table-wrap">
            <table class="pwd-table" id="pwd-comps-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Address',  'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Price',    'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Sqft',     'realwise' ); ?></th>
                        <th><?php esc_html_e( '$/sqft',   'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Bed/Bath', 'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Dist',     'realwise' ); ?></th>
                        <th><?php esc_html_e( 'Status',   'realwise' ); ?></th>
                    </tr>
                </thead>
                <tbody id="pwd-comps-tbody"></tbody>
            </table>
        </div>
    </div>
</div>
