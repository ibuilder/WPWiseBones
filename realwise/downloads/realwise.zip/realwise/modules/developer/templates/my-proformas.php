<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwd-my-proformas">
    <h2><?php esc_html_e( 'My Proformas', 'realwise' ); ?></h2>
    <?php if ( empty( $proformas ) ) : ?>
    <p class="pwd-notice"><?php esc_html_e( 'No saved proformas yet. Use [pwd_proforma] to build and save one.', 'realwise' ); ?></p>
    <?php else : ?>
    <table class="pwd-table widefat">
        <thead><tr><th>Label</th><th>Property</th><th>Price</th><th>Cap Rate</th><th>IRR</th><th>Updated</th><th></th></tr></thead>
        <tbody>
        <?php foreach ( $proformas as $pf ) :
            $res = json_decode( $pf->results_json ?? '{}', true );
        ?>
        <tr>
            <td><?php echo esc_html( $pf->label ); ?></td>
            <td><?php echo esc_html( $pf->listing_id ? '#' . $pf->listing_id : '—' ); ?></td>
            <td>$<?php echo number_format( $pf->purchase_price ); ?></td>
            <td><?php echo isset($res['cap_rate_pct']) ? esc_html( $res['cap_rate_pct'] ) . '%' : '—'; ?></td>
            <td><?php echo isset($res['irr_pct']) ? esc_html( $res['irr_pct'] ) . '%' : '—'; ?></td>
            <td><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $pf->updated_at ) ) ); ?></td>
            <td>
                <button class="pwd-btn pwd-btn--sm pwd-load-proforma" data-id="<?php echo (int) $pf->id; ?>">Load</button>
                <button class="pwd-btn pwd-btn--sm pwd-btn--danger pwd-delete-proforma" data-id="<?php echo (int) $pf->id; ?>">Delete</button>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
    <?php endif; ?>
</div>
