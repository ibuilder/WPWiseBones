/* RealWise Developer — Front-end JS */
/* global PWD, Chart */
(function ($) {
  'use strict';

  var cfChart = null;

  // ── Proforma ──────────────────────────────────────────────────────────────
  function initProforma() {
    var $app = $('#pwd-proforma-app');
    if (!$app.length) return;

    $('#pwd-print-btn').on('click', function () {
      window.print();
    });

    $('#pwd-run-btn').on('click', function () {
      var params = collectInputs($app);
      params.listing_id = $app.data('listing') || 0;
      $(this).prop('disabled', true).text('Calculating…');
      var $btn = $(this);
      $.post(PWD.ajax_url, $.extend({ action: 'pwd_run_proforma', nonce: PWD.nonce }, params), function (res) {
        $btn.prop('disabled', false).text('▶ Run Proforma');
        if (!res.success) return;
        $('#pwd-results').show();
        $('#pwd-print-btn').show();
        renderMetrics(res.data.results, '#pwd-metrics');
        renderDealScore(res.data.deal_score, '#pwd-deal-score-wrap');
        renderAnnualTable(res.data.results.annual_rows, '#pwd-annual-table');
        drawCFChart(res.data.results.annual_rows);
      });
    });

    $('#pwd-save-btn').on('click', function () {
      var label = prompt('Proforma name:', 'My Proforma');
      if (!label) return;
      var params = collectInputs($app);
      params.label       = label;
      params.listing_id  = $app.data('listing')  || 0;
      params.proforma_id = $app.data('proforma') || 0;
      var $btn = $(this).prop('disabled', true).text('Saving…');
      $.post(PWD.ajax_url, $.extend({ action: 'pwd_save_proforma', nonce: PWD.nonce }, params), function (res) {
        $btn.prop('disabled', false).html('&#128190; Save');
        if (res.success) {
          $app.data('proforma', res.data.proforma_id);
          $btn.html('&#10003; Saved');
          setTimeout(function () { $btn.html('&#128190; Save'); }, 2500);
        }
      });
    });
  }

  function collectInputs($ctx) {
    var params = {};
    $ctx.find('input, select').each(function () {
      if (this.name) params[this.name] = $(this).val();
    });
    return params;
  }

  function renderMetrics(r, selector) {
    var metrics = [
      { label: 'Cap Rate',       value: fmt_pct(r.cap_rate_pct),    cls: r.cap_rate_pct >= 6 ? 'positive' : 'negative' },
      { label: 'Cash-on-Cash',   value: fmt_pct(r.cash_on_cash_pct),cls: r.cash_on_cash_pct >= 6 ? 'positive' : 'negative' },
      { label: 'IRR',            value: r.irr_pct != null ? fmt_pct(r.irr_pct) : 'N/A', cls: r.irr_pct >= 12 ? 'positive' : 'neutral' },
      { label: 'NPV',            value: fmt_dollar(r.npv),           cls: r.npv >= 0 ? 'positive' : 'negative' },
      { label: 'DSCR',           value: r.dscr != null ? r.dscr.toFixed(2) : 'N/A', cls: r.dscr >= 1.25 ? 'positive' : 'negative' },
      { label: 'GRM',            value: r.grm  != null ? r.grm.toFixed(1)  : 'N/A', cls: 'neutral' },
      { label: 'Equity Multiple',value: r.equity_multiple != null ? r.equity_multiple.toFixed(2) + 'x' : 'N/A', cls: 'neutral' },
      { label: 'Monthly P&I',    value: fmt_dollar(r.monthly_payment), cls: 'neutral' },
    ];
    var html = metrics.map(function (m) {
      return '<div class="pwd-metric-card pwd-metric--' + m.cls + '"><div class="pwd-metric-card__value">' + m.value + '</div><div class="pwd-metric-card__label">' + m.label + '</div></div>';
    }).join('');
    $(selector).html(html);
  }

  function renderDealScore(ds, selector) {
    if (!ds) return;
    var arc = Math.round(ds.score * 1.57);
    var color = ds.score >= 75 ? '#16a34a' : (ds.score >= 50 ? '#ca8a04' : '#dc2626');
    var bars = Object.entries(ds.components).map(function (e) {
      return '<div class="pwd-score-comp"><div class="pwd-score-comp__label">' + e[0].replace(/_/g,' ') + '</div>'
           + '<div class="pwd-score-comp__bar"><div class="pwd-score-comp__fill" style="width:' + e[1] + '%"></div></div>'
           + '<div class="pwd-score-comp__val">' + e[1] + '</div></div>';
    }).join('');
    $(selector).html(
      '<div class="pwd-deal-score">'
      + '<div class="pwd-deal-score__main"><div class="pwd-deal-score__dial">'
      + '<svg viewBox="0 0 120 70" class="pwd-score-arc">'
      + '<path d="M 10 65 A 50 50 0 0 1 110 65" stroke="#e5e7eb" stroke-width="10" fill="none"/>'
      + '<path d="M 10 65 A 50 50 0 0 1 110 65" stroke="' + color + '" stroke-width="10" fill="none" stroke-dasharray="' + arc + ' 157" stroke-linecap="round"/>'
      + '</svg><div class="pwd-deal-score__num">' + ds.score + '</div><div class="pwd-deal-score__grade">' + ds.grade + '</div></div>'
      + '<div class="pwd-deal-score__reco">' + ds.recommendation + '</div></div>'
      + '<div class="pwd-deal-score__components">' + bars + '</div>'
      + '</div>'
    );
  }

  function renderAnnualTable(rows, selector) {
    if (!rows || !rows.length) return;
    var headers = ['Year','Gross Income','EGI','OpEx','NOI','Debt Service','Cash Flow'];
    var th = headers.map(function (h) { return '<th>' + h + '</th>'; }).join('');
    var trs = rows.map(function (r) {
      var cls = r.cash_flow < 0 ? ' class="negative"' : '';
      return '<tr' + cls + '>'
        + '<td>' + r.year + '</td>'
        + '<td>' + fmt_dollar(r.gross_income) + '</td>'
        + '<td>' + fmt_dollar(r.egi) + '</td>'
        + '<td>' + fmt_dollar(r.opex) + '</td>'
        + '<td>' + fmt_dollar(r.noi) + '</td>'
        + '<td>' + fmt_dollar(r.debt_service) + '</td>'
        + '<td>' + fmt_dollar(r.cash_flow) + '</td>'
        + '</tr>';
    }).join('');
    $(selector).html('<table class="pwd-table"><thead><tr>' + th + '</tr></thead><tbody>' + trs + '</tbody></table>');
  }

  function drawCFChart(rows) {
    var ctx = document.getElementById('pwd-cf-chart');
    if (!ctx || !window.Chart) return;
    if (cfChart) cfChart.destroy();
    cfChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: rows.map(function (r) { return 'Yr ' + r.year; }),
        datasets: [
          { label: 'NOI',        data: rows.map(function (r) { return r.noi; }),        backgroundColor: 'rgba(124,58,237,.6)' },
          { label: 'Cash Flow',  data: rows.map(function (r) { return r.cash_flow; }), backgroundColor: rows.map(function (r) { return r.cash_flow >= 0 ? 'rgba(22,163,74,.7)' : 'rgba(220,38,38,.7)'; }) }
        ]
      },
      options: { responsive: true, plugins: { legend: { position: 'bottom' } },
        scales: { y: { ticks: { callback: function (v) { return '$' + (v/1000).toFixed(0) + 'k'; } } } } }
    });
  }

  // ── Fix & Flip ─────────────────────────────────────────────────────────────
  function initFlip() {
    $('#pwd-flip-run-btn').on('click', function () {
      var $btn = $(this).prop('disabled', true).text('Analyzing…');
      $.post(PWD.ajax_url, {
        action: 'pwd_run_flip', nonce: PWD.nonce,
        purchase_price:  $('#pwd-flip-purchase').val(),
        renovation_cost: $('#pwd-flip-reno').val(),
        arv:             $('#pwd-flip-arv').val(),
        hold_months:     $('#pwd-flip-months').val(),
        annual_rate:     $('#pwd-flip-rate').val(),
      }, function (res) {
        $btn.prop('disabled', false).text('Analyze Deal');
        if (!res.success) return;
        var r = res.data;
        var metrics = [
          { label: 'Gross Profit',  value: fmt_dollar(r.gross_profit),   cls: r.gross_profit >= 0 ? 'positive' : 'negative' },
          { label: 'ROI',           value: fmt_pct(r.roi_pct),           cls: r.roi_pct >= 15 ? 'positive' : 'negative' },
          { label: 'Total Investment', value: fmt_dollar(r.total_investment), cls: 'neutral' },
          { label: '70% Rule MAO',  value: fmt_dollar(r.mao_70_rule),    cls: 'neutral' },
          { label: 'Carry Cost',    value: fmt_dollar(r.carry_cost),     cls: 'neutral' },
          { label: 'Sell Costs',    value: fmt_dollar(r.selling_costs),  cls: 'neutral' },
        ];
        $('#pwd-flip-results').show().find('#pwd-flip-metrics').html(
          metrics.map(function (m) {
            return '<div class="pwd-metric-card pwd-metric--' + m.cls + '"><div class="pwd-metric-card__value">' + m.value + '</div><div class="pwd-metric-card__label">' + m.label + '</div></div>';
          }).join('')
        );
      });
    });

    // Auto-fill ARV from comparable sales
    $('#pwd-comps-btn').on('click', function () {
      var listingId = $('#pwd-flip-app').data('listing');
      if (!listingId) { alert('Comps need a linked listing. Use [pwd_flip listing_id="X"].'); return; }
      var $btn = $(this).prop('disabled', true).text('Pulling comps…');
      $.post(PWD.ajax_url, { action: 'pwd_get_comps', nonce: PWD.nonce, listing_id: listingId }, function (res) {
        $btn.prop('disabled', false).html('&#128202; Auto-fill from comps');
        if (!res.success) { alert(res.data || 'No comps found.'); return; }
        renderComps(res.data);
        if (res.data.suggested_arv) {
          $('#pwd-flip-arv').val(res.data.suggested_arv).trigger('change');
        }
      });
    });
  }

  function renderComps(data) {
    var stats = data.stats || {};
    var srcLabel = { local: 'from your database', attom: 'from ATTOM Data', mixed: 'from your database + ATTOM' }[data.source] || '';
    $('#pwd-comps-source').text(stats.count ? '(' + stats.count + ' comps ' + srcLabel + ')' : '');

    if (!stats.count) {
      $('#pwd-comps-summary').html('<p class="pwd-notice">No comparable sales found nearby. Try widening the radius or enter ARV manually.</p>');
      $('#pwd-comps-tbody').empty();
      $('#pwd-comps-panel').show();
      return;
    }

    $('#pwd-comps-summary').html(
      '<div class="pwd-comps-stats">'
      + '<span><strong>' + fmt_dollar(stats.median_ppsf) + '</strong>/sqft median</span>'
      + '<span><strong>' + fmt_dollar(stats.low_ppsf) + '</strong>–<strong>' + fmt_dollar(stats.high_ppsf) + '</strong>/sqft range</span>'
      + (data.suggested_arv ? '<span class="pwd-comps-arv">Suggested ARV: <strong>' + fmt_dollar(data.suggested_arv) + '</strong></span>' : '')
      + '</div>'
    );

    $('#pwd-comps-tbody').html(data.comps.map(function (c) {
      var addr = c.url ? '<a href="' + c.url + '" target="_blank" rel="noopener">' + c.address + '</a>' : c.address;
      return '<tr>'
        + '<td style="text-align:left">' + addr + '</td>'
        + '<td>' + fmt_dollar(c.price) + '</td>'
        + '<td>' + Number(c.sqft).toLocaleString() + '</td>'
        + '<td>' + fmt_dollar(c.ppsf) + '</td>'
        + '<td>' + (c.beds || '—') + ' / ' + (c.baths || '—') + '</td>'
        + '<td>' + (c.distance != null ? c.distance + ' mi' : '—') + '</td>'
        + '<td>' + c.status + '</td>'
        + '</tr>';
    }).join(''));
    $('#pwd-comps-panel').show();
  }

  // ── Renovation estimator ───────────────────────────────────────────────────
  function initReno() {
    $(document).on('change', '.pwd-reno-check', function () {
      $(this).closest('.pwd-reno-item').find('.pwd-reno-item__qty-wrap').toggle( this.checked );
    });

    $('#pwd-reno-estimate-btn').on('click', function () {
      var items = [];
      $('.pwd-reno-check:checked').each(function () {
        var $item = $(this).closest('.pwd-reno-item');
        items.push({
          key:  $(this).data('key'),
          qty:  parseFloat( $item.find('.pwd-reno-qty').val() ) || 1,
          tier: $item.find('.pwd-reno-tier').val() || 'mid',
        });
      });
      if (!items.length) { alert('Select at least one scope item.'); return; }
      $.post(PWD.ajax_url, {
        action: 'pwd_estimate_reno', nonce: PWD.nonce,
        items: JSON.stringify(items)
      }, function (res) {
        if (!res.success) return;
        var b = res.data.budget, rng = res.data.range;
        $('#pwd-reno-results').show();
        $('#pwd-reno-range-cards').html(
          ['low','mid','high'].map(function (t) {
            return '<div class="pwd-metric-card pwd-metric--neutral"><div class="pwd-metric-card__value">' + fmt_dollar(rng[t]) + '</div><div class="pwd-metric-card__label">' + t.charAt(0).toUpperCase() + t.slice(1) + ' Estimate</div></div>';
          }).join('')
        );
        var rows = b.items.map(function (i) {
          return '<tr><td>' + i.label + '</td><td>' + i.qty + ' ' + i.unit + '</td><td>' + fmt_dollar(i.unit_cost) + '</td><td>' + fmt_dollar(i.line_total) + '</td></tr>';
        }).join('');
        $('#pwd-reno-table').html(
          '<thead><tr><th>Item</th><th>Qty</th><th>Unit Cost</th><th>Subtotal</th></tr></thead><tbody>' + rows + '</tbody>'
        );
        $('#pwd-reno-totals').html(
          'Subtotal: <strong>' + fmt_dollar(b.subtotal) + '</strong> &nbsp;|&nbsp; '
          + '15% Contingency: <strong>' + fmt_dollar(b.contingency) + '</strong> &nbsp;|&nbsp; '
          + 'Total: <strong style="color:var(--pwd-primary)">' + fmt_dollar(b.total) + '</strong>'
        );
      });
    });
  }

  // ── My Proformas ───────────────────────────────────────────────────────────
  function initMyProformas() {
    $(document).on('click', '.pwd-load-proforma', function () {
      var id = $(this).data('id');
      // Redirect to the proforma page with the proforma_id param
      var $app = $('#pwd-proforma-app');
      if (!$app.length) {
        // Try to find the proforma shortcode page URL from the link
        var baseUrl = window.location.href.split('?')[0];
        window.location.href = baseUrl + '?pwd_proforma=' + id;
        return;
      }
      // Load data inline if the proforma app is on the same page
      $.post(PWD.ajax_url, {
        action: 'pwd_run_proforma',
        nonce:  PWD.nonce,
        proforma_id: id
      }, function (res) {
        if (!res.success) return;
        $('#pwd-results').show();
        renderMetrics(res.data.results, '#pwd-metrics');
        renderDealScore(res.data.deal_score, '#pwd-deal-score-wrap');
        renderAnnualTable(res.data.results.annual_rows, '#pwd-annual-table');
        drawCFChart(res.data.results.annual_rows);
        $app.data('proforma', id);
        $('html, body').animate({ scrollTop: $app.offset().top - 40 }, 400);
      });
    });

    $(document).on('click', '.pwd-delete-proforma', function () {
      if (!confirm('Delete this proforma?')) return;
      var $row = $(this).closest('tr');
      $.post(PWD.ajax_url, { action: 'pwd_delete_proforma', nonce: PWD.nonce, proforma_id: $(this).data('id') }, function (res) {
        if (res.success) $row.remove();
      });
    });
  }

  // ── Utilities ──────────────────────────────────────────────────────────────
  function fmt_dollar(v) { if (v == null) return 'N/A'; return (v < 0 ? '-$' : '$') + Math.abs(Math.round(v)).toLocaleString(); }
  function fmt_pct(v) { if (v == null) return 'N/A'; return v.toFixed(2) + '%'; }

  $(function () {
    initProforma();
    initFlip();
    initReno();
    initMyProformas();
  });

}(jQuery));
