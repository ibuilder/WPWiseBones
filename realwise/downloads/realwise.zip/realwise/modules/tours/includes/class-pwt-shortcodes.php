<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWT_Shortcodes
 *   [pwt_request_tour listing_id="123"]  — slot picker + request form.
 */
class PWT_Shortcodes {

    public static function init(): void {
        add_shortcode( 'pwt_request_tour', [ __CLASS__, 'render' ] );
    }

    public static function render( array $atts ): string {
        $atts = shortcode_atts( [
            'listing_id' => (int) ( $_GET['pwl_id'] ?? 0 ),
            'agent_id'   => 0,
            'title'      => __( 'Request a Tour', 'realwise' ),
        ], $atts );

        $agent_id = (int) $atts['agent_id'];
        if ( ! $agent_id && $atts['listing_id'] && class_exists( 'PWL_DB' ) ) {
            $listing  = PWL_DB::get_listing( (int) $atts['listing_id'] );
            $agent_id = $listing && $listing->agent_id ? (int) $listing->agent_id : 0;
        }
        $days = PWT_Availability::upcoming( $agent_id, (int) get_option( 'pwt_window_days', 14 ) );

        ob_start();
        include PWT_DIR . 'templates/request-tour.php';
        return ob_get_clean();
    }
}
