<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWT_Availability — computes bookable slots from availability windows,
 * minus already-booked slots and past times.
 */
class PWT_Availability {

    /**
     * Bookable slots for the next N days.
     *
     * @return array[] [ 'date' => 'Y-m-d', 'label' => 'Mon, Jun 9', 'slots' => ['09:00', …] ]
     */
    public static function upcoming( int $agent_id = 0, int $days = 14 ): array {
        $slot_minutes = (int) get_option( 'pwt_slot_minutes', 30 );
        $lead_hours   = (int) get_option( 'pwt_min_lead_hours', 2 );
        $windows      = self::windows_by_weekday( $agent_id );
        $tz           = wp_timezone();
        $now          = new DateTime( 'now', $tz );
        $min_book     = ( clone $now )->modify( "+{$lead_hours} hours" );

        $out = [];
        for ( $i = 0; $i < $days; $i++ ) {
            $day  = ( clone $now )->modify( "+{$i} days" );
            $wd   = (int) $day->format( 'w' ); // 0=Sun
            if ( empty( $windows[ $wd ] ) ) continue;

            $date   = $day->format( 'Y-m-d' );
            $booked = PWT_DB::booked_slots( $date, $agent_id );
            $slots  = [];

            foreach ( $windows[ $wd ] as $win ) {
                $cursor = DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $win['start'], $tz );
                $end    = DateTime::createFromFormat( 'Y-m-d H:i', $date . ' ' . $win['end'],   $tz );
                if ( ! $cursor || ! $end ) continue;
                while ( $cursor < $end ) {
                    $hm = $cursor->format( 'H:i' );
                    if ( $cursor >= $min_book && ! in_array( $hm, $booked, true ) ) {
                        $slots[] = $hm;
                    }
                    $cursor->modify( "+{$slot_minutes} minutes" );
                }
            }
            if ( $slots ) {
                $out[] = [ 'date' => $date, 'label' => $day->format( 'D, M j' ), 'slots' => $slots ];
            }
        }
        return $out;
    }

    private static function windows_by_weekday( int $agent_id ): array {
        $rows = PWT_DB::availability( $agent_id );
        $map  = [];
        foreach ( $rows as $r ) {
            $map[ (int) $r->weekday ][] = [ 'start' => $r->start_time, 'end' => $r->end_time ];
        }
        return $map;
    }

    /** Validate that a requested datetime falls inside an available, open slot. */
    public static function is_valid_slot( string $datetime, int $agent_id = 0 ): bool {
        $ts = strtotime( $datetime );
        if ( ! $ts ) return false;
        $date = gmdate( 'Y-m-d', $ts ); // wall-clock slot key
        $hm   = gmdate( 'H:i', $ts ); // wall-clock slot key
        foreach ( self::upcoming( $agent_id, 30 ) as $day ) {
            if ( $day['date'] === $date && in_array( $hm, $day['slots'], true ) ) return true;
        }
        return false;
    }
}
