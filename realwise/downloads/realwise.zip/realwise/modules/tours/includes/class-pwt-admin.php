<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWT_Admin — tour management + availability + settings.
 */
class PWT_Admin {

    public static function init(): void {
        add_action( 'admin_menu', [ __CLASS__, 'menu' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'assets' ] );
        add_action( 'admin_post_pwt_tour_status',  [ __CLASS__, 'tour_status' ] );
        add_action( 'admin_post_pwt_save_avail',   [ __CLASS__, 'save_avail' ] );
    }

    public static function menu(): void {
        // Folded into the RealWise hub (showings are part of the sales workflow).
        $parent = class_exists( 'PWL_Admin' ) ? 'pwl-dashboard' : 'options-general.php';
        add_submenu_page( $parent, __( 'Tours', 'realwise' ),         __( 'Tours', 'realwise' ),         'manage_options', 'pwt-tours',    [ __CLASS__, 'page_tours' ], 50 );
        add_submenu_page( $parent, __( 'Availability', 'realwise' ),  __( 'Availability', 'realwise' ),  'manage_options', 'pwt-avail',    [ __CLASS__, 'page_avail' ], 55 );
        add_submenu_page( $parent, __( 'Tour Settings', 'realwise' ), __( 'Tour Settings', 'realwise' ), 'manage_options', 'pwt-settings', [ __CLASS__, 'page_settings' ], 95 );
    }

    public static function register_settings(): void {
        foreach ( [ 'pwt_slot_minutes', 'pwt_min_lead_hours', 'pwt_window_days', 'pwt_fallback_email' ] as $k ) {
            register_setting( 'pwt_settings_group', $k, [ 'sanitize_callback' => 'sanitize_text_field' ] );
        }
    }

    public static function assets( string $hook ): void {
        if ( strpos( $hook, 'pwt' ) === false ) return;
        wp_enqueue_style( 'pwt-admin', PWT_URL . 'assets/css/admin.css', [], PWT_VERSION );
    }

    public static function page_tours(): void {
        $status = sanitize_key( wp_unslash( $_GET['status'] ?? '' ) );
        $tours  = PWT_DB::tours( [ 'status' => $status, 'limit' => 200 ] );
        include PWT_DIR . 'templates/admin/tours.php';
    }

    public static function page_avail(): void {
        $weekdays = [ __( 'Sun', 'realwise' ), __( 'Mon', 'realwise' ), __( 'Tue', 'realwise' ), __( 'Wed', 'realwise' ), __( 'Thu', 'realwise' ), __( 'Fri', 'realwise' ), __( 'Sat', 'realwise' ) ];
        $windows  = PWT_DB::availability( 0 );
        $by_day   = array_fill( 0, 7, null );
        foreach ( $windows as $w ) { $by_day[ (int) $w->weekday ] = $w; }
        include PWT_DIR . 'templates/admin/availability.php';
    }

    public static function page_settings(): void {
        include PWT_DIR . 'templates/admin/settings.php';
    }

    public static function tour_status(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Denied' );
        check_admin_referer( 'pwt_tour_status' );
        PWT_Tours::set_status( (int) ( $_GET['tour'] ?? 0 ), sanitize_key( wp_unslash( $_GET['to'] ?? 'requested' ) ) );
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwt-tours', 'msg' => 'updated' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    public static function save_avail(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Denied' );
        check_admin_referer( 'pwt_save_avail' );
        $windows = [];
        foreach ( (array) ( $_POST['day'] ?? [] ) as $wd => $row ) {
            if ( empty( $row['on'] ) ) continue;
            $windows[] = [
                'weekday'    => (int) $wd,
                'start_time' => sanitize_text_field( $row['start'] ?? '09:00' ),
                'end_time'   => sanitize_text_field( $row['end'] ?? '17:00' ),
            ];
        }
        PWT_DB::replace_availability( 0, $windows );
        wp_safe_redirect( add_query_arg( [ 'page' => 'pwt-avail', 'msg' => 'saved' ], admin_url( 'admin.php' ) ) );
        exit;
    }
}
