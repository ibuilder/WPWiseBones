<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWT_DB — schema and helpers for Tours.
 */
class PWT_DB {

    public static function tours_table()    { global $wpdb; return $wpdb->prefix . 'pwt_tours'; }
    public static function avail_table()    { global $wpdb; return $wpdb->prefix . 'pwt_availability'; }

    public static function install(): void {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $sql = [];

        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::tours_table() . " (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            listing_id    BIGINT UNSIGNED DEFAULT NULL,
            agent_id      BIGINT UNSIGNED DEFAULT NULL,
            name          VARCHAR(190) DEFAULT NULL,
            email         VARCHAR(190) DEFAULT NULL,
            phone         VARCHAR(40)  DEFAULT NULL,
            requested_at  DATETIME NOT NULL,
            tour_type     VARCHAR(16) DEFAULT 'in_person',
            message       TEXT,
            status        VARCHAR(16) DEFAULT 'requested',
            reminded      TINYINT(1)  DEFAULT 0,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY listing_id (listing_id),
            KEY agent_id (agent_id),
            KEY status (status),
            KEY requested_at (requested_at)
        ) $charset;";

        // Weekly availability windows per agent (0 = global default)
        $sql[] = "CREATE TABLE IF NOT EXISTS " . self::avail_table() . " (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            agent_id    BIGINT UNSIGNED NOT NULL DEFAULT 0,
            weekday     TINYINT NOT NULL,
            start_time  VARCHAR(5) NOT NULL DEFAULT '09:00',
            end_time    VARCHAR(5) NOT NULL DEFAULT '17:00',
            PRIMARY KEY (id),
            KEY agent_id (agent_id)
        ) $charset;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( $sql as $q ) dbDelta( $q );

        // Seed a sensible default availability (Mon–Sat, 9–5) if none exists
        $count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . self::avail_table() );
        if ( $count === 0 ) {
            for ( $d = 1; $d <= 6; $d++ ) {
                $wpdb->insert( self::avail_table(), [ 'agent_id' => 0, 'weekday' => $d, 'start_time' => '09:00', 'end_time' => '17:00' ] );
            }
        }
        update_option( 'pwt_db_version', PWT_VERSION );
    }

    public static function create_tour( array $data ): int {
        global $wpdb;
        $wpdb->insert( self::tours_table(), $data );
        return $wpdb->insert_id;
    }

    public static function get_tour( int $id ): ?object {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . self::tours_table() . ' WHERE id = %d', $id ) );
    }

    public static function update_tour( int $id, array $data ): void {
        global $wpdb;
        $wpdb->update( self::tours_table(), $data, [ 'id' => $id ] );
    }

    public static function tours( array $args = [] ): array {
        global $wpdb;
        $args  = wp_parse_args( $args, [ 'status' => '', 'upcoming' => false, 'limit' => 200 ] );
        $where = [ '1=1' ]; $params = [];
        if ( $args['status'] )   { $where[] = 'status = %s'; $params[] = $args['status']; }
        if ( $args['upcoming'] ) { $where[] = 'requested_at >= %s'; $params[] = current_time( 'mysql' ); }
        $sql = "SELECT * FROM " . self::tours_table() . " WHERE " . implode( ' AND ', $where ) . " ORDER BY requested_at ASC LIMIT %d";
        $params[] = (int) $args['limit'];
        return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) ) ?: [];
    }

    public static function booked_slots( string $date, int $agent_id = 0 ): array {
        global $wpdb;
        $start = $date . ' 00:00:00';
        $end   = $date . ' 23:59:59';
        $where = 'requested_at BETWEEN %s AND %s AND status != %s';
        $params = [ $start, $end, 'cancelled' ];
        if ( $agent_id ) { $where .= ' AND agent_id = %d'; $params[] = $agent_id; }
        $rows = $wpdb->get_col( $wpdb->prepare(
            "SELECT requested_at FROM " . self::tours_table() . " WHERE $where", ...$params
        ) );
        return array_map( fn( $dt ) => gmdate( 'H:i', strtotime( $dt ) ), $rows );
    }

    public static function availability( int $agent_id = 0 ): array {
        global $wpdb;
        // Agent-specific windows if present, else global (agent_id 0)
        $rows = $wpdb->get_results( $wpdb->prepare(
            'SELECT * FROM ' . self::avail_table() . ' WHERE agent_id = %d ORDER BY weekday, start_time', $agent_id
        ) );
        if ( ! $rows && $agent_id ) {
            $rows = $wpdb->get_results( 'SELECT * FROM ' . self::avail_table() . ' WHERE agent_id = 0 ORDER BY weekday, start_time' );
        }
        return $rows ?: [];
    }

    public static function replace_availability( int $agent_id, array $windows ): void {
        global $wpdb;
        $wpdb->delete( self::avail_table(), [ 'agent_id' => $agent_id ] );
        foreach ( $windows as $w ) {
            $wpdb->insert( self::avail_table(), [
                'agent_id'   => $agent_id,
                'weekday'    => (int) $w['weekday'],
                'start_time' => $w['start_time'],
                'end_time'   => $w['end_time'],
            ] );
        }
    }
}
