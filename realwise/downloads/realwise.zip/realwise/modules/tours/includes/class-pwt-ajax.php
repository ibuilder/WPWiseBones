<?php
if ( ! defined( 'ABSPATH' ) ) exit;
/**
 * PWT_Ajax — public booking + admin status changes.
 */
class PWT_Ajax {

    public static function init(): void {
        add_action( 'wp_ajax_pwt_book_tour',        [ __CLASS__, 'book_tour' ] );
        add_action( 'wp_ajax_nopriv_pwt_book_tour', [ __CLASS__, 'book_tour' ] );
        add_action( 'wp_ajax_pwt_slots',            [ __CLASS__, 'slots' ] );
        add_action( 'wp_ajax_nopriv_pwt_slots',     [ __CLASS__, 'slots' ] );
    }

    public static function slots(): void {
        if ( ! check_ajax_referer( 'pwt_nonce', 'nonce', false ) ) wp_send_json_error( [], 403 );
        $agent_id = (int) ( $_POST['agent_id'] ?? 0 );
        wp_send_json_success( PWT_Availability::upcoming( $agent_id, (int) get_option( 'pwt_window_days', 14 ) ) );
    }

    private static function throttle( int $max = 8, int $window = HOUR_IN_SECONDS ): bool {
        $ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : 'cli';
        $key = 'pwt_rl_' . md5( $ip );
        $n   = (int) get_transient( $key );
        if ( $n >= $max ) return false;
        set_transient( $key, $n + 1, $window );
        return true;
    }

    public static function book_tour(): void {
        if ( ! check_ajax_referer( 'pwt_nonce', 'nonce', false ) ) {
            wp_send_json_error( [ 'message' => __( 'Security check failed.', 'realwise' ) ], 403 );
        }
        if ( ! empty( $_POST['pwt_hp'] ) ) wp_send_json_success(); // honeypot
        if ( ! self::throttle( 8 ) ) {
            wp_send_json_error( [ 'message' => __( 'Too many requests. Please try again later.', 'realwise' ) ], 429 );
        }

        $name  = sanitize_text_field( wp_unslash( $_POST['name']  ?? '' ) );
        $email = sanitize_email(      wp_unslash( $_POST['email'] ?? '' ) );
        $phone = sanitize_text_field( wp_unslash( $_POST['phone'] ?? '' ) );
        $date  = sanitize_text_field( wp_unslash( $_POST['date'] ?? '' ) );
        $time  = sanitize_text_field( wp_unslash( $_POST['time'] ?? '' ) );
        $agent_id   = (int) ( $_POST['agent_id'] ?? 0 );
        $listing_id = (int) ( $_POST['listing_id'] ?? 0 );

        if ( ! $email && ! $phone ) wp_send_json_error( [ 'message' => __( 'Please provide an email or phone.', 'realwise' ) ] );
        if ( ! $date || ! $time )   wp_send_json_error( [ 'message' => __( 'Please choose a time slot.', 'realwise' ) ] );

        $datetime = $date . ' ' . $time . ':00';
        if ( ! PWT_Availability::is_valid_slot( $date . ' ' . $time, $agent_id ) ) {
            wp_send_json_error( [ 'message' => __( 'That slot is no longer available. Please pick another.', 'realwise' ) ] );
        }

        $tour_id = PWT_Tours::book( [
            'listing_id'   => $listing_id ?: null,
            'agent_id'     => $agent_id ?: null,
            'name'         => $name,
            'email'        => $email ?: null,
            'phone'        => $phone ?: null,
            'requested_at' => $datetime,
            'tour_type'    => in_array( $_POST['tour_type'] ?? '', [ 'in_person', 'video' ], true ) ? $_POST['tour_type'] : 'in_person',
            'message'      => sanitize_textarea_field( wp_unslash( $_POST['message'] ?? '' ) ),
            'status'       => 'requested',
        ] );
        wp_send_json_success( [ 'tour_id' => $tour_id, 'message' => __( 'Your tour request is in! Check your email for confirmation.', 'realwise' ) ] );
    }
}
