<?php
if ( ! defined( 'ABSPATH' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery, PluginCheck.Security.DirectDB.UnescapedDBParameter -- Data-access for the plugin's own custom tables: table names come from $wpdb->prefix + hardcoded literals, and every user value is passed through $wpdb->prepare(). The sniffs flag only the (safe) interpolated table names.
/**
 * PWT_Tours — booking lifecycle, notifications, reminders.
 */
class PWT_Tours {

    public static function init(): void {
        add_action( 'pwt_send_reminders', [ __CLASS__, 'send_reminders' ] );
    }

    public static function ensure_scheduled(): void {
        if ( ! wp_next_scheduled( 'pwt_send_reminders' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'hourly', 'pwt_send_reminders' );
        }
    }

    public static function clear_scheduled(): void {
        wp_clear_scheduled_hook( 'pwt_send_reminders' );
    }

    public static function status_label( string $s ): string {
        return [
            'requested' => __( 'Requested', 'realwise' ),
            'confirmed' => __( 'Confirmed', 'realwise' ),
            'completed' => __( 'Completed', 'realwise' ),
            'cancelled' => __( 'Cancelled', 'realwise' ),
        ][ $s ] ?? ucfirst( $s );
    }

    /**
     * Create a tour, notify the agent, and fire pwt_tour_requested so the CRM
     * can capture the lead.
     */
    public static function book( array $data ): int {
        // Resolve the listing's agent if not provided
        if ( empty( $data['agent_id'] ) && ! empty( $data['listing_id'] ) && class_exists( 'PWL_DB' ) ) {
            $listing = PWL_DB::get_listing( (int) $data['listing_id'] );
            if ( $listing && $listing->agent_id ) $data['agent_id'] = (int) $listing->agent_id;
        }
        $tour_id = PWT_DB::create_tour( $data );

        self::notify_agent( $tour_id );
        self::confirm_visitor( $tour_id );

        // Let the CRM capture this as a high-intent lead
        do_action( 'pwt_tour_requested', array_merge( $data, [
            'tour_id'        => $tour_id,
            'requested_time' => $data['requested_at'] ?? '',
        ] ) );

        return $tour_id;
    }

    public static function set_status( int $id, string $status ): void {
        PWT_DB::update_tour( $id, [ 'status' => $status ] );
        if ( $status === 'confirmed' ) self::confirm_visitor( $id, true );
    }

    private static function agent_email( ?int $agent_id ): ?string {
        if ( $agent_id && class_exists( 'PWL_DB' ) ) {
            global $wpdb;
            $email = $wpdb->get_var( $wpdb->prepare( 'SELECT email FROM ' . PWL_DB::agents_table() . ' WHERE id = %d', $agent_id ) );
            if ( $email ) return $email;
        }
        return get_option( 'pwt_fallback_email', get_option( 'admin_email' ) );
    }

    private static function notify_agent( int $tour_id ): void {
        $t = PWT_DB::get_tour( $tour_id );
        if ( ! $t ) return;
        $to = self::agent_email( $t->agent_id ? (int) $t->agent_id : null );
        if ( ! $to ) return;
        $when    = date_i18n( 'l, M j, Y \a\t g:i a', strtotime( $t->requested_at ) );
        $addr    = self::listing_address( $t->listing_id );
        /* translators: %s and %d are dynamic values inserted at runtime. */
        $subject = sprintf( esc_html__( 'New tour request: %s', 'realwise' ), $addr ?: __( 'a property', 'realwise' ) );
        $body    = sprintf(
            __( "Tour requested.\n\nWhen: %1\$s\nType: %2\$s\nProperty: %3\$s\n\nName: %4\$s\nEmail: %5\$s\nPhone: %6\$s\nMessage: %7\$s\n\nManage: %8\$s", 'realwise' ),
            $when, $t->tour_type, $addr ?: '—', $t->name ?: '—', $t->email ?: '—', $t->phone ?: '—', $t->message ?: '—',
            admin_url( 'admin.php?page=pwt-tours' )
        );
        wp_mail( $to, $subject, $body );
    }

    private static function confirm_visitor( int $tour_id, bool $confirmed = false ): void {
        $t = PWT_DB::get_tour( $tour_id );
        if ( ! $t || ! $t->email ) return;
        $when = date_i18n( 'l, M j, Y \a\t g:i a', strtotime( $t->requested_at ) );
        $addr = self::listing_address( $t->listing_id );
        $subject = $confirmed
            ? __( 'Your tour is confirmed', 'realwise' )
            : __( 'We received your tour request', 'realwise' );
        $intro = $confirmed
            ? __( 'Good news — your tour is confirmed!', 'realwise' )
            : __( 'Thanks! Your tour request has been received and an agent will confirm shortly.', 'realwise' );
        $body = sprintf( "%s\n\n%s %s\n%s %s\n\n%s",
            $intro,
            __( 'When:', 'realwise' ), $when,
            __( 'Property:', 'realwise' ), $addr ?: '—',
            get_bloginfo( 'name' )
        );

        // Attach an .ics calendar invite so the visitor can add it in one click
        $attachments = [];
        $ics_path    = self::write_ics( $t, $addr );
        if ( $ics_path ) $attachments[] = $ics_path;

        wp_mail( $t->email, $subject, $body, [], $attachments );

        if ( $ics_path && file_exists( $ics_path ) ) wp_delete_file( $ics_path );
    }

    /**
     * Build an iCalendar (.ics) file for a tour and return its temp path.
     */
    private static function write_ics( object $t, string $addr ): ?string {
        $start = strtotime( $t->requested_at );
        if ( ! $start ) return null;
        $dur   = (int) get_option( 'pwt_slot_minutes', 30 ) * 60;
        $fmt   = fn( $ts ) => gmdate( 'Ymd\THis\Z', $ts );
        $uid   = 'pwt-' . $t->id . '@' . wp_parse_url( home_url(), PHP_URL_HOST );
        /* translators: %s and %d are dynamic values inserted at runtime. */
        $summary  = sprintf( esc_html__( 'Property Tour — %s', 'realwise' ), get_bloginfo( 'name' ) );
        $location = $addr ?: '';

        $ics = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//RealWise//Tours//EN\r\nMETHOD:PUBLISH\r\n"
             . "BEGIN:VEVENT\r\nUID:{$uid}\r\nDTSTAMP:" . $fmt( time() ) . "\r\n"
             . "DTSTART:" . $fmt( $start ) . "\r\nDTEND:" . $fmt( $start + $dur ) . "\r\n"
             . "SUMMARY:" . self::ics_escape( $summary ) . "\r\n"
             . ( $location ? "LOCATION:" . self::ics_escape( $location ) . "\r\n" : '' )
             . "STATUS:" . ( $t->status === 'confirmed' ? 'CONFIRMED' : 'TENTATIVE' ) . "\r\n"
             . "END:VEVENT\r\nEND:VCALENDAR\r\n";

        // Write via WP_Filesystem (WordPress-standard file I/O).
        global $wp_filesystem;
        if ( ! function_exists( 'WP_Filesystem' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        WP_Filesystem();
        $tmp = trailingslashit( get_temp_dir() ) . 'tour-' . (int) $t->id . '.ics';
        if ( $wp_filesystem && $wp_filesystem->put_contents( $tmp, $ics, FS_CHMOD_FILE ) ) {
            return $tmp;
        }
        return null;
    }

    private static function ics_escape( string $s ): string {
        return addcslashes( str_replace( [ "\r\n", "\n" ], '\\n', $s ), ",;\\" );
    }

    private static function listing_address( $listing_id ): string {
        if ( ! $listing_id || ! class_exists( 'PWL_DB' ) ) return '';
        $l = PWL_DB::get_listing( (int) $listing_id );
        return $l ? trim( $l->address . ', ' . $l->city ) : '';
    }

    /**
     * Hourly: remind visitors ~24h before their confirmed tour.
     */
    public static function send_reminders(): void {
        global $wpdb;
        $from = current_time( 'mysql' );
        $to   = gmdate( 'Y-m-d H:i:s', strtotime( '+24 hours', current_time( 'timestamp' ) ) );
        $tours = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . PWT_DB::tours_table() . "
             WHERE status IN ('confirmed','requested') AND reminded = 0
             AND requested_at BETWEEN %s AND %s", $from, $to
        ) );
        foreach ( $tours as $t ) {
            if ( $t->email ) {
                $when = date_i18n( 'l \a\t g:i a', strtotime( $t->requested_at ) );
                wp_mail( $t->email, __( 'Reminder: your tour is coming up', 'realwise' ),
                    /* translators: %s and %d are dynamic values inserted at runtime. */
                    sprintf( esc_html__( "This is a reminder of your property tour %1\$s.\n\nSee you then!\n%2\$s", 'realwise' ),
                        $when, get_bloginfo( 'name' ) ) );
            }
            PWT_DB::update_tour( (int) $t->id, [ 'reminded' => 1 ] );
        }
    }
}
