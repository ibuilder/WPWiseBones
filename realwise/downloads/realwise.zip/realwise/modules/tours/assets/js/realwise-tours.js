/* RealWise Tours — booking widget */
(function ($) {
  'use strict';

  $(function () {
    var $w = $('#pwt-widget');
    if (!$w.length) return;

    var data = [];
    try { data = JSON.parse($('#pwt-data').text() || '[]'); } catch (e) {}

    function renderSlots(date) {
      var day = data.find(function (d) { return d.date === date; });
      var html = (day ? day.slots : []).map(function (s) {
        var label = new Date('1970-01-01T' + s + ':00').toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
        return '<button type="button" class="pwt-slot" data-time="' + s + '">' + label + '</button>';
      }).join('');
      $('#pwt-slots').html(html);
    }

    // Pick a day
    $w.on('click', '.pwt-day', function () {
      $('.pwt-day').removeClass('pwt-day--active');
      $(this).addClass('pwt-day--active');
      renderSlots($(this).data('date'));
    });

    // Pick a slot → show form
    $w.on('click', '.pwt-slot', function () {
      var date = $('.pwt-day--active').data('date');
      var time = $(this).data('time');
      $('#pwt-date').val(date);
      $('#pwt-time').val(time);
      var label = $('.pwt-day--active').text().trim().replace(/\d+$/, '') + ' at ' +
        new Date('1970-01-01T' + time + ':00').toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
      $('#pwt-chosen').text('🗓 ' + label);
      $('#pwt-step-date').hide();
      $('#pwt-form').show();
    });

    // Back
    $('#pwt-back').on('click', function () {
      $('#pwt-form').hide();
      $('#pwt-step-date').show();
    });

    // Submit
    $('#pwt-form').on('submit', function (e) {
      e.preventDefault();
      var post = {
        action: 'pwt_book_tour', nonce: PWT.nonce,
        listing_id: $w.data('listing') || 0,
        agent_id: $w.data('agent') || 0
      };
      $(this).serializeArray().forEach(function (f) { post[f.name] = f.value; });
      var $btn = $(this).find('button[type=submit]').prop('disabled', true);
      var $msg = $('#pwt-msg').text('');
      $.post(PWT.ajax_url, post, function (res) {
        $btn.prop('disabled', false);
        if (res.success) {
          $('#pwt-form').hide();
          $('#pwt-success-msg').text(res.data.message);
          $('#pwt-success').show();
        } else {
          $msg.css('color', '#dc2626').text((res.data && res.data.message) || 'Could not book.');
        }
      });
    });
  });
}(jQuery));
