<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="pwt-widget" id="pwt-widget"
     data-listing="<?php echo (int) $atts['listing_id']; ?>"
     data-agent="<?php echo (int) $agent_id; ?>">
    <h3 class="pwt-title"><?php echo esc_html( $atts['title'] ); ?></h3>

    <?php if ( empty( $days ) ) : ?>
    <p class="pwt-empty"><?php esc_html_e( 'No tour times are currently available. Please check back soon or contact us directly.', 'realwise' ); ?></p>
    <?php else : ?>

    <!-- Step 1: choose a day -->
    <div class="pwt-step" id="pwt-step-date">
        <div class="pwt-days">
            <?php foreach ( $days as $i => $day ) : ?>
            <button type="button" class="pwt-day <?php echo $i === 0 ? 'pwt-day--active' : ''; ?>" data-date="<?php echo esc_attr( $day['date'] ); ?>">
                <?php echo esc_html( $day['label'] ); ?>
                <span class="pwt-day__count"><?php echo count( $day['slots'] ); ?></span>
            </button>
            <?php endforeach; ?>
        </div>
        <div class="pwt-slots" id="pwt-slots">
            <?php foreach ( $days[0]['slots'] as $slot ) : ?>
            <button type="button" class="pwt-slot" data-time="<?php echo esc_attr( $slot ); ?>"><?php echo esc_html( date_i18n( 'g:i a', strtotime( $slot ) ) ); ?></button>
            <?php endforeach; ?>
        </div>
        <script type="application/json" id="pwt-data"><?php echo wp_json_encode( $days ); ?></script>
    </div>

    <!-- Step 2: details -->
    <form class="pwt-form" id="pwt-form" style="display:none">
        <div class="pwt-chosen" id="pwt-chosen"></div>
        <div class="pwt-field-row">
            <label><?php esc_html_e( 'Tour type', 'realwise' ); ?>
                <select name="tour_type">
                    <option value="in_person"><?php esc_html_e( 'In person', 'realwise' ); ?></option>
                    <option value="video"><?php esc_html_e( 'Video call', 'realwise' ); ?></option>
                </select>
            </label>
        </div>
        <div class="pwt-field"><label><?php esc_html_e( 'Name', 'realwise' ); ?></label><input type="text" name="name" autocomplete="name"></div>
        <div class="pwt-field"><label><?php esc_html_e( 'Email', 'realwise' ); ?></label><input type="email" name="email" autocomplete="email"></div>
        <div class="pwt-field"><label><?php esc_html_e( 'Phone', 'realwise' ); ?></label><input type="tel" name="phone" autocomplete="tel"></div>
        <div class="pwt-field"><label><?php esc_html_e( 'Anything we should know?', 'realwise' ); ?></label><textarea name="message" rows="2"></textarea></div>
        <div style="position:absolute;left:-9999px" aria-hidden="true"><input type="text" name="pwt_hp" tabindex="-1" autocomplete="off"></div>
        <input type="hidden" name="date" id="pwt-date">
        <input type="hidden" name="time" id="pwt-time">
        <div class="pwt-actions">
            <button type="button" class="pwt-btn" id="pwt-back">&larr; <?php esc_html_e( 'Back', 'realwise' ); ?></button>
            <button type="submit" class="pwt-btn pwt-btn--primary"><?php esc_html_e( 'Request Tour', 'realwise' ); ?></button>
        </div>
        <div class="pwt-msg" id="pwt-msg"></div>
    </form>

    <!-- Success -->
    <div class="pwt-success" id="pwt-success" style="display:none">
        <div class="pwt-success__icon">&#10003;</div>
        <p id="pwt-success-msg"></p>
    </div>
    <?php endif; ?>
</div>
