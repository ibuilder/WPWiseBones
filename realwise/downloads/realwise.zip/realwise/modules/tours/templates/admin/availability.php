<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwt-admin">
    <h1><?php esc_html_e( 'Availability', 'realwise' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Availability saved.', 'realwise' ); ?></p></div><?php endif; ?>

    <div class="notice notice-info inline"><p>
        <?php esc_html_e( 'Set the weekly windows when tours can be booked. Slots are generated within these hours using the slot length from Settings. Tick a day to make it bookable.', 'realwise' ); ?>
    </p></div>

    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
        <input type="hidden" name="action" value="pwt_save_avail">
        <?php wp_nonce_field( 'pwt_save_avail' ); ?>
        <table class="form-table">
            <?php foreach ( $weekdays as $wd => $label ) : $w = $by_day[ $wd ]; ?>
            <tr>
                <th><label><input type="checkbox" name="day[<?php echo esc_attr( $wd ); ?>][on]" value="1" <?php checked( (bool) $w ); ?>> <?php echo esc_html( $label ); ?></label></th>
                <td>
                    <input type="time" name="day[<?php echo esc_attr( $wd ); ?>][start]" value="<?php echo esc_attr( $w->start_time ?? '09:00' ); ?>">
                    &mdash;
                    <input type="time" name="day[<?php echo esc_attr( $wd ); ?>][end]" value="<?php echo esc_attr( $w->end_time ?? '17:00' ); ?>">
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <?php submit_button( __( 'Save Availability', 'realwise' ) ); ?>
    </form>
</div>
