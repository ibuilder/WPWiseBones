<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwt-admin">
    <h1><?php esc_html_e( 'Tour Settings', 'realwise' ); ?></h1>

    <div class="notice notice-info inline"><p>
        <?php esc_html_e( 'Place', 'realwise' ); ?> <code>[pwt_request_tour]</code>
        <?php esc_html_e( 'on your listing page (it auto-detects the listing from', 'realwise' ); ?> <code>?pwl_id</code><?php esc_html_e( ') or pass', 'realwise' ); ?> <code>listing_id</code>/<code>agent_id</code>.
        <?php esc_html_e( 'When RealWise CRM is active, each request also becomes a high-intent lead automatically.', 'realwise' ); ?>
    </p></div>

    <form method="post" action="options.php">
        <?php settings_fields( 'pwt_settings_group' ); ?>
        <table class="form-table">
            <tr><th><?php esc_html_e( 'Slot length (minutes)', 'realwise' ); ?></th><td><input type="number" name="pwt_slot_minutes" value="<?php echo esc_attr( get_option( 'pwt_slot_minutes', 30 ) ); ?>" class="small-text" min="15" max="120" step="15"></td></tr>
            <tr><th><?php esc_html_e( 'Minimum lead time (hours)', 'realwise' ); ?></th><td><input type="number" name="pwt_min_lead_hours" value="<?php echo esc_attr( get_option( 'pwt_min_lead_hours', 2 ) ); ?>" class="small-text" min="0" max="72">
                <p class="description"><?php esc_html_e( 'How far in advance a visitor must book.', 'realwise' ); ?></p></td></tr>
            <tr><th><?php esc_html_e( 'Booking window (days)', 'realwise' ); ?></th><td><input type="number" name="pwt_window_days" value="<?php echo esc_attr( get_option( 'pwt_window_days', 14 ) ); ?>" class="small-text" min="1" max="60">
                <p class="description"><?php esc_html_e( 'How many days ahead visitors can see open slots.', 'realwise' ); ?></p></td></tr>
            <tr><th><?php esc_html_e( 'Fallback agent email', 'realwise' ); ?></th><td><input type="email" name="pwt_fallback_email" value="<?php echo esc_attr( get_option( 'pwt_fallback_email', get_option( 'admin_email' ) ) ); ?>" class="regular-text">
                <p class="description"><?php esc_html_e( 'Where tour requests go when the listing has no agent.', 'realwise' ); ?></p></td></tr>
        </table>
        <?php submit_button(); ?>
    </form>
</div>
