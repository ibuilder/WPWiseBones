<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>
<div class="wrap pwt-admin">
    <h1><?php esc_html_e( 'Tour Requests', 'realwise' ); ?></h1>
    <?php if ( isset( $_GET['msg'] ) ) : ?><div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Updated.', 'realwise' ); ?></p></div><?php endif; ?>

    <ul class="subsubsub">
        <?php
        $rw_tabs = [ '' => __( 'All', 'realwise' ), 'requested' => __( 'Requested', 'realwise' ), 'confirmed' => __( 'Confirmed', 'realwise' ), 'completed' => __( 'Completed', 'realwise' ) ];
        $cur  = sanitize_key( wp_unslash( $_GET['status'] ?? '' ) );
        $out  = [];
        foreach ( $rw_tabs as $k => $label ) {
            $url   = add_query_arg( array_filter( [ 'page' => 'pwt-tours', 'status' => $k ] ), admin_url( 'admin.php' ) );
            $out[] = '<a href="' . esc_url( $url ) . '" class="' . ( $cur === $k ? 'current' : '' ) . '">' . esc_html( $label ) . '</a>';
        }
        echo implode( ' | ', $out ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- items built with esc_url/esc_html.
        ?>
    </ul>

    <table class="widefat striped">
        <thead><tr>
            <th><?php esc_html_e( 'When', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Visitor', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Property', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Type', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Status', 'realwise' ); ?></th>
            <th><?php esc_html_e( 'Actions', 'realwise' ); ?></th>
        </tr></thead>
        <tbody>
        <?php if ( $tours ) : foreach ( $tours as $t ) :
            $addr = ( $t->listing_id && class_exists( 'PWL_DB' ) ) ? ( ( $l = PWL_DB::get_listing( (int) $t->listing_id ) ) ? $l->address . ', ' . $l->city : '#' . $t->listing_id ) : '—';
        ?>
        <tr>
            <td><strong><?php echo esc_html( date_i18n( 'M j, Y', strtotime( $t->requested_at ) ) ); ?></strong><br><?php echo esc_html( date_i18n( 'g:i a', strtotime( $t->requested_at ) ) ); ?></td>
            <td>
                <?php echo esc_html( $t->name ?: '—' ); ?>
                <?php if ( $t->email ) : ?><br><a href="mailto:<?php echo esc_attr( $t->email ); ?>"><?php echo esc_html( $t->email ); ?></a><?php endif; ?>
                <?php if ( $t->phone ) : ?><br><a href="tel:<?php echo esc_attr( $t->phone ); ?>"><?php echo esc_html( $t->phone ); ?></a><?php endif; ?>
            </td>
            <td><?php echo esc_html( $addr ); ?></td>
            <td><?php echo esc_html( $t->tour_type === 'video' ? __( 'Video', 'realwise' ) : __( 'In person', 'realwise' ) ); ?></td>
            <td><span class="pwt-pill pwt-pill--<?php echo esc_attr( $t->status ); ?>"><?php echo esc_html( PWT_Tours::status_label( $t->status ) ); ?></span></td>
            <td>
                <?php foreach ( [ 'confirmed' => __( 'Confirm', 'realwise' ), 'completed' => __( 'Complete', 'realwise' ), 'cancelled' => __( 'Cancel', 'realwise' ) ] as $to => $label ) :
                    if ( $t->status === $to ) continue; ?>
                <a href="<?php echo esc_url( wp_nonce_url( add_query_arg( [ 'action' => 'pwt_tour_status', 'tour' => $t->id, 'to' => $to ], admin_url( 'admin-post.php' ) ), 'pwt_tour_status' ) ); ?>" class="button button-small"><?php echo esc_html( $label ); ?></a>
                <?php endforeach; ?>
            </td>
        </tr>
        <?php endforeach; else : ?>
        <tr><td colspan="6"><?php esc_html_e( 'No tour requests yet.', 'realwise' ); ?></td></tr>
        <?php endif; ?>
        </tbody>
    </table>
</div>
