<?php
/**
 * Uninstall RealWise — removes everything every bundled module created:
 * all tables, options, transients, scheduled events, roles, capabilities, and
 * user meta. Multisite-aware. Runs only on plugin deletion (not deactivation).
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;
// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.DirectDatabaseQuery -- Uninstall drops the plugin's own custom tables (names from $wpdb->prefix + literals); no user values to prepare.

function realwise_uninstall_site() {
    global $wpdb;

    // ── Scheduled events ──────────────────────────────────────────────────────
    foreach ( [
        'pwl_run_alerts_daily', 'pwl_run_alerts_weekly', 'pwl_run_alerts_instant',
        'pwc_run_drip', 'pwpm_generate_rent', 'pwt_send_reminders',
    ] as $hook ) {
        wp_clear_scheduled_hook( $hook );
    }

    // ── Tables ────────────────────────────────────────────────────────────────
    $tables = [
        // Listings
        'pwl_listings', 'pwl_agents', 'pwl_saved', 'pwl_scores', 'pwl_price_history', 'pwl_saved_searches',
        // Developer
        'pwd_proformas', 'pwd_renovation_scenarios', 'pwd_scenarios',
        // CRM
        'pwc_leads', 'pwc_lead_activity', 'pwc_tasks',
        // Property Management
        'pwpm_properties', 'pwpm_units', 'pwpm_leases', 'pwpm_payments', 'pwpm_maintenance',
        // Tours
        'pwt_tours', 'pwt_availability',
    ];
    foreach ( $tables as $t ) {
        $wpdb->query( "DROP TABLE IF EXISTS `{$wpdb->prefix}$t`" ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    }

    // ── Options (every module uses a unique pw* prefix) ───────────────────────
    foreach ( [ 'pwl', 'pwd', 'pwc', 'pwpm', 'pwt' ] as $p ) {
        $wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '{$p}\\_%'" ); // phpcs:ignore WordPress.DB
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '\\_transient\\_{$p}\\_%'
                OR option_name LIKE '\\_transient\\_timeout\\_{$p}\\_%'"
        ); // phpcs:ignore WordPress.DB
    }
    // Listings cache layer transients (pwlc…)
    $wpdb->query(
        "DELETE FROM {$wpdb->options}
         WHERE option_name LIKE '\\_transient\\_pwlc%'
            OR option_name LIKE '\\_transient\\_timeout\\_pwlc%'"
    ); // phpcs:ignore WordPress.DB

    // ── Roles, capabilities, user meta ────────────────────────────────────────
    remove_role( 'realwise_agent' );
    remove_role( 'realwise_tenant' );
    $admin = get_role( 'administrator' );
    if ( $admin ) {
        $admin->remove_cap( 'pwc_manage_leads' );
        $admin->remove_cap( 'pwap_access' );
        $admin->remove_cap( 'pwap_edit_own' );
    }
    $wpdb->delete( $wpdb->usermeta, [ 'meta_key' => 'pwap_agent_id' ] ); // phpcs:ignore WordPress.DB.SlowDBQuery
}

if ( is_multisite() ) {
    foreach ( get_sites( [ 'fields' => 'ids', 'number' => 0 ] ) as $rw_blog_id ) {
        switch_to_blog( $rw_blog_id );
        realwise_uninstall_site();
        restore_current_blog();
    }
} else {
    realwise_uninstall_site();
}
