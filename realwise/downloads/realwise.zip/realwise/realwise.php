<?php
/**
 * Plugin Name: RealWise
 * Plugin URI:  https://wprealwise.com
 * Description: The complete real-estate platform for WordPress — listings & search with Walk Score/crime/schools, mortgage calculator, investor proformas (NPV/IRR), CRM & lead pipeline, agent portal, property management with online rent, and tour scheduling. Pairs with RealWise MLS for automated MLS imports.
 * Version:     1.0.0
 * Author:      RealWise
 * Author URI:  https://wprealwise.com
 * License:     GPL-2.0+
 * Text Domain: realwise
 * Requires PHP: 8.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WPRW_VERSION', '1.0.0' );
define( 'WPRW_DIR',     plugin_dir_path( __FILE__ ) );
define( 'WPRW_URL',     plugin_dir_url(  __FILE__ ) );
define( 'WPRW_MODULES', WPRW_DIR . 'modules/' );

/*
 * Per-module path/url/version constants. Each module's code references these to
 * resolve its own templates and assets, so it runs unchanged inside this merged
 * plugin. Class/table/option prefixes are already unique per module — no collisions.
 */
define( 'PWL_VERSION', WPRW_VERSION ); define( 'PWL_DB_VER', '1' );
define( 'PWL_DIR',  WPRW_MODULES . 'listings/' );      define( 'PWL_URL',  WPRW_URL . 'modules/listings/' );
define( 'PWD_VERSION', WPRW_VERSION );
define( 'PWD_DIR',  WPRW_MODULES . 'developer/' );     define( 'PWD_URL',  WPRW_URL . 'modules/developer/' );
define( 'PWC_VERSION', WPRW_VERSION );
define( 'PWC_DIR',  WPRW_MODULES . 'crm/' );           define( 'PWC_URL',  WPRW_URL . 'modules/crm/' );
define( 'PWAP_VERSION', WPRW_VERSION );
define( 'PWAP_DIR', WPRW_MODULES . 'agent-portal/' );  define( 'PWAP_URL', WPRW_URL . 'modules/agent-portal/' );
define( 'PWPM_VERSION', WPRW_VERSION );
define( 'PWPM_DIR', WPRW_MODULES . 'property-mgmt/' ); define( 'PWPM_URL', WPRW_URL . 'modules/property-mgmt/' );
define( 'PWT_VERSION', WPRW_VERSION );
define( 'PWT_DIR',  WPRW_MODULES . 'tours/' );         define( 'PWT_URL',  WPRW_URL . 'modules/tours/' );

// ── Load all module classes (Listings first; others reference PWL_DB) ─────────
$wprw_includes = [
    // Listings (foundation)
    'listings/includes/class-pwl-cache.php',
    'listings/includes/class-pwl-db.php',
    'listings/includes/class-pwl-listing.php',
    'listings/includes/class-pwl-scores.php',
    'listings/includes/class-pwl-mortgage.php',
    'listings/includes/class-pwl-comps.php',
    'listings/includes/class-pwl-alerts.php',
    'listings/includes/class-pwl-rest.php',
    'listings/includes/class-pwl-shortcodes.php',
    'listings/includes/class-pwl-widgets.php',
    'listings/includes/class-pwl-ajax.php',
    'listings/includes/class-pwl-admin.php',
    // Developer
    'developer/includes/class-pwd-db.php',
    'developer/includes/class-pwd-proforma.php',
    'developer/includes/class-pwd-renovation.php',
    'developer/includes/class-pwd-deal-score.php',
    'developer/includes/class-pwd-shortcodes.php',
    'developer/includes/class-pwd-ajax.php',
    'developer/includes/class-pwd-admin.php',
    // CRM
    'crm/includes/class-pwc-db.php',
    'crm/includes/class-pwc-leads.php',
    'crm/includes/class-pwc-assignment.php',
    'crm/includes/class-pwc-drip.php',
    'crm/includes/class-pwc-capture.php',
    'crm/includes/class-pwc-shortcodes.php',
    'crm/includes/class-pwc-ajax.php',
    'crm/includes/class-pwc-admin.php',
    // Agent Portal
    'agent-portal/includes/class-pwap-roles.php',
    'agent-portal/includes/class-pwap-portal.php',
    'agent-portal/includes/class-pwap-ajax.php',
    'agent-portal/includes/class-pwap-shortcodes.php',
    'agent-portal/includes/class-pwap-admin.php',
    // Property Management
    'property-mgmt/includes/class-pwpm-db.php',
    'property-mgmt/includes/class-pwpm-roles.php',
    'property-mgmt/includes/class-pwpm-rent.php',
    'property-mgmt/includes/class-pwpm-payments.php',
    'property-mgmt/includes/class-pwpm-maintenance.php',
    'property-mgmt/includes/class-pwpm-shortcodes.php',
    'property-mgmt/includes/class-pwpm-ajax.php',
    'property-mgmt/includes/class-pwpm-admin.php',
    // Tours
    'tours/includes/class-pwt-db.php',
    'tours/includes/class-pwt-availability.php',
    'tours/includes/class-pwt-tours.php',
    'tours/includes/class-pwt-shortcodes.php',
    'tours/includes/class-pwt-ajax.php',
    'tours/includes/class-pwt-admin.php',
];
foreach ( $wprw_includes as $f ) {
    require_once WPRW_MODULES . $f;
}

// ── Activation: install every module's tables, roles, and cron events ─────────
register_activation_hook( __FILE__, function () {
    PWL_DB::install();
    PWD_DB::install();
    PWC_DB::install();
    PWPM_DB::install();
    PWT_DB::install();
    PWAP_Roles::add_role();
    PWPM_Roles::add_role();
    PWL_Alerts::ensure_scheduled();
    PWC_Drip::ensure_scheduled();
    PWPM_Rent::ensure_scheduled();
    PWT_Tours::ensure_scheduled();
} );

register_deactivation_hook( __FILE__, function () {
    PWL_Alerts::clear_scheduled();
    PWC_Drip::clear_scheduled();
    PWPM_Rent::clear_scheduled();
    PWT_Tours::clear_scheduled();
} );

// Translations: WordPress.org auto-loads them for the plugin slug since WP 4.6,
// so no load_plugin_textdomain() call is needed.

// ── Bootstrap all modules ─────────────────────────────────────────────────────
add_action( 'plugins_loaded', function () {
    // Listings
    PWL_Shortcodes::init();
    PWL_Widgets::init();
    PWL_Ajax::init();
    PWL_Alerts::init();
    PWL_REST::init();
    // Developer
    PWD_Shortcodes::init();
    PWD_Ajax::init();
    // CRM
    PWC_Shortcodes::init();
    PWC_Ajax::init();
    PWC_Capture::init();
    PWC_Drip::init();
    // Agent Portal
    PWAP_Shortcodes::init();
    PWAP_Ajax::init();
    // Property Management
    PWPM_Shortcodes::init();
    PWPM_Ajax::init();
    PWPM_Rent::init();
    PWPM_Payments::init();
    // Tours
    PWT_Shortcodes::init();
    PWT_Ajax::init();
    PWT_Tours::init();

    if ( is_admin() ) {
        PWL_Admin::init();
        PWD_Admin::init();
        PWC_Admin::init();
        PWAP_Admin::init();
        PWPM_Admin::init();
        PWT_Admin::init();
    } else {
        PWL_Admin::init_front();
    }
} );

// ── Front-end assets (all modules) ────────────────────────────────────────────
add_action( 'wp_enqueue_scripts', function () {
    // Shared third-party libs (bundled locally) live in the listings module.
    wp_enqueue_style(  'pwl-leaflet', PWL_URL . 'assets/vendor/leaflet/leaflet.css', [], '1.9.4' );
    wp_enqueue_script( 'pwl-leaflet', PWL_URL . 'assets/vendor/leaflet/leaflet.js',  [], '1.9.4', true );
    wp_enqueue_script( 'pwl-chartjs', PWL_URL . 'assets/vendor/chartjs/chart.umd.min.js', [], '4.4.0', true );

    // Listings
    wp_enqueue_style(  'pwl-style', PWL_URL . 'assets/css/realwise-listings.css', [], WPRW_VERSION );
    wp_enqueue_script( 'pwl-main',  PWL_URL . 'assets/js/realwise-listings.js', [ 'jquery', 'pwl-leaflet', 'pwl-chartjs' ], WPRW_VERSION, true );
    $saved_ids = [];
    $page_ids  = array_filter( [ (int) get_option( 'pwl_listing_page_id' ), (int) get_option( 'pwl_search_page_id' ) ] );
    if ( is_user_logged_in() && $page_ids && is_page( $page_ids ) ) {
        $saved     = PWL_DB::get_saved_for_user( get_current_user_id() );
        $saved_ids = array_map( fn( $s ) => (int) $s->listing_id, $saved );
    }
    wp_localize_script( 'pwl-main', 'PWL', [
        'ajax_url'  => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'pwl_nonce' ),
        'maps_key'  => get_option( 'pwl_google_maps_key', '' ),
        'currency'  => get_option( 'pwl_currency_symbol', '$' ),
        'saved_ids' => $saved_ids,
    ] );

    // Developer
    wp_enqueue_style(  'pwd-style', PWD_URL . 'assets/css/realwise-developer.css', [], WPRW_VERSION );
    wp_enqueue_script( 'pwd-main',  PWD_URL . 'assets/js/realwise-developer.js', [ 'jquery', 'pwl-chartjs' ], WPRW_VERSION, true );
    wp_localize_script( 'pwd-main', 'PWD', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'pwd_nonce' ) ] );

    // CRM
    wp_enqueue_style(  'pwc-style', PWC_URL . 'assets/css/realwise-crm.css', [], WPRW_VERSION );
    wp_enqueue_script( 'pwc-main',  PWC_URL . 'assets/js/realwise-crm.js', [ 'jquery' ], WPRW_VERSION, true );
    wp_localize_script( 'pwc-main', 'PWC', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'pwc_nonce' ) ] );

    // Agent Portal
    wp_enqueue_style(  'pwap-style', PWAP_URL . 'assets/css/realwise-agent-portal.css', [], WPRW_VERSION );
    wp_enqueue_script( 'pwap-main',  PWAP_URL . 'assets/js/realwise-agent-portal.js', [ 'jquery' ], WPRW_VERSION, true );
    wp_localize_script( 'pwap-main', 'PWAP', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'pwap_nonce' ) ] );

    // Property Management
    wp_enqueue_style(  'pwpm-style', PWPM_URL . 'assets/css/realwise-pm.css', [], WPRW_VERSION );
    wp_enqueue_script( 'pwpm-main',  PWPM_URL . 'assets/js/realwise-pm.js', [ 'jquery' ], WPRW_VERSION, true );
    wp_localize_script( 'pwpm-main', 'PWPM', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'pwpm_nonce' ), 'stripe_pk' => get_option( 'pwpm_stripe_pk', '' ) ] );

    // Tours
    wp_enqueue_style(  'pwt-style', PWT_URL . 'assets/css/realwise-tours.css', [], WPRW_VERSION );
    wp_enqueue_script( 'pwt-main',  PWT_URL . 'assets/js/realwise-tours.js', [ 'jquery' ], WPRW_VERSION, true );
    wp_localize_script( 'pwt-main', 'PWT', [ 'ajax_url' => admin_url( 'admin-ajax.php' ), 'nonce' => wp_create_nonce( 'pwt_nonce' ) ] );
} );

// ── WPRealWise.com admin credit (all RealWise admin screens) ────────────────
add_filter( 'admin_footer_text', function ( $text ) {
    $screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
    if ( ! $screen ) return $text;
    foreach ( [ 'pwl-', 'pwd-', 'pwc-', 'pwpm-', 'pwt-' ] as $prefix ) {
        if ( strpos( $screen->id, $prefix ) !== false ) {
            return 'Built with <span style="color:#e25555">&#9829;</span> by <a href="https://wprealwise.com" target="_blank" rel="noopener"><strong>WPRealWise.com</strong></a>.';
        }
    }
    return $text;
} );
